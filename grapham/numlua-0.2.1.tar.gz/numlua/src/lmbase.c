/* {=================================================================
 * 
 * LuaMatrix basic methods
 * See Copyright Notice in luamatrix.h
 * $Id: lmbase.c,v 1.7 2006-09-11 02:25:38 carvalho Exp $
 *  
 * ==================================================================} */

#include <string.h>
#include <ctype.h>
#include <math.h>
#include <lauxlib.h>

#include "luamatrix.h"
#include "lmaux.h"
#include "lmwrap.h"
#include "lmbuffer.h"


/* {=================================================================
 *    Lua class (Matrix) metamethods
 * ==================================================================} */

static int matrix__index (lua_State *L) {
  /* stack contains matrix and index */
  lua_Matrix *M = (lua_Matrix *) lua_touserdata(L, 1);
  if (lua_isnumber(L, -1)) {
    int pos = lua_tointeger(L, 2);
    if (pos < 1 || pos > M->size)
      luaL_error(L, "invalid index: %d", pos);
    if (M->dim == 1) { /* push entry */
      int stride = (M->sup) ? M->sup->size : 1;
      if (M->complex == LM_REAL)
        lua_pushnumber(L, M->data[stride * (pos - 1)]);
      else
        complex_push(L, M->data[2 * stride * (pos - 1)],
            M->data[2 * stride * (pos - 1) + 1]);
    }
    else { /* push level */
      lua_pushlightuserdata(L, (void *) M->level[pos - 1]);
      lua_rawget(L, LUA_REGISTRYINDEX);
    }
  }
  else /* check Class method */
    lua_getfield(L, LUA_ENVIRONINDEX, luaL_checkstring(L, 2));
  return 1;
}

static int matrix__newindex (lua_State *L) {
  /* stack contains matrix, index and value */
  lua_Matrix *M = (lua_Matrix *) lua_touserdata(L, 1);
  int pos = luaL_checkinteger(L, 2);
  int stride = 1;
  if (pos < 1 || pos > M->size)
    luaL_error(L, "invalid index: %d", pos);
  if (M->dim > 1)
    luaL_error(L, "wrong dimension to attribute: %d", M->dim);
  if (M->sup) {
    stride = M->sup->size; /* M->dim == 1 already */
    settype_general(M->sup); /* reset parent type */
  }
  /* set entry */
  if (M->complex == LM_REAL)
    M->data[stride * (pos - 1)] = luaL_checknumber(L, 3);
  else {
    lua_Complex *c = complex_to(L, 3);
    if (c != NULL) { /* complex? */
      M->data[2 * stride * (pos - 1)] = c->r;
      M->data[2 * stride * (pos - 1) + 1] = c->i;
    }
    else {
      M->data[2 * stride * (pos - 1)] = luaL_checknumber(L, 3);
      M->data[2 * stride * (pos - 1) + 1] = 0;
    }
  }
  return 0;
}

/* matrix splicing for two arguments (from-to), or transpose for none */
static int matrix__call (lua_State *L) {
  /* stack contains matrix and args */
  lua_Matrix *M = (lua_Matrix *) lua_touserdata(L, 1);
  int n = lua_gettop(L);
  if (n == 1)
    matrix_transpose(L, M);
  else {
    int from = luaL_checkinteger(L, 2);
    int to = (n > 2) ? luaL_checkinteger(L, 3) : M->size;
    if ((from < 1) || (from > M->size))
      luaL_error(L, "invalid slice start: %d", from);
    if ((to < 1) || (to > M->size))
      luaL_error(L, "invalid slice end: %d", to);
    if (from > to)
      luaL_error(L, "slice start greater than end: %d > %d", from, to);
    matrix_slice(L, M, from, to);
  }
  return 1;
}

static int matrix__gc (lua_State *L) {
  /* stack contains matrix only */
  matrix_free(L, (lua_Matrix *) lua_touserdata(L, -1));
  return 0;
}

static int matrix__tostring (lua_State *L) {
  /* stack contains matrix only */
  lua_pushfstring(L, LUAMATRIX_LIBNAME ": %p", lua_touserdata(L, 1));
  return 1;
}

static int matrix__len (lua_State *L) {
  /* stack contains matrix only */
  return matrix_transpose(L, (lua_Matrix *) lua_touserdata(L, 1)) != NULL;
}

/* {====================     Operations     ========================} */

static int matrix__add (lua_State *L) {
  /* stack contains matrix and object in no specific order */
  /* check inputs */
  int pos;
  if (matrix_istype(L, 1))
    pos = (matrix_istype(L, 2)) ? 0 : 2;
  else pos = 1;
  if (pos && !lua_isnumber(L, pos) && !complex_checktype(L, pos))
    luaL_typerror(L, pos, "number or " LUACOMPLEX_LIBNAME);
  /* apply operation */
  if (pos) { /* stack contains number or complex */
    lua_Matrix *A = (lua_Matrix *) (pos == 1) ? lua_touserdata(L, 2)
        : lua_touserdata(L, 1);
    int i, stride, size = matrixA_datasize(A);
    lua_Matrix *S = matrix_copyshallow(L, A,
        A->complex | (!lua_isnumber(L, pos)));
    stride = matrix_stride(A);
    if (lua_isnumber(L, pos)) {
      lua_Number b = lua_tonumber(L, pos);
      if (A->complex == LM_REAL)
        for (i = 0; i < size; i++)
          S->data[i] = A->data[i * stride] + b;
      else
        for (i = 0; i < 2 * size; i += 2) {
          S->data[i] = A->data[i * stride] + b;
          S->data[i + 1] = A->data[i * stride + 1];
        }
    }
    else {
      lua_Complex *b = complex_to(L, pos);
      if (A->complex == LM_REAL)
        for (i = 0; i < size; i++) {
          S->data[2 * i] = A->data[i * stride] + b->r;
          S->data[2 * i + 1] = b->i;
        }
      else
        for (i = 0; i < 2 * size; i += 2) {
          S->data[i] = A->data[i * stride] + b->r;
          S->data[i + 1] = A->data[i * stride + 1] + b->i;
        }
    }
  }
  else
    matrix_add(L, (lua_Matrix *) lua_touserdata(L, 1),
        (lua_Matrix *) lua_touserdata(L, 2));
  return 1;
}

static int matrix__sub (lua_State *L) {
  /* stack contains matrix and object in no specific order */
  /* check inputs */
  int pos;
  if (matrix_istype(L, 1))
    pos = (matrix_istype(L, 2)) ? 0 : 2;
  else pos = 1;
  if (pos && !lua_isnumber(L, pos) && !complex_checktype(L, pos))
    luaL_typerror(L, pos, "number or " LUACOMPLEX_LIBNAME);
  /* apply operation */
  if (pos) { /* stack contains number or complex */
    lua_Matrix *A = (lua_Matrix *) (pos == 1) ? lua_touserdata(L, 2)
        : lua_touserdata(L, 1);
    int i, stride, size = matrixA_datasize(A);
    lua_Matrix *S = matrix_copyshallow(L, A,
        A->complex | (!lua_isnumber(L, pos)));
    stride = matrix_stride(A);
    if (lua_isnumber(L, pos)) {
      lua_Number b = lua_tonumber(L, pos);
      if (pos == 1) {
        if (A->complex == LM_REAL)
          for (i = 0; i < size; i++)
            S->data[i] = b - A->data[i * stride];
        else
          for (i = 0; i < 2 * size; i += 2) {
            S->data[i] = b - A->data[i * stride];
            S->data[i + 1] = -A->data[i * stride + 1];
          }
      }
      else { /* pos == 2 */
        if (A->complex == LM_REAL)
          for (i = 0; i < size; i++)
            S->data[i] = A->data[i * stride] - b;
        else
          for (i = 0; i < 2 * size; i += 2) {
            S->data[i] = A->data[i * stride] - b;
            S->data[i + 1] = A->data[i * stride + 1];
          }
      }
    }
    else {
      lua_Complex *b = complex_to(L, pos);
      if (pos == 1) {
        if (A->complex == LM_REAL)
          for (i = 0; i < size; i++) {
            S->data[2 * i] = b->r - A->data[i * stride];
            S->data[2 * i + 1] = b->i;
          }
        else
          for (i = 0; i < 2 * size; i += 2) {
            S->data[i] = b->r - A->data[i * stride];
            S->data[i + 1] = b->i - A->data[i * stride + 1];
          }
      }
      else {
        if (A->complex == LM_REAL)
          for (i = 0; i < size; i++) {
            S->data[2 * i] = A->data[i * stride] - b->r;
            S->data[2 * i + 1] = -b->i;
          }
        else
          for (i = 0; i < 2 * size; i += 2) {
            S->data[i] = A->data[i * stride] - b->r;
            S->data[i + 1] = A->data[i * stride + 1] - b->i;
          }
      }
    }
  }
  else
    matrix_sub(L, (lua_Matrix *) lua_touserdata(L, 1),
        (lua_Matrix *) lua_touserdata(L, 2));
  return 1;
}

static int matrix__unm (lua_State *L) {
  /* stack contains matrix only */
  matrix_unm(L, (lua_Matrix *) lua_touserdata(L, 1));
  return 1;
}

static int matrix__mul (lua_State *L) {
  /* stack contains matrix and object in no specific order */
  /* check inputs */
  int pos;
  if (matrix_istype(L, 1))
    pos = (matrix_istype(L, 2)) ? 0 : 2;
  else pos = 1;
  if (pos && !lua_isnumber(L, pos) && !complex_checktype(L, pos))
    luaL_typerror(L, pos, "number or " LUACOMPLEX_LIBNAME);
  /* apply operation */
  if (pos) { /* stack contains number or complex */
    lua_Matrix *A = (lua_Matrix *) (pos == 1) ? lua_touserdata(L, 2)
        : lua_touserdata(L, 1);
    int i, stride, size = matrixA_datasize(A);
    lua_Matrix *S = matrix_copyshallow(L, A,
        A->complex | (!lua_isnumber(L, pos)));
    stride = matrix_stride(A);
    if (lua_isnumber(L, pos)) {
      lua_Number b = lua_tonumber(L, pos);
      if (A->complex == LM_COMPLEX) size *= 2;
      for (i = 0; i < size; i++)
        S->data[i] = A->data[i * stride] * b;
    }
    else {
      lua_Complex *b = complex_to(L, pos);
      if (A->complex == LM_REAL)
        for (i = 0; i < size; i++) {
          S->data[2 * i] = A->data[i * stride] * b->r;
          S->data[2 * i + 1] = A->data[i * stride] * b->i;
        }
      else
        for (i = 0; i < 2 * size; i += 2) {
          S->data[i] = A->data[i * stride] * b->r
            - A->data[i * stride + 1] * b->i;
          S->data[i + 1] = A->data[i * stride] * b->i
            + A->data[i * stride + 1] * b->r;
        }
    }
  }
  else
    matrix_mul(L, (lua_Matrix *) lua_touserdata(L, 1),
        (lua_Matrix *) lua_touserdata(L, 2));
  return 1;
}

static int matrix__div (lua_State *L) {
  /* stack contains matrix and object in no specific order */
  /* check inputs */
  int pos;
  if (matrix_istype(L, 1))
    pos = (matrix_istype(L, 2)) ? 0 : 2;
  else pos = 1;
  if (pos && !lua_isnumber(L, pos) && !complex_checktype(L, pos))
    luaL_typerror(L, pos, "number or " LUACOMPLEX_LIBNAME);
  /* apply operation */
  if (pos) { /* stack contains number or complex */
    lua_Matrix *A = (lua_Matrix *) (pos == 1) ? lua_touserdata(L, 2)
        : lua_touserdata(L, 1);
    int i, stride, size = matrixA_datasize(A);
    lua_Matrix *S = matrix_copyshallow(L, A,
        A->complex | (!lua_isnumber(L, pos)));
    lua_Number norm;
    stride = matrix_stride(A);
    if (lua_isnumber(L, pos)) {
      lua_Number b = lua_tonumber(L, pos);
      if (pos == 1) {
        if (A->complex == LM_REAL)
          for (i = 0; i < size; i++)
            S->data[i] = b / A->data[i * stride];
        else
          for (i = 0; i < 2 * size; i += 2) {
            norm = A->data[i * stride] * A->data[i * stride]
              + A->data[i * stride + 1] * A->data[i * stride + 1];
            S->data[i] = b * A->data[i * stride] / norm;
            S->data[i + 1] = -b * A->data[i * stride + 1] / norm;
          }
      }
      else { /* pos == 2 */
        if (A->complex == LM_REAL)
          for (i = 0; i < size; i++)
            S->data[i] = A->data[i * stride] / b;
        else
          for (i = 0; i < 2 * size; i += 2) {
            S->data[i] = A->data[i * stride] / b;
            S->data[i + 1] = A->data[i * stride + 1] / b;
          }
      }
    }
    else {
      lua_Complex *c, *b = complex_to(L, pos);
      if (pos == 1) {
        if (A->complex == LM_REAL)
          for (i = 0; i < size; i++) {
            S->data[2 * i] = b->r / A->data[i * stride];
            S->data[2 * i + 1] = b->i / A->data[i * stride];
          }
        else
          for (i = 0; i < 2 * size; i += 2) {
            c = (lua_Complex *) (S->data + i);
            complex_div(c, c, (lua_Complex *) (A->data
                  + i * stride));
          }
      }
      else {
        if (A->complex == LM_REAL)
          for (i = 0; i < size; i++) {
            norm = b->r * b->r + b->i * b->i;
            S->data[2 * i] = A->data[i * stride] * b->r / norm;
            S->data[2 * i + 1] = -A->data[i * stride] * b->i / norm;
          }
        else
          for (i = 0; i < 2 * size; i += 2) {
            c = (lua_Complex *) (S->data + i);
            complex_div(c,
                (lua_Complex *) (A->data + i * stride), c);
          }
      }
    }
  }
  else { /* compute X, A*X = B by least squares */
    int rank, info;
    matrix_lss(L, (lua_Matrix *) lua_touserdata(L, 1),
        (lua_Matrix *) lua_touserdata(L, 2), 0, &rank, &info);
  }
  return 1;
}

/* true if B-A is posdef */
static int matrix__lt (lua_State *L) {
  lua_Matrix *C = matrix_sub(L, matrix_checktype(L, 2),
      matrix_checktype(L, 1));
  lua_pushboolean(L, (istype_symmetric(C)) ? matrix_isposdef(L, C) : 0);
  return 1;
}


/* {=================================================================
 *    Lua (class) methods
 * ==================================================================} */

/* matrix constructor */
static int real_matrix (lua_State *L) {
  if (lua_isnumber(L, 1)) {
    /* stack holds dimensions:
     * read them and store in array */
    int i, size = 1;
    int dim[LM_MAXDIMS];
    int n = lua_gettop(L);
    lua_Matrix *M;
    if (n < 1 || n > LM_MAXDIMS)
      luaL_error(L, "invalid number of dimensions: %d", n);
    /* compute size and create dim array */
    for (i = 0; i < n; i++)
      size *= dim[i] = luaL_checkinteger(L, i + 1);
    /* create userdata */
    M = matrix_pushshallow(L, dim, n, size, NULL, LM_REAL);
    matrixW_dscal(size, 0.0, M->data, 1);
    M->type = ((n == 2) && (dim[0] == dim[1])) 
        ? LM_SYMMETRIC + LM_DIAGONAL : LM_GENERAL;
  }
  else
    matrix_toreal(L, matrix_checktype(L, 1));
  return 1;
}

/* matrix constructor */
static int complex_matrix (lua_State *L) {
  if (lua_isnumber(L, 1)) {
    /* stack holds dimensions:
     * read them and store in array */
    int i, size = 1;
    int dim[LM_MAXDIMS];
    int n = lua_gettop(L);
    lua_Matrix *M;
    if (n < 1 || n > LM_MAXDIMS)
      luaL_error(L, "invalid number of dimensions: %d", n);
    /* compute size and create dim array */
    for (i = 0; i < n; i++)
      size *= dim[i] = luaL_checkinteger(L, i + 1);
    /* create userdata */
    M = matrix_pushshallow(L, dim, n, size, NULL, LM_COMPLEX);
    matrixW_zdscal(size, 0.0, M->data, 1);
    M->type = ((n == 2) && (dim[0] == dim[1]))
        ? LM_SYMMETRIC + LM_DIAGONAL : LM_GENERAL;
  }
  else
    matrix_tocomplex(L, matrix_checktype(L, 1));
  return 1;
}

/* return true if argument is matrix, false otherwise */
static int check_matrix (lua_State *L) {
  /* object on stack */
  lua_pushboolean(L, matrix_istype(L, 1));
  return 1;
}

/* {=======================     Info     ===========================} */

/* accessor for M->complex */
static int iscomplex_matrix (lua_State *L) {
  lua_pushboolean(L, matrix_checktype(L, 1)->complex);
  return 1;
}

/* accessor for M->dim */
static int dim_matrix (lua_State *L) {
  lua_pushinteger(L, matrix_checktype(L, 1)->dim);
  return 1;
}

/* pushes size(n) if _n_ is at position 2 on the stack, and all sizes
 * otherwise */
static int size_matrix (lua_State *L) {
  lua_Matrix *M = matrix_checktype(L, 1);
  int size[LM_MAXDIMS];
  matrixA_getsizes(M, size);
  if (lua_gettop(L) > 1) {
    int n = luaL_checkinteger(L, 2);
    lua_settop(L, 0);
    if (n < 1 || n > M->dim)
      luaL_error(L, "invalid dimension: %d", n);
    else
      lua_pushinteger(L, size[n - 1]);
    return 1;
  }
  else {
    lua_settop(L, 0);
    matrixA_pushindex(L, M, size);
    return M->dim;
  }
}

/* type handling: get */
static int gettype_matrix (lua_State *L) {
  matrix_pushtag(L, matrix_checktype(L, 1));
  return 1;
}

/* type handling: set */
/* always check matrix type using is<type> before assigning */
static int settype_matrix (lua_State *L) {
  int n = lua_gettop(L);
  lua_Matrix *M = matrix_checktype(L, 1);
  /* read input or guess if none */
  if (n == 1) /* only matrix on stack: guess type */
    matrix_guesstype(L, M);
  else {
    size_t l;
    const char *tag = luaL_checklstring(L, 2, &l);
    if (*tag != LM_TAG_GENERAL && !matrix_issquare(M))
      luaL_error(L, "matrix is not square: cannot set type to `%s'",
          tag);
    else {
      size_t i;
      for (i = 0; i < l; i++) {
        switch (toupper(tag[i])) {
          case LM_TAG_GENERAL:
            settype_general(M);
            break;
          case LM_TAG_SYMMETRIC:
            settype_symmetric(M);
            break;
          case LM_TAG_DIAGONAL:
            settype_diagonal(M);
            break;
          case LM_TAG_UPPER:
            settype_upper(M);
            break;
          case LM_TAG_LOWER:
            settype_lower(M);
            break;
          case LM_TAG_POSDEF:
            settype_posdef(M);
            break;
          default:
            luaL_error(L, "unknown type: %c", tag[i]);
            break;
        }
      }
    }
  }
  lua_settop(L, 1); /* only matrix */
  return 1; /* return matrix for convenience */
}

static int issquare_matrix (lua_State *L) {
  lua_pushboolean(L, matrix_issquare(matrix_checktype(L, 1)));
  return 1;
}

static int issymmetric_matrix (lua_State *L) {
  lua_pushboolean(L, matrix_issymmetric(matrix_checktype(L, 1)));
  return 1;
}

static int isupper_matrix (lua_State *L) {
  lua_pushboolean(L, matrix_isupper(matrix_checktype(L, 1)));
  return 1;
}

static int islower_matrix (lua_State *L) {
  lua_pushboolean(L, matrix_islower(matrix_checktype(L, 1)));
  return 1;
}

static int isdiagonal_matrix (lua_State *L) {
  lua_pushboolean(L, matrix_isdiagonal(matrix_checktype(L, 1)));
  return 1;
}


/* {=======================     Utils    ===========================} */

static int slice_matrix (lua_State *L) {
  int n = lua_gettop(L);
  lua_Matrix *M = matrix_checktype(L, 1);
  int from = luaL_checkinteger(L, 2);
  int to = (n > 2) ? luaL_checkinteger(L, 3) : M->size;
  if (from < 1 || from > M->size)
    luaL_error(L, "invalid slice start: %d", from);
  if (to < 1 || to > M->size)
    luaL_error(L, "invalid slice end: %d", to);
  if (from > to)
    luaL_error(L, "slice start greater than end: %d > %d", from, to);
  matrix_slice(L, M, from, to);
  return 1;
}

static int row_matrix (lua_State *L) {
  int n = lua_gettop(L);
  lua_Matrix *M = matrix_checktype(L, 1);
  int from = luaL_checkinteger(L, 2);
  int to = (n > 2) ? luaL_checkinteger(L, 3) : from;
  int nrows, ncols, i, stride;
  lua_Matrix *R;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to reference: %d", M->dim);
  if (from < 1 || from > M->size)
    luaL_error(L, "invalid starting row: %d", from);
  if (to < 1 || to > M->size)
    luaL_error(L, "invalid ending row: %d", to);
  if (from > to)
    luaL_error(L, "starting row greater than ending row: %d > %d",
        from, to);
  nrows = to - from + 1;
  ncols = M->level[0]->size;
  if (nrows == 1) { /* reduce dimension */
    R = matrix_pushvector(L, ncols, M->complex);
    stride = 1;
  }
  else {
    R = matrix_pusharray(L, nrows, ncols, M->complex);
    stride = nrows;
  }
  if (M->complex == LM_REAL)
    for (i = 0; i < nrows; i++)
      matrixW_dcopy(ncols, M->data + from - 1 + i, M->size,
          R->data + i, stride);
  else
    for (i = 0; i < 2 * nrows; i += 2)
      matrixW_zcopy(ncols, M->data + 2 * (from - 1) + i, M->size,
          R->data + i, stride);
  return 1;
}

static int col_matrix (lua_State *L) {
  int n = lua_gettop(L);
  lua_Matrix *M = matrix_checktype(L, 1);
  int from = luaL_checkinteger(L, 2);
  int to = (n > 2) ? luaL_checkinteger(L, 3) : from;
  int nrows, ncols;
  lua_Matrix *C;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to reference: %d", M->dim);
  if (from < 1 || from > M->level[0]->size)
    luaL_error(L, "invalid starting column: %d", from);
  if (to < 1 || to > M->level[0]->size)
    luaL_error(L, "invalid ending column: %d", to);
  if (from > to)
    luaL_error(L, "starting row greater than ending column: %d > %d",
        from, to);
  nrows = M->size;
  ncols = to - from + 1;
  if (ncols == 1) /* reduce dimension */
    C = matrix_pushvector(L, nrows, M->complex);
  else
    C = matrix_pusharray(L, nrows, ncols, M->complex);
  if (M->complex == LM_REAL)
    matrixW_dcopy(nrows * ncols, M->data + (from - 1) * M->size, 1,
        C->data, 1);
  else
    matrixW_zcopy(nrows * ncols, M->data + 2 * (from - 1) * M->size, 1,
        C->data, 1);
  return 1;
}

static int rowcat_matrix (lua_State *L) {
  lua_Matrix *A = matrix_checktype(L, 1);
  lua_Matrix *B = matrix_checktype(L, 2);
  lua_Matrix *C;
  int arows, brows, crows, cols, i;
  if (A->dim > 2)
    luaL_error(L, "invalid dimension on first argument: %d", A->dim);
  if (B->dim > 2)
    luaL_error(L, "invalid dimension on second argument: %d", B->dim);
  arows = (A->dim == 2) ? A->level[0]->size : A->size; /* cols(A) */
  brows = (B->dim == 2) ? B->level[0]->size : B->size; /* cols(B) */
  if (arows != brows)
    luaL_error(L, "number of columns does not agree: %d and %d",
        arows, brows);
  cols = arows;
  arows = (A->dim == 2) ? A->size : 1; /* rows(A) */
  brows = (B->dim == 2) ? B->size : 1; /* rows(B) */
  crows = arows + brows;
  /* create concatenation */
  C = matrix_pusharray(L, crows, cols, A->complex | B->complex);
  if (A->complex == LM_REAL) {
    if (B->complex == LM_REAL) {
      /* copy A rows */
      for (i = 0; i < arows; i++)
        matrixW_dcopy(cols, A->data + i, arows, C->data + i, crows);
      /* copy B rows */
      for (i = 0; i < brows; i++)
        matrixW_dcopy(cols, B->data + i, brows,
            C->data + arows + i, crows);
    }
    else {
      /* copy A rows */
      for (i = 0; i < arows; i++) {
        matrixW_dcopy(cols, A->data + i, arows,
            C->data + 2 * i, 2 * crows);
        matrixW_dscal(cols, 0.0, C->data + 2 * i + 1, 2 * crows);
      }
      /* copy B rows */
      for (i = 0; i < 2 * brows; i += 2)
        matrixW_zcopy(cols, B->data + i, brows,
            C->data + 2 * arows + i, crows);
    }
  }
  else {
    if (B->complex == LM_REAL) {
      /* copy A rows */
      for (i = 0; i < 2 * arows; i += 2)
        matrixW_zcopy(cols, A->data + i, arows, C->data + i, crows);
      /* copy B rows */
      for (i = 0; i < brows; i++) {
        matrixW_dcopy(cols, B->data + i, brows,
            C->data + 2 * (arows + i), 2 * crows);
        matrixW_dscal(cols, 0.0, C->data + 2 * (arows + i) + 1,
            2 * crows);
      }
    }
    else {
      /* copy A rows */
      for (i = 0; i < 2 * arows; i += 2)
        matrixW_zcopy(cols, A->data + i, arows, C->data + i, crows);
      /* copy B rows */
      for (i = 0; i < 2 * brows; i += 2)
        matrixW_zcopy(cols, B->data + i, brows,
            C->data + 2 * arows + i, crows);
    }
  }
  return 1;
}

static int colcat_matrix (lua_State *L) {
  lua_Matrix *A = matrix_checktype(L, 1);
  lua_Matrix *B = matrix_checktype(L, 2);
  lua_Matrix *C;
  int acols, bcols, ccols, rows;
  lua_pop(L, 2);
  if (A->dim > 2)
    luaL_error(L, "invalid dimension on first argument: %d", A->dim);
  if (B->dim > 2)
    luaL_error(L, "invalid dimension on second argument: %d", B->dim);
  if (A->size != B->size)
    luaL_error(L, "number of rows does not agree: %d and %d",
        A->size, B->size);
  rows = A->size;
  acols = (A->dim == 2) ? A->level[0]->size : 1;
  bcols = (B->dim == 2) ? B->level[0]->size : 1;
  ccols = acols + bcols;
  /* create concatenation */
  C = matrix_pusharray(L, rows, ccols, A->complex | B->complex);
  if (A->complex == LM_REAL) {
    if (B->complex == LM_REAL) {
      /* copy A cols */
      matrixW_dcopy(rows * acols, A->data, 1, C->data, 1);
      /* copy B cols */
      matrixW_dcopy(rows * bcols, B->data, 1,
          C->data + rows * acols, 1);
    }
    else {
      /* copy A cols */
      matrixW_dcopy(rows * acols, A->data, 1, C->data, 2);
      matrixW_dscal(rows * acols, 0.0, C->data + 1, 2);
      /* copy B cols */
      matrixW_zcopy(rows * bcols, B->data, 1,
          C->data + 2 * rows * acols, 1);
    }
  }
  else {
    if (B->complex == LM_REAL) {
      /* copy A cols */
      matrixW_zcopy(rows * acols, A->data, 1, C->data, 1);
      /* copy B cols */
      matrixW_dcopy(rows * bcols, B->data, 1,
          C->data + 2 * rows * acols, 2);
      matrixW_dscal(rows * bcols, 0.0,
          C->data + 2 * rows * acols + 1, 2);
    }
    else {
      /* copy A cols */
      matrixW_zcopy(rows * acols, A->data, 1, C->data, 1);
      /* copy B cols */
      matrixW_zcopy(rows * bcols, B->data, 1,
          C->data + 2 * rows * acols, 1);
    }
  }
  return 1;
}

static int copy_matrix (lua_State *L) {
  /* stack holds matrix only */
  matrix_copy(L, matrix_checktype(L, 1));
  return 1;
}

static int fill_matrix (lua_State *L) {
  /* stack contains matrix and number */
  lua_Matrix *M = matrix_checktype(L, 1); 
  int i;
  int stride = matrix_stride(M);
  int size = matrixA_datasize(M) * stride;
  if (M->complex == LM_REAL) {
    lua_Number x = luaL_checknumber(L, 2);
    for (i = 0; i < size; i += stride) M->data[i] = x;
  }
  else {
    size *= 2;
    stride *= 2;
    if (complex_checktype(L, 2)) {
      lua_Complex *x = complex_to(L, 2);
      for (i = 0; i < size; i += stride) {
        M->data[i] = x->r;
        M->data[i + 1] = x->i;
      }
    }
    else {
      lua_Number x = luaL_checknumber(L, 2);
      for (i = 0; i < size; i += stride) {
        M->data[i] = x;
        M->data[i + 1] = 0;
      }
    }
  }
  M->type = LM_GENERAL; /* reset type */
  lua_settop(L, 1); /* matrix */
  return 1; /* for convenience */
}

/* matrix generator-iterator */
/* first part: C closure (generator)
 * upvalues in order:
 *    o matrix M
 *    o indexes (remaining M->dim positions)
 */
static int entriesclosure_matrix (lua_State *L) {
  lua_Matrix *M = (lua_Matrix *) lua_touserdata(L, lua_upvalueindex(1));
  lua_Matrix *m = M;
  int i, size[LM_MAXDIMS];
  /* update upvalues:
   * similar to matrixA_next, but with some speedups */
  int pos = M->dim + 1;
  char back_update = 1;
  matrixA_getsizes(M, size);
  while (back_update) {
    if (lua_tointeger(L, lua_upvalueindex(pos)) == size[pos - 2]) {
      lua_pushinteger(L, 1);
      lua_replace(L, lua_upvalueindex(pos--)); /* index[pos--] = 1 */
      back_update = (pos > 1);
    }
    else {
      lua_pushinteger(L, lua_tointeger(L, lua_upvalueindex(pos)) + 1);
      lua_replace(L, lua_upvalueindex(pos)); /* index[pos]++ */
      back_update = 0;
    }
  }
  if (pos > 1) {
    /* push results */
    for (i = 0; i < M->dim - 1; i++) {
      pos = lua_tointeger(L, lua_upvalueindex(i + 2));
      lua_pushinteger(L, pos);
      m = m->level[pos - 1];
    }
    pos = lua_tointeger(L, lua_upvalueindex(i + 2));
    lua_pushinteger(L, pos);
    i = (m->sup) ? m->sup->size : 1; /* stride */
    if (m->complex == LM_REAL)
      lua_pushnumber(L, m->data[i * (pos - 1)]);
    else
      complex_push(L, m->data[i * (pos - 1)],
          m->data[i * (pos - 1) + 1]);
    return M->dim + 1;
  }
  else
    return 0;
}

/* matrix generator-iterator */
/* second part: iterator */
static int entries_matrix (lua_State *L) {
  /* only matrix on stack */
  lua_Matrix *M = matrix_checktype(L, 1);
  int i;
  for (i = 0; i < M->dim - 1; i++) lua_pushinteger(L, 1);
  lua_pushinteger(L, 0);
  lua_pushcclosure(L, entriesclosure_matrix, M->dim + 1);
  return 1;
}

/* apply an operator entrywise to two matrices */
static int op_matrix (lua_State *L) {
  /* two matrices and function in stack */
  lua_Matrix *A = matrix_checktype(L, 1);
  lua_Matrix *B = matrix_checktype(L, 2);
  int i, size = matrixA_checkconsistency(L, A, B);
  int astride = matrix_stride(A);
  int bstride = matrix_stride(B);
  lua_Matrix *M;
  luaL_checktype(L, 3, LUA_TFUNCTION);
  M = matrix_copyshallow(L, A, A->complex | B->complex);
  if (M->complex == LM_REAL)
    for (i = 0; i < size; i++) {
      lua_pushvalue(L, 3); /* function */
      lua_pushnumber(L, A->data[i * astride]); /* A[i] */
      lua_pushnumber(L, B->data[i * bstride]); /* B[i] */
      lua_call(L, 2, 1); /* op(A[i], B[i]) */
      M->data[i] = luaL_optnumber(L, -1, 0);
      lua_pop(L, 1); /* pop value */
    }
  else {
    lua_Complex *c;
    size *= 2;
    for (i = 0; i < size; i += 2) {
      lua_pushvalue(L, 3); /* function */
      complex_push(L, A->data[i * astride],
          A->data[i * astride + 1]); /* A[i] */
      complex_push(L, B->data[i * bstride],
          B->data[i * bstride + 1]); /* B[i] */
      lua_call(L, 2, 1); /* op(A[i], B[i]) */
      if ((c = complex_to(L, -1)) != NULL) {
        M->data[i] = c->r;
        M->data[i + 1] = c->i;
      }
      else {
        M->data[i] = luaL_optnumber(L, -1, 0);
        M->data[i + 1] = 0;
      }
      lua_pop(L, 1); /* pop value */
    }
  }
  return 1;
}

static int eq_matrix (lua_State *L) {
  /* stack contains matrix and number or matrix */
  lua_Matrix *E, *A = matrix_checktype(L, 1);
  int i, size, astride, bstride;
  astride = matrix_stride(A);
  if (lua_gettop(L) < 2)
    luaL_error(L, "not enough arguments to compare");
  E = matrix_copyshallow(L, A, LM_REAL);
  if (!matrix_istype(L, 2)) { /* number or complex? */
    size = matrixA_datasize(E);
    if (A->complex == LM_REAL) {
      lua_Number x = luaL_checknumber(L, 2);
      for (i = 0; i < size; i++)
        E->data[i] = EQ(A->data[i * astride], x);
    }
    else {
      if (complex_checktype(L, 2)) {
        lua_Complex *x = complex_to(L, 2);
        for (i = 0; i < size; i++)
          E->data[i] = complex_eq((lua_Complex *)
              (A->data + 2 * i * astride), x);
      }
      else {
        lua_Number x = luaL_checknumber(L, 2);
        for (i = 0; i < size; i++)
          E->data[i] = EQ(A->data[2 * i * astride], x)
            && EQZERO(A->data[2 * i * astride + 1]);
      }
    }
  }
  else { /* matrix */
    lua_Matrix *B = (lua_Matrix *) lua_touserdata(L, 2);
    bstride = matrix_stride(B);
    size = matrixA_checkconsistency(L, A, B);
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL) {
        for (i = 0; i < size; i++)
          E->data[i] = EQ(A->data[i * astride],
              B->data[i * bstride]);
      }
      else {
        for (i = 0; i < size; i++)
          E->data[i] = EQ(A->data[i * astride],
              B->data[2 * i * bstride])
              && EQZERO(B->data[2 * i * bstride + 1]);
      }
    }
    else {
      if (B->complex == LM_REAL) {
        for (i = 0; i < size; i++)
          E->data[i] = EQ(A->data[2 * i * astride],
              B->data[i * bstride])
              && EQZERO(A->data[2 * i * astride + 1]);
      }
      else {
        for (i = 0; i < size; i++)
          E->data[i] = complex_eq((lua_Complex *)
              (A->data + 2 * i * astride),
              (lua_Complex *) (B->data + 2 * i * bstride));
      }
    }
  }
  return 1;
}

static int lt_matrix (lua_State *L) {
  /* stack contains matrix and number or matrix */
  lua_Matrix *E, *A = matrix_checktype(L, 1);
  int i, size, astride, bstride;
  astride = matrix_stride(A);
  if (lua_gettop(L) < 2)
    luaL_error(L, "not enough arguments to compare");
  E = matrix_copyshallow(L, A, LM_REAL);
  if (!matrix_istype(L, 2)) { /* number or complex? */
    size = matrixA_datasize(E);
    if (A->complex == LM_REAL) {
      lua_Number x = luaL_checknumber(L, 2);
      for (i = 0; i < size; i++)
        E->data[i] = (A->data[i * astride] < x);
    }
    else {
      if (complex_checktype(L, 2)) {
        lua_Complex *x = complex_to(L, 2);
        for (i = 0; i < size; i++)
          E->data[i] = complex_lt((lua_Complex *)
              (A->data + 2 * i * astride), x);
      }
      else {
        lua_Number x = luaL_checknumber(L, 2);
        for (i = 0; i < size; i++)
          E->data[i] = (A->data[2 * i * astride] < x)
            && EQZERO(A->data[2 * i * astride + 1]);
      }
    }
  }
  else { /* matrix */
    lua_Matrix *B = (lua_Matrix *) lua_touserdata(L, 2);
    bstride = matrix_stride(B);
    size = matrixA_checkconsistency(L, A, B);
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL) {
        for (i = 0; i < size; i++)
          E->data[i] = (A->data[i * astride]
              < B->data[i * bstride]);
      }
      else {
        for (i = 0; i < size; i++)
          E->data[i] = (A->data[i * astride]
              < B->data[2 * i * bstride])
              && EQZERO(B->data[2 * i * bstride + 1]);
      }
    }
    else {
      if (B->complex == LM_REAL) {
        for (i = 0; i < size; i++)
          E->data[i] = (A->data[2 * i * astride]
              < B->data[i * bstride])
              && EQZERO(A->data[2 * i * astride + 1]);
      }
      else {
        for (i = 0; i < size; i++)
          E->data[i] = complex_lt((lua_Complex *)
              (A->data + 2 * i * astride),
              (lua_Complex *) (B->data + 2 * i * bstride));
      }
    }
  }
  return 1;
}

static int le_matrix (lua_State *L) {
  /* stack contains matrix and number or matrix */
  lua_Matrix *E, *A = matrix_checktype(L, 1);
  int i, size, astride, bstride;
  astride = matrix_stride(A);
  if (lua_gettop(L) < 2)
    luaL_error(L, "not enough arguments to compare");
  E = matrix_copyshallow(L, A, LM_REAL);
  if (!matrix_istype(L, 2)) { /* number or complex? */
    size = matrixA_datasize(E);
    if (A->complex == LM_REAL) {
      lua_Number x = luaL_checknumber(L, 2);
      for (i = 0; i < size; i++)
        E->data[i] = (A->data[i * astride] <= x);
    }
    else {
      if (complex_checktype(L, 2)) {
        lua_Complex *x = complex_to(L, 2);
        for (i = 0; i < size; i++)
          E->data[i] = complex_le((lua_Complex *)
              (A->data + 2 * i * astride), x);
      }
      else {
        lua_Number x = luaL_checknumber(L, 2);
        for (i = 0; i < size; i++)
          E->data[i] = (A->data[2 * i * astride] <= x)
            && EQZERO(A->data[2 * i * astride + 1]);
      }
    }
  }
  else { /* matrix */
    lua_Matrix *B = (lua_Matrix *) lua_touserdata(L, 2);
    bstride = matrix_stride(B);
    size = matrixA_checkconsistency(L, A, B);
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL) {
        for (i = 0; i < size; i++)
          E->data[i] = (A->data[i * astride]
              <= B->data[i * bstride]);
      }
      else {
        for (i = 0; i < size; i++)
          E->data[i] = (A->data[i * astride]
              <= B->data[2 * i * bstride])
              && EQZERO(B->data[2 * i * bstride + 1]);
      }
    }
    else {
      if (B->complex == LM_REAL) {
        for (i = 0; i < size; i++)
          E->data[i] = (A->data[2 * i * astride]
              <= B->data[i * bstride])
              && EQZERO(A->data[2 * i * astride + 1]);
      }
      else {
        for (i = 0; i < size; i++)
          E->data[i] = complex_le((lua_Complex *)
              (A->data + 2 * i * astride),
              (lua_Complex *) (B->data + 2 * i * bstride));
      }
    }
  }
  return 1;
}

static int transpose_matrix (lua_State *L) {
  /* only matrix on stack */
  lua_Matrix *M = matrix_checktype(L, 1);
  if (M->dim > 2)
    luaL_error(L, "invalid number of dimensions: %d", M->dim);
  else
    matrix_transpose(L, M);
  return 1;
}

static int linspace_matrix (lua_State *L) {
  /* stack: start, end, step */
  int n = lua_gettop(L);
  if (n < 2)
    luaL_error(L, "insufficient number of parameters: %d", n);
  else {
    lua_Number start = luaL_checknumber(L, 1);
    lua_Number end = luaL_checknumber(L, 2);
    lua_Number step = (n > 2) ? luaL_checknumber(L, 3) : 1;
    int i, size;
    lua_Matrix *v;
    lua_number2int(size, ceil((end - start) / step));
    size = (size > 0) ? size + 1 : 1;
    v = matrix_pushvector(L, size, LM_REAL);
    for (i = 0; i < size; i++)
      v->data[i] = start + step * i;
  }
  return 1;
}

/* pushes zero (square) matrix of order _n_ */
static int zeros_matrix (lua_State *L) {
  /* stack contains order */
  int n = luaL_checkinteger(L, 1);
  lua_Matrix *M = matrix_pusharray(L, n, n, LM_REAL);
  matrixW_dscal(n * n, 0.0, M->data, 1);
  M->type = LM_SYMMETRIC + LM_DIAGONAL;
  return 1;
}
  
/* pushes an identity matrix of order _n_ */
static int eye_matrix (lua_State *L) {
  /* stack contains order */
  int i, n = luaL_checkinteger(L, 1);
  lua_Matrix *M = matrix_pusharray(L, n, n, LM_REAL);
  matrixW_dscal(n * n, 0.0, M->data, 1);
  for (i = 0; i < n; i++)
    M->data[i * (n + 1)] = 1.0;
  M->type = LM_SYMMETRIC + LM_DIAGONAL;
  return 1;
}

static int diag_matrix (lua_State *L) {
  /* stack contains matrix */
  lua_Matrix *D, *M = matrix_checktype(L, 1);
  if (M->dim > 2)
    luaL_error(L, "invalid number of dimensions: %d", M->dim);
  if (M->dim == 1) { /* vector? return diagonal matrix */
    D = matrix_pusharray(L, M->size, M->size, M->complex);
    matrixW_dscal(M->size * M->size, 0.0, D->data, 1);
    if (M->complex == LM_REAL)
      matrixW_dcopy(M->size, M->data, matrix_stride(M),
          D->data, M->size + 1);
    else
      matrixW_zcopy(M->size, M->data, matrix_stride(M),
          D->data, M->size + 1);
    D->type = LM_SYMMETRIC + LM_DIAGONAL;
  }
  else {  /* matrix? return diagonal vector */
    int n = (M->size < M->level[0]->size) ? M->size : M->level[0]->size;
    D = matrix_pushvector(L, n, M->complex);
    if (M->complex == LM_REAL)
      matrixW_dcopy(n, M->data, M->size + 1, D->data, 1);
    else
      matrixW_zcopy(n, M->data, M->size + 1, D->data, 1);
  }
  return 1;
}

static int inner_matrix (lua_State *L) {
  /* stack contains one or two matrices */
  lua_Matrix *A = matrix_checktype(L, 1);
  if (lua_gettop(L) > 1)
    matrix_inner(L, A, matrix_checktype(L, 2));
  else
    matrix_inner(L, A, A);
  return 1;
}

static int outer_matrix (lua_State *L) {
  /* stack contains one or two matrices */
  lua_Matrix *A = matrix_checktype(L, 1);
  if (lua_gettop(L) > 1)
    matrix_outer(L, A, matrix_checktype(L, 2));
  else
    matrix_outer(L, A, A);
  return 1;
}


/* {====================     Functional     ========================} */

/* matrix iterator with indexes */
static int foreach_matrix (lua_State *L) {
  /* matrix and function in stack */
  int size[LM_MAXDIMS], index[LM_MAXDIMS];  /* state and control */
  lua_Number *pos;
  /* check inputs */
  lua_Matrix *M = matrix_checktype(L, 1); 
  luaL_checktype(L, 2, LUA_TFUNCTION);
  /* initialize size and index array */
  matrixA_initindex(M, index, size);
  /* iteration */
  if (M->complex == LM_REAL) {
    while (matrixA_next(M, index, size) != 0) {
      /* prepare for function call */
      lua_pushvalue(L, 2); /* function */
      /* push indexes and value */
      pos = matrixA_pushindex(L, M, index); /* indexes */
      lua_pushnumber(L, *pos); /* value */
      lua_call(L, M->dim + 1, 1);
      if (!lua_isnil(L, -1)) return 1;
      lua_pop(L, 1);  /* pop value from call */
    }
  }
  else {
    while (matrixA_next(M, index, size) != 0) {
      /* prepare for function call */
      lua_pushvalue(L, 2); /* function */
      /* push indexes and value */
      pos = matrixA_pushindex(L, M, index); /* indexes */
      complex_push(L, *pos, *(pos + 1)); /* value */
      lua_call(L, M->dim + 1, 1);
      if (!lua_isnil(L, -1)) return 1;
      lua_pop(L, 1);  /* pop value from call */
    }
  }
  return 0;
}

/* matrix iterator with entry only */
static int map_matrix (lua_State *L) {
  /* matrix and function in stack */
  /* check if it is so: */
  luaL_checktype(L, 2, LUA_TFUNCTION);
  matrix_map(L, matrix_checktype(L, 1));
  lua_settop(L, 1); /* matrix */
  return 1; /* for convenience */
}

/* matrix reducer */
static int reduce_matrix (lua_State *L) {
  /* matrix, function and initial value in stack */
  luaL_checktype(L, 2, LUA_TFUNCTION);
  lua_settop(L, 3);
  matrix_reduce(L, matrix_checktype(L, 1));
  return 1;
}

/* similar to iterator, but applies results entrywise; uses a function that
 * receives indexes (in order) and returns a new value for the respective
 * entry */
static int apply_matrix (lua_State *L) {
  /* matrix and function in stack */
  int size[LM_MAXDIMS], index[LM_MAXDIMS]; /* state and control */
  /* check inputs */
  lua_Matrix *M = matrix_checktype(L, 1); 
  luaL_checktype(L, 2, LUA_TFUNCTION);
  /* initialize size and index array */
  matrixA_initindex(M, index, size);
  /* iteration */
  if (M->complex == LM_REAL) {
    lua_Number *v;
    while (matrixA_next(M, index, size) != 0) {
      /* prepare for function call */
      lua_pushvalue(L, 2);      /* function */
      /* push indexes and value */
      v = matrixA_pushindex(L, M, index); /* indexes */
      lua_call(L, M->dim, 1);
      *v = luaL_optnumber(L, -1, 0);
      lua_pop(L, 1);    /* pop value from call */
    }
  }
  else {
    lua_Complex *v;
    while (matrixA_next(M, index, size) != 0) {
      /* prepare for function call */
      lua_pushvalue(L, 2);      /* function */
      /* push indexes and value */
      v = (lua_Complex *) matrixA_pushindex(L, M, index); /* indexes */
      lua_call(L, M->dim, 1);
      if (complex_checktype(L, -1)) {
        lua_Complex *c = complex_to(L, -1);
        *v = *c;
      }
      else {
        v->r = luaL_optnumber(L, -1, 0);
        v->i = 0;
      }
      lua_pop(L, 1);    /* pop value from call */
    }
  }
  M->type = LM_GENERAL; /* reset type */
  lua_settop(L, 1); /* matrix */
  return 1; /* for convenience */
}

static int fromtable_matrix (lua_State *L) {
  if (lua_istable(L, 1))
    matrix_fromtable(L, 1);
  else
    luaL_argerror(L, 1, "matrix expected");
  return 1;
}


/* {=================================================================
 *    Interface
 * ==================================================================} */

static int matrixMT__call (lua_State *L) {
  if (lua_isnumber(L, 2)) {
    lua_Matrix *M;
    int i, size = 1;
    int dim[LM_MAXDIMS];
    int n = lua_gettop(L)-1;
    if (n < 1 || n > LM_MAXDIMS)
      luaL_error(L, "invalid number of dimensions: %d", n);
    /* compute size and create dim array */
    for (i = 0; i < n; i++)
      size *= dim[i] = luaL_checkinteger(L, i+2);
    lua_pop(L, n);
    /* create userdata */
    M = matrix_pushshallow(L, dim, n, size, NULL, LM_REAL);
    matrixW_dscal(size, 0.0, M->data, 1);
    M->type = (n == 2 && dim[0] == dim[1])
        ? LM_SYMMETRIC + LM_DIAGONAL
        : LM_GENERAL;
  }
  else if (lua_istable(L, 2))
    matrix_fromtable(L, 2);
  else
    matrix_copy(L, matrix_checktype(L, 2));
  return 1;
}

static const luaL_reg base_func[] = {
  {"real", real_matrix},
  {"complex", complex_matrix},
  {"check", check_matrix},
  /* info */
  {"iscomplex", iscomplex_matrix},
  {"dim", dim_matrix},
  {"size", size_matrix},
  {"gettype", gettype_matrix},
  {"settype", settype_matrix},
  {"issquare", issquare_matrix},
  {"issymmetric", issymmetric_matrix},
  {"isupper", isupper_matrix},
  {"islower", islower_matrix},
  {"isdiagonal", isdiagonal_matrix},
  /* utils */
  {"slice", slice_matrix},
  {"row", row_matrix},
  {"col", col_matrix},
  {"rowcat", rowcat_matrix},
  {"colcat", colcat_matrix},
  {"copy", copy_matrix},
  {"fill", fill_matrix},
  {"entries", entries_matrix},
  {"op", op_matrix},
  {"eq", eq_matrix},
  {"lt", lt_matrix},
  {"le", le_matrix},
  {"transpose", transpose_matrix},
  {"linspace", linspace_matrix},
  {"zeros", zeros_matrix},
  {"eye", eye_matrix},
  {"diag", diag_matrix},
  {"inner", inner_matrix},
  {"outer", outer_matrix},
  /* functional */
  {"foreach", foreach_matrix},
  {"map", map_matrix},
  {"reduce", reduce_matrix},
  {"apply", apply_matrix},
  {"fromtable", fromtable_matrix},
  {NULL, NULL}
};

static const luaL_reg matrix_mt[] = {
  {"__newindex", matrix__newindex},
  {"__call", matrix__call},
  {"__gc", matrix__gc},
  {"__tostring", matrix__tostring},
  {"__concat", rowcat_matrix},
  {"__len", matrix__len},
  /* operators */
  {"__add", matrix__add},
  {"__sub", matrix__sub},
  {"__unm", matrix__unm},
  {"__mul", matrix__mul},
  {"__div", matrix__div},
  {"__lt", matrix__lt},
  {NULL, NULL}
};

int base_open (lua_State *L) {
  /* store buffer */
  matrixB_newbuffer(L);
  lua_setfield(L, LUA_REGISTRYINDEX, LUAMATRIX_BUFFER);
  /* luamatrix MT */
  luaL_newmetatable(L, LUAMATRIX_MT);
  /* set as current environment */
  lua_pushvalue(L, -1);
  lua_replace(L, LUA_ENVIRONINDEX);
  luaL_register(L, NULL, matrix_mt); /* push metamethods */
  /* class table */
  luaL_register(L, LUAMATRIX_LIBNAME, base_func);
  /* push constants */
  lua_pushstring(L, LUAMATRIX_VERSION);
  lua_setfield(L, -2, "_VERSION");
  lua_pushnumber(L, LM_EPS);    /* eps */
  lua_setfield(L, -2, "eps");
  lua_pushnumber(L, LM_RMIN);   /* underflow */
  lua_setfield(L, -2, "rmin");
  lua_pushnumber(L, LM_RMAX);   /* overflow */
  lua_setfield(L, -2, "rmax");
  /* push class table as environment to __index */
  lua_pushcfunction(L, matrix__index);
  lua_pushvalue(L, -2);
  lua_setfenv(L, -2);
  lua_setfield(L, -3, "__index");
  /* push buffer as environment to __div */
  lua_pushcfunction(L, matrix__div);
  lua_getfield(L, LUA_REGISTRYINDEX, LUAMATRIX_BUFFER);
  lua_setfenv(L, -2);
  lua_setfield(L, -3, "__div");
  /* set as MT field in class */
  lua_pushvalue(L, -2);
  lua_setfield(L, -2, "_MT");   /* push MT */
  /* push class metatable */
  lua_createtable(L, 0, 2);
  lua_pushcfunction(L, matrixMT__call);
  lua_setfield(L, -2, "__call");
  lua_pushvalue(L, -2); /* class */
  lua_setfield(L, -2, "__metatable"); /* protect */
  lua_setmetatable(L, -2);
  return 0;
}

