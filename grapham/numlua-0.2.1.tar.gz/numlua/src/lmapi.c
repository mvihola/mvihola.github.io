/* {=================================================================
 * 
 * Matrix library API
 * See Copyright Notice in luamatrix.h
 * $Id: lmapi.c,v 1.4 2006-09-11 02:25:38 carvalho Exp $
 *  
 * ==================================================================} */

#include <lauxlib.h>

#include "luamatrix.h"
#include "lmaux.h"
#include "lmwrap.h"

/* some constants */
static const lua_Complex complex_neg_one = { -1.0, 0.0 };
static const lua_Complex complex_zero    = {  0.0, 0.0 };
static const lua_Complex complex_one     = {  1.0, 0.0 };

/* {=================================================================
 *    API
 * ==================================================================} */

LUAMATRIX_API int matrix_istype (lua_State *L, int pos) {
  int b;
  if (lua_isnoneornil(L, pos)) return 0;
  if (pos <= 0 && pos > LUA_REGISTRYINDEX) pos = lua_gettop(L) + pos + 1;
  if (!lua_getmetatable(L, pos)) return 0;
  if ((b = lua_rawequal(L, -1, LUA_ENVIRONINDEX)) == 0) {
    lua_getfield(L, LUA_REGISTRYINDEX, LUAMATRIX_MT);
    b = lua_rawequal(L, -1, -2);
    lua_pop(L, 1); /* LUAMATRIX_MT */
  }
  lua_pop(L, 1); /* mt */
  return b;
}

/* checks if a matrix is in stack at position _pos_ and, if so, pushes the
 * matrix on the stack */
LUAMATRIX_API lua_Matrix *matrix_checktype (lua_State *L, int pos) {
  lua_Matrix *m = NULL;
  if (lua_isnoneornil(L, pos)) luaL_typerror(L, pos, LUAMATRIX_LIBNAME);
  if (pos <= 0 && pos > LUA_REGISTRYINDEX) pos = lua_gettop(L) + pos + 1;
  if (!lua_getmetatable(L, pos)) luaL_typerror(L, pos, LUAMATRIX_LIBNAME);
  /* check current environment first */
  if (lua_rawequal(L, -1, LUA_ENVIRONINDEX))
    m = (lua_Matrix *) lua_touserdata(L, pos);
  else {
    lua_getfield(L, LUA_REGISTRYINDEX, LUAMATRIX_MT);
    if (lua_rawequal(L, -1, -2))
      m = (lua_Matrix *) lua_touserdata(L, pos);
    lua_pop(L, 1); /* LUAMATRIX_MT */
  }
  lua_pop(L, 1); /* mt */
  if (!m) luaL_typerror(L, pos, LUAMATRIX_LIBNAME);
  return m;
}

/* *** NOTE ***:
 * matrix_pushtop and matrix_pushshallow are _low level_ routines;
 * use matrix_pusharray or matrix_pushmatrix rather */

/* pushes a lua_Matrix where lua_Matrix->data is referenced, that is, no space
 * is created for data */
LUAMATRIX_INTERN lua_Matrix *matrix_pushlevel (lua_State *L, 
    int size, int dim, lua_Number *data, lua_Matrix_complexity complex) {
  int lsize = (dim > 1) ? size * sizeof(lua_Matrix *) : 0;
  lua_Matrix *M = (lua_Matrix *) lua_newuserdata(L, 
      sizeof(lua_Matrix) + (size_t) lsize);
  M->size = size;
  M->dim = dim;
  M->sup = NULL;
  M->level = (dim > 1) ? (lua_Matrix **) (M + 1) : NULL;
  M->data = data;
  M->type = LM_GENERAL;
  M->complex = complex;
  /* set metatable */
  lua_getfield(L, LUA_REGISTRYINDEX, LUAMATRIX_MT);
  lua_setmetatable(L, -2);
  return M;
}

/* pushes a matrix level (building block), i.e. a lua_Matrix with
 * uninitialized levels: dsize is total datasize */
/* mem alignment is: first lua_Matrix, then lua_Matrix->level (if any), and
 * then lua_Matrix->data */
LUAMATRIX_API lua_Matrix *matrix_pushtop (lua_State *L,
    int size, int dim, int datasize, lua_Matrix_complexity complex) {
  int lsize = (dim > 1) ? size * sizeof(lua_Matrix *) : 0;
  int dsize = (complex == LM_REAL) ? datasize * sizeof(lua_Number)
      : 2 * datasize * sizeof(lua_Number);
  lua_Matrix *M = (lua_Matrix *) lua_newuserdata(L,
      sizeof(lua_Matrix) /* struct */
      + (size_t) lsize /* levels */
      + (size_t) dsize); /* data */
  M->size = size;
  M->dim = dim;
  M->sup = NULL;
  M->level = (dim > 1) ? (lua_Matrix **) (M + 1) : NULL;
  M->data = (lua_Number *) ((char *) M + sizeof(lua_Matrix) + lsize);
  M->type = LM_GENERAL;
  M->complex = complex;
  /* set metatable */
  lua_getfield(L, LUA_REGISTRYINDEX, LUAMATRIX_MT);
  lua_setmetatable(L, -2);
  return M;
}

/* pushes a shallow matrix, i.e. a matrix with reference to _data_ */
/* _size is size of data block */
LUAMATRIX_API lua_Matrix *matrix_pushshallow (lua_State *L,
    int *dim, int dims, int size, lua_Number *data,
    lua_Matrix_complexity complex) {
  /* push top level */
  lua_Matrix *M = (data == NULL)
      ? matrix_pushtop(L, *dim, dims, size, complex)
      :  matrix_pushlevel(L, *dim, dims, data, complex);
  /* fill levels */
  if (dims > 1) {
    /* initialize */
    int i;
    int rsize = size / M->size; /* M->size == dim[0] */
    /* stride is very important: if dims == 2, we have a regular 2D array
     * and so we store data columnwise, as in FORTRAN; otherwise, store
     * rows sequentially */
    int stride = (dims == 2) ? 1 : rsize;
    if (complex == LM_COMPLEX) stride *= 2;
    for (i = 0; i < M->size; i++) {
      M->level[i] = matrix_pushshallow(L, dim + 1, dims - 1,
          rsize, M->data + stride * i, complex);
      /* register */
      lua_pushlightuserdata(L, (void *) M->level[i]);
      lua_pushvalue(L, -2);
      lua_rawset(L, LUA_REGISTRYINDEX);
      M->level[i]->sup = M; /* keep track of parent */
      lua_pop(L, 1); /* pop registered matrix */
    }
  }
  return M;
}

/* pushes a full matrix */
LUAMATRIX_API lua_Matrix *matrix_pushmatrix (lua_State *L, int *dim,
    int dims, lua_Matrix_complexity complex) {
  lua_Matrix *M;
  /* compute size */
  int i, size = 1;
  for (i = 0; i < dims; size *= dim[i++]);
  /* create user data and initialize to zeros */
  M = matrix_pushshallow(L, dim, dims, size, NULL, complex);
  return M;
}

/* push an array (a 2D matrix) */
LUAMATRIX_API lua_Matrix *matrix_pusharray (lua_State *L, int row, int col,
    lua_Matrix_complexity complex) {
  int size = row * col;
  lua_Matrix *M;
  int dim[2]; dim[0] = row; dim[1] = col;
  /* create user data and initialize to zeros */
  M = matrix_pushshallow(L, dim, 2, size, NULL, complex);
  return M;
}

/* free memory allocated by matrix (for GC) */
LUAMATRIX_API void matrix_free (lua_State *L, lua_Matrix *M) {
  int i;
  if (M->level != NULL) { /* M->dim > 1 */
    for (i = 0; i < M->size; i++)
      matrix_free(L, M->level[i]);
  }
  /* unregister matrix */
  lua_pushlightuserdata(L, (void *) M);
  lua_pushnil(L);
  lua_rawset(L, LUA_REGISTRYINDEX);
}

/* pushes a shallow copy of a matrix, i.e. up to levels not including data */
LUAMATRIX_API lua_Matrix *matrix_copyshallow (lua_State *L, lua_Matrix *M,
    lua_Matrix_complexity complex) {
  lua_Matrix *m = M;
  int i, dim[LM_MAXDIMS];
  int size = 1;
  for (i = 0; i < M->dim - 1; i++) {
    size *= dim[i] = m->size;
    m = m->level[0];
  }
  size *= dim[i] = m->size;
  return matrix_pushshallow(L, dim, M->dim, size, NULL, complex);
}

/* pushes a full copy of a matrix */
LUAMATRIX_API lua_Matrix *matrix_copy (lua_State *L, lua_Matrix *M) {
  int size = matrixA_datasize(M);
  lua_Matrix *m = matrix_copyshallow(L, M, M->complex);
  if (M->complex == LM_REAL)
    matrixW_dcopy(size, M->data, matrix_stride(M), m->data, 1);
  else
    matrixW_zcopy(size, M->data, matrix_stride(M), m->data, 1);
  m->type = M->type;
  return m;
}

/* {====================    matrix_fromtable    ====================} */

/* auxiliar to fromtable: returns number of dimensions on table at top of
 * stack */
static int dimstable (lua_State *L) {
  if (!lua_istable(L, -1)) return 0;
  else {
    int s, min = LM_MAXDIMS;
    /* traverse table */
    lua_pushnil(L);
    while (lua_next(L, -2) != 0) {
      s = dimstable(L);
      lua_pop(L, 1);
      if (min > s) min = s;
    }
    return min + 1;
  }
}

/* auxiliar to fromtable: return size of table at top of stack */
static int sizestable (lua_State *L) {
  int s, min = INT_MAX;
  /* traverse table */
  lua_pushnil(L);
  while (lua_next(L, -2) != 0) {
    s = lua_objlen(L, -1);
    lua_pop(L, 1);
    if (min > s) min = s;
  }
  return min;
}

/* auxiliar to fromtable: given a table at the top of the stack, store
 * dimensions at dim, store complexity of table at hascomplex, return
 * datasize, and pop table */
static int sizetable (lua_State *L, int *dim, int ndims,
    lua_Matrix_complexity *hascomplex) {
  int i, j, k;
  int size = 1;
  *hascomplex = 0;
  size *= dim[0] = lua_objlen(L, -1);
  /* flatten table */
  lua_pushvalue(L, -1); /* dup */
  for (i = 1; i < ndims-1; i++) {
    size *= dim[i] = sizestable(L);
    lua_newtable(L);  /* := flat */
    for (j = 0; j < dim[i-1]; j++)
      for (k = 0; k < dim[i]; k++) {
        lua_rawgeti(L, -2, j + 1);  /* top[j] */
        lua_rawgeti(L, -1, k + 1);  /* top[j][k] */
        /* insert(flat, top[j][k]) */
        lua_rawseti(L, -3, j*dim[i] + k + 1);
        lua_pop(L, 1);  /* top[j] */
      }
    lua_replace(L, -2); /* top = flat */
  }
  /* last step: check for complex */
  i = ndims - 1;
  if (i > 0) {
    size *= dim[i] = sizestable(L);
    for (j = 0; j < dim[i-1] && (!*hascomplex); j++)
      for (k = 0; k < dim[i] && (!*hascomplex); k++) {
        lua_rawgeti(L, -2, j + 1);  /* top[j] */
        lua_rawgeti(L, -1, k + 1);  /* top[j][k] */
        if (complex_checktype(L, -1)) *hascomplex = 1;
        lua_pop(L, 2);
      }
  }
  else {
    for (k = 0; k < dim[i] && (!*hascomplex); k++) {
      lua_rawgeti(L, -1, k + 1);  /* top[k] */
      if (complex_checktype(L, -1)) *hascomplex = 1;
      lua_pop(L, 1);
    }
  }
  lua_pop(L, 1);  /* dup */
  return size;
}

/* import from table at position _pos_ */
LUAMATRIX_API lua_Matrix *matrix_fromtable (lua_State *L, int pos) {
  int i, ndims, size;
  int dims[LM_MAXDIMS], index[LM_MAXDIMS];
  lua_Matrix *M, *m;
  lua_Matrix_complexity iscomplex;
  lua_Complex *c;
  luaL_checktype(L, pos, LUA_TTABLE);
  lua_pushvalue(L, pos);
  ndims = dimstable(L);
  luaL_argcheck(L, ndims > 0, pos, "empty table");
  if (ndims > LM_MAXDIMS)
    luaL_error(L, "table dimension exceeds max dimension: %d", ndims);
  size = sizetable(L, dims, ndims, &iscomplex);
  luaL_argcheck(L, size > 0, pos, "table contains empty table");
  /* create matrix */
  M = matrix_pushshallow(L, dims, ndims, size, NULL, iscomplex);
  /* fill matrix */
  matrixA_initindex(M, index, dims);
  while (matrixA_next(M, index, dims) != 0) {
    m = M;
    lua_pushvalue(L, -2); /* top table */
    for (i = 0; i < ndims-1; i++) {
      m = m->level[index[i]-1];
      lua_rawgeti(L, -1, index[i]);
      lua_replace(L, -2);
    }
    i = ndims - 1;  /* last position */
    lua_rawgeti(L, -1, index[i]);
    i = index[i] - 1;
    if (m->sup) i *= m->sup->size; /* apply stride */
    if (iscomplex) {
      i *= 2;
      if ((c = complex_to(L, -1)) != NULL) { /* complex? */
        m->data[i] = c->r;
        m->data[i+1] = c->i;
      }
      else {
        m->data[i] = luaL_optnumber(L, -1, 0);
        m->data[i+1] = 0;
      }
    }
    else
      m->data[i] = luaL_optnumber(L, -1, 0);
    lua_pop(L, 2);  /* value */
  }
  lua_replace(L, -2); /* table copy by new matrix */
  return M;
}


/* pushes a real matrix based on a complex (or not) matrix */
LUAMATRIX_API lua_Matrix *matrix_toreal (lua_State *L, lua_Matrix *M) {
  lua_Matrix *m = M;
  int stride = matrix_stride(M);
  int i, size = 1, dim[LM_MAXDIMS];
  for (i = 0; i < M->dim-1; i++) {
    size *= dim[i] = m->size;
    m = m->level[0];
  }
  size *= dim[i] = m->size;
  m = matrix_pushshallow(L, dim, M->dim, size, NULL, LM_REAL);
  if (M->complex == LM_REAL)
    matrixW_dcopy(size, M->data, stride, m->data, 1);
  else
    for (i = 0; i < size; i++)
      m->data[i] = complex_abs((lua_Complex *) (M->data + 2*i*stride));
  return m;
}

/* pushes a complex matrix based on a real (or not) matrix */
LUAMATRIX_API lua_Matrix *matrix_tocomplex (lua_State *L, lua_Matrix *M) {
  lua_Matrix *m = M;
  int i, size = 1, dim[LM_MAXDIMS];
  for (i = 0; i < M->dim-1; i++) {
    size *= dim[i] = m->size;
    m = m->level[0];
  }
  size *= dim[i] = m->size;
  m = matrix_pushshallow(L, dim, M->dim, size, NULL, LM_COMPLEX);
  if (M->complex == LM_REAL) {
    matrixW_dcopy(size, M->data, matrix_stride(M), m->data, 2);
    matrixW_dscal(size, 0.0, m->data + 1, 2);
  }
  else
    matrixW_zcopy(size, M->data, matrix_stride(M), m->data, 1);
  return m;
}

/* pushes matrix slice, from _from_ to _to_ */
LUAMATRIX_API lua_Matrix *matrix_slice (lua_State *L, lua_Matrix *M,
    int from, int to) {
  int dims[LM_MAXDIMS];
  int shift = matrixA_datasize(M) / M->size;
  lua_Matrix *S;
  matrixA_getsizes(M, dims);
  dims[0] = to - from + 1;
  /* create matrix structure */
  if (dims[0] == 1) { /* from == to: reduce dimension */
    if (M->dim < 3)
      S = matrix_pushvector(L, shift, M->complex);
    else
      S = matrix_pushshallow(L, dims + 1, M->dim - 1, shift, NULL,
          M->complex);
  }
  else {
    if (M->dim == 1)
      S = matrix_pushvector(L, dims[0] * shift, M->complex);
    else
      S = matrix_pushshallow(L, dims, M->dim, dims[0] * shift, NULL,
          M->complex);
  }
  /* copy data */
  if (M->dim > 2) {
    if (M->complex == LM_REAL)
      matrixW_dcopy(dims[0] * shift, M->data + (from - 1) * shift,
          1, S->data, 1);
    else
      matrixW_zcopy(dims[0] * shift, M->data + 2 * (from - 1) * shift,
          1, S->data, 1);
  }
  else if (M->dim == 2) {
    int i, stride = (S->dim == 2) ? S->size : 1;
    if (M->complex == LM_REAL)
      for (i = 0; i < dims[0]; i++) /* copy each row */
        matrixW_dcopy(shift, M->data + i + from - 1, M->size,
            S->data + i, stride);
    else
      for (i = 0; i < dims[0]; i++)
        matrixW_zcopy(shift, M->data + i + from - 1, M->size,
            S->data + i, stride);
  }
  else { /* M->dim == 1 */
    if (M->complex == LM_REAL)
      matrixW_dcopy(dims[0], M->data + from - 1, 1, S->data, 1);
    else
      matrixW_zcopy(dims[0], M->data + from - 1, 1, S->data, 1);
  }
  return S;
}

/* pushes M->type tag on stack */
LUAMATRIX_API void matrix_pushtag (lua_State *L, lua_Matrix *M) {
  luaL_Buffer b;
  luaL_buffinit(L, &b);
  if (istype_general(M))
    luaL_putchar(&b, LM_TAG_GENERAL);
  else {
    if (istype_symmetric(M))
      luaL_putchar(&b, LM_TAG_SYMMETRIC);
    if (istype_diagonal(M))
      luaL_putchar(&b, LM_TAG_DIAGONAL);
    else if (istype_upper(M))
        luaL_putchar(&b, LM_TAG_UPPER);
    else if (istype_lower(M))
        luaL_putchar(&b, LM_TAG_LOWER);
    if (istype_posdef(M))
      luaL_putchar(&b, LM_TAG_POSDEF);
  }
  luaL_pushresult(&b);
}

/* guess type using is<type> functions */
LUAMATRIX_API lua_Matrix_type matrix_guesstype (lua_State *L, lua_Matrix *M) {
  M->type = LM_GENERAL;
  if (M->dim == 2 && matrix_issquare(M)) {
    if (matrix_issymmetric(M)) {
      M->type += LM_SYMMETRIC;
      if (matrix_isposdef(L, M)) M->type += LM_POSDEF;
    }
    if (matrix_isupper(M))
      M->type += LM_UPPER;
    if (matrix_islower(M))
      M->type += LM_LOWER;
  }
  return M->type;
}

/* {=======================     Info     ===========================} */

LUAMATRIX_API int matrix_issquare (lua_Matrix *M) {
  int issquare = (M->dim > 1);
  int dim = M->size;
  lua_Matrix *p = M;
  while (p->level && issquare) {
    issquare = (dim == p->level[0]->size);
    p = p->level[0];
  }
  return issquare;
}

LUAMATRIX_API int matrix_issymmetric (lua_Matrix *M) {
  int issym = 1;
  int i, j, n = M->size;
  if (M->dim != 2 || M->level[0]->size != n) return 0;
  if (M->complex == LM_REAL) {
    for (i = 0; (i < n - 1) && issym; i++)
      for (j = i + 1; (j < n) && issym; j++)
        issym = EQ(M->data[i * n + j], M->data[j * n + i]);
  }
  else {
    int r, c;
    for (i = 0; (i < n - 1) && issym; i++)
      for (j = 0; (j < i) && issym; j++) {
        r = 2 * (i * n + j);
        c = 2 * (j * n + i);
        issym = EQ(M->data[r], M->data[c]) 
            && EQ(M->data[r + 1], -M->data[c + 1]);
      }
  }
  return issym;
}

LUAMATRIX_API int matrix_isupper (lua_Matrix *M) {
  int isupper = 1;
  int i, j, n = M->size;
  if (M->dim != 2 || M->level[0]->size != n) return 0;
  if (M->complex == LM_REAL)
    for (j = 0; (j < n - 1) && isupper; j++)
      for (i = j + 1; (i < n) && isupper; i++)
        isupper = EQZERO(M->data[j * n + i]);
  else {
    int c;
    for (j = 0; (j < n - 1) && isupper; j++)
      for (i = j + 1; (i < n) && isupper; i++) {
        c = 2 * (j*n + i);
        isupper = EQZERO(M->data[c]) && EQZERO(M->data[c + 1]);
      }
  }
  return isupper;
}

LUAMATRIX_API int matrix_islower (lua_Matrix *M) {
  int islower = 1;
  int i, j, n = M->size;
  if (M->dim != 2 || M->level[0]->size != n) return 0;
  if (M->complex == LM_REAL)
    for (i = 0; (i < n - 1) && islower; i++)
      for (j = i + 1; (j < n) && islower; j++)
        islower = EQZERO(M->data[j * n + i]);
  else {
    int c;
    for (i = 0; (i < n - 1) && islower; i++)
      for (j = i + 1; (j < n) && islower; j++) {
        c = 2 * (j * n + i);
        islower = EQZERO(M->data[c]) && EQZERO(M->data[c + 1]);
      }
  }
  return islower;
}


/* {====================     Operations     ========================} */

/* pushes A+B on the stack */
LUAMATRIX_API lua_Matrix *matrix_add (lua_State *L,
    lua_Matrix *A, lua_Matrix *B) {
  int size = matrixA_checkconsistency(L, A, B);
  lua_Matrix *S = matrix_copyshallow(L, A, A->complex | B->complex);
  if (A->complex == LM_REAL) {
    if (B->complex == LM_REAL) {
      matrixW_dcopy(size, A->data, matrix_stride(A), S->data, 1);
      matrixW_daxpy(size, 1.0, B->data, matrix_stride(B), S->data, 1);
    }
    else {
      matrixW_dcopy(size, A->data, matrix_stride(A), S->data, 2);
      matrixW_dscal(size, 0.0, S->data + 1, 2);
      matrixW_zaxpy(size, complex_one, B->data, matrix_stride(B),
          S->data, 1);
    }
  }
  else {
    matrixW_zcopy(size, A->data, matrix_stride(A), S->data, 1);
    if (B->complex == LM_REAL)
      matrixW_daxpy(size, 1.0, B->data, matrix_stride(B), S->data, 2);
    else
      matrixW_zaxpy(size, complex_one, B->data, matrix_stride(B),
          S->data, 1);
  }
  S->type = A->type & B->type;  /* common types */
  S->type &= ~LM_POSDEF;      /* POSDEF off */
  return S;
}

/* pushes A-B on the stack */
LUAMATRIX_API lua_Matrix *matrix_sub (lua_State *L,
    lua_Matrix *A, lua_Matrix *B) {
  int size = matrixA_checkconsistency(L, A, B);
  lua_Matrix *S = matrix_copyshallow(L, A, A->complex | B->complex);
  if (A->complex == LM_REAL) {
    if (B->complex == LM_REAL) {
      matrixW_dcopy(size, A->data, matrix_stride(A), S->data, 1);
      matrixW_daxpy(size, -1.0, B->data, matrix_stride(B),
          S->data, 1);
    }
    else {
      matrixW_dcopy(size, A->data, matrix_stride(A), S->data, 2);
      matrixW_dscal(size, 0.0, S->data + 1, 2);
      matrixW_zaxpy(size, complex_neg_one, B->data, matrix_stride(B),
          S->data, 1);
    }
  }
  else {
    matrixW_zcopy(size, A->data, matrix_stride(A), S->data, 1);
    if (B->complex == LM_REAL)
      matrixW_daxpy(size, -1.0, B->data, matrix_stride(B), S->data, 2);
    else
      matrixW_zaxpy(size, complex_neg_one, B->data, matrix_stride(B),
          S->data, 1);
  }
  S->type = A->type & B->type;  /* common types */
  S->type &= ~LM_POSDEF;      /* POSDEF off */
  return S;
}

/* pushes (-A) on the stack */
LUAMATRIX_API lua_Matrix *matrix_unm (lua_State *L, lua_Matrix *A) {
  lua_Matrix *U = matrix_copy(L, A);  /* push U */
  int size = matrixA_datasize(A);
  if (U->complex == LM_REAL)
    matrixW_dscal(size, -1.0, U->data, 1);
  else
    matrixW_zdscal(size, -1.0, U->data, 1);
  U->type &= ~LM_POSDEF;    /* POSDEF off */
  return U;
}

/* pushes A*B on the stack */
LUAMATRIX_API lua_Matrix *matrix_mul (lua_State *L,
    lua_Matrix *A, lua_Matrix *B) {
  lua_Matrix *M;
  matrixA_checkmultiply(L, A, B);
  /* =========== first case: vector and vector ========== */
  if (A->dim == 1 && B->dim == 1) {
    int Astride = (A->sup) ? A->sup->size : 1;
    int Bstride = (B->sup) ? B->sup->size : 1;
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL)
        lua_pushnumber(L, matrixW_ddot(A->size, A->data, Astride,
              B->data, Bstride));
      else
        complex_push(L,
            matrixW_ddot(A->size, A->data, Astride,
                B->data, 2 * Bstride),
            matrixW_ddot(A->size, A->data, Astride,
                B->data + 1, 2 * Bstride));
    }
    else {
      if (B->complex == LM_REAL)
        complex_push(L,
            matrixW_ddot(A->size, A->data, 2 * Astride,
                B->data, Bstride),
            matrixW_ddot(A->size, A->data + 1, 2 * Astride,
                B->data, Bstride));
      else
        matrixW_zdotu(complex_pushzero(L),
            A->size, A->data, Astride, B->data, Bstride);
    }
    return NULL;
  }
  /* =========== second case: array and vector =========== */
  /* if B->dim == 1, we want to compute A*b; otherwise, we want B'*a */
  if (A->dim == 1 || B->dim == 1) {
    char trans;
    lua_Matrix *a, *b;
    int stride;
    if (A->dim == 1) {
      a = B; b = A; trans = 'T';
      M = matrix_pushvector(L, a->level[0]->size,
          a->complex | b->complex);
    }
    else {
      a = A; b = B; trans = 'N';
      M = matrix_pushvector(L, a->size, a->complex | b->complex);
    }
    stride = matrix_stride(b);
    if (istype_triangular(a)) {
      char uplo = istype_upper(a) ? LM_TAG_UPPER : LM_TAG_LOWER;
      if (a->complex == LM_REAL) {
        if (b->complex == LM_REAL) {
          /* copy b->data */
          matrixW_dcopy(b->size, b->data, stride, M->data, 1);
          matrixW_dtrmv(uplo,         /* UPLO */
                trans,          /* TRANS */
                'N',          /* DIAG */
                a->size,        /* N */
                a->data,        /* A */
                a->size,        /* LDA */
                M->data,        /* X */
                1);           /* INCX */
        }
        else {
          /* copy b->data */
          matrixW_zcopy(b->size, b->data, stride, M->data, 1);
          /* real part */
          matrixW_dtrmv(uplo,         /* UPLO */
                trans,          /* TRANS */
                'N',          /* DIAG */
                a->size,        /* N */
                a->data,        /* A */
                a->size,        /* LDA */
                M->data,        /* X */
                2);           /* INCX */
          /* imag part */
          matrixW_dtrmv(uplo,         /* UPLO */
                trans,          /* TRANS */
                'N',          /* DIAG */
                a->size,        /* N */
                a->data,        /* A */
                a->size,        /* LDA */
                M->data + 1,      /* X */
                2);           /* INCX */
        }
      }
      else {
        /* copy b->data */
        if (b->complex == LM_REAL) {
          matrixW_dcopy(b->size, b->data, stride, M->data, 2);
          matrixW_dscal(b->size, 0.0, M->data + 1, 2);
        }
        else
          matrixW_zcopy(b->size, b->data, stride, M->data, 1);
        matrixW_ztrmv(uplo,           /* UPLO */
              trans,            /* TRANS */
              'N',            /* DIAG */
              a->size,          /* N */
              a->data,          /* A */
              a->size,          /* LDA */
              M->data,          /* X */
              1);             /* INCX */
      }
    }
    else if (istype_symmetric(a)) {
      if (a->complex == LM_REAL) {
        if (b->complex == LM_REAL)
          matrixW_dsymv('U',          /* UPLO */
              a->size,          /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              stride,           /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        else {
          /* real part */
          matrixW_dsymv('U',          /* UPLO */
              a->size,          /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              2);             /* INCY */
          /* imag part */
          matrixW_dsymv('U',          /* UPLO */
              a->size,          /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data + 1,        /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data + 1,        /* Y */
              2);             /* INCY */
        }
      }
      else {
        lua_Number *bc = b->data;
        if (b->complex == LM_REAL) {
          /* create complex(b) */
          bc = (lua_Number *) lua_newuserdata(L,
              b->size * sizeof(lua_Complex));
          matrixW_dcopy(b->size, b->data, stride, bc, 2);
          matrixW_dscal(b->size, 0.0, bc + 1, 2);
        }
        if (trans == 'N') /* b->dim == 1 */
          matrixW_zhemv('U',          /* UPLO */
              a->size,          /* N */
              complex_one,        /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              bc,             /* X */
              /* INCX */
              b->complex == LM_REAL ? 1 : stride,
              complex_zero,       /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        else
          matrixW_zhemm('R',          /* SIDE */
              'U',            /* UPLO */
              1,              /* M */
              a->size,          /* N */
              complex_one,        /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              bc,             /* X */
              /* INCX */
              b->complex == LM_REAL ? 1 : stride,
              complex_zero,       /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        if (b->complex == LM_REAL) lua_pop(L, 1); /* allocated bc */
      }
    }
    else { /* general or posdef */
      if (a->complex == LM_REAL) {
        if (b->complex == LM_REAL)
          matrixW_dgemv(trans,        /* TRANS */
              a->size,          /* M */
              a->level[0]->size,      /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              stride,           /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        else {
          /* real part */
          matrixW_dgemv(trans,        /* TRANS */
              a->size,          /* M */
              a->level[0]->size,      /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              2);             /* INCY */
          /* imag part */
          matrixW_dgemv(trans,        /* TRANS */
              a->size,          /* M */
              a->level[0]->size,      /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data + 1,        /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data + 1,        /* Y */
              2);             /* INCY */
        }
      }
      else {
        lua_Number *bc = b->data;
        if (b->complex == LM_REAL) {
          /* create complex(b) */
          bc = (lua_Number *) lua_newuserdata(L,
              b->size * sizeof(lua_Complex));
          matrixW_dcopy(b->size, b->data, stride, bc, 2);
          matrixW_dscal(b->size, 0.0, bc + 1, 2);
        }
        matrixW_zgemv(trans,          /* TRANS */
            a->size,            /* M */
            a->level[0]->size,        /* N */
            complex_one,          /* ALPHA */
            a->data,            /* A */
            a->size,            /* LDA */
            bc,               /* X */
            /* INCX */
            b->complex == LM_REAL ? 1 : stride,
            complex_zero,         /* BETA */
            M->data,            /* Y */
            1);               /* INCY */
        if (b->complex == LM_REAL) lua_pop(L, 1); /* allocated bc */
      }
    }
    return M;
  }
  /* =========== last case: array and array =========== */
  M = matrix_pusharray(L, A->size, B->level[0]->size,
      A->complex | B->complex);
  M->type = A->type & B->type;  /* common types */
  M->type &= ~LM_POSDEF;      /* POSDEF off */
  if (istype_triangular(A) || istype_triangular(B)) {
    char side, uplo;
    int size;
    lua_Matrix *a, *b;
    if (istype_triangular(A)) {
      a = A; b = B; side = 'L';
    }
    else { /* B is triangular */
      a = B; b = A; side = 'R';
    }
    uplo = istype_upper(a) ? LM_TAG_UPPER : LM_TAG_LOWER;
    size = b->size * b->level[0]->size;
    if (a->complex == LM_REAL) {
      if (b->complex == LM_REAL) {
        matrixW_dcopy(size, b->data, 1, M->data, 1);
        matrixW_dtrmm(side,         /* SIDE */
            uplo,           /* UPLO */
            'N',            /* TRANSA */
            'N',            /* DIAG */
            b->size,          /* M */
            b->level[0]->size,      /* N */
            1.0,            /* ALPHA */
            a->data,          /* A */
            a->size,          /* LDA */
            M->data,          /* B */
            M->size);         /* LDB */
      }
      else {
        /* create complex(a) */
        int asize = a->size * a->level[0]->size;
        lua_Number *ac = (lua_Number *) lua_newuserdata(L,
              asize * sizeof(lua_Complex));
        matrixW_dcopy(asize, a->data, 1, ac, 2);
        matrixW_dscal(asize, 0.0, ac + 1, 2);
        /* copy b */
        matrixW_zcopy(size, b->data, 1, M->data, 1);
        matrixW_ztrmm(side,         /* SIDE */
            uplo,           /* UPLO */
            'N',            /* TRANSA */
            'N',            /* DIAG */
            b->size,          /* M */
            b->level[0]->size,      /* N */
            complex_one,        /* ALPHA */
            ac,             /* A */
            a->size,          /* LDA */
            M->data,          /* B */
            M->size);         /* LDB */
        lua_pop(L, 1); /* ac */
      }
    }
    else {
      if (b->complex == LM_REAL) {
        matrixW_dcopy(size, b->data, 1, M->data, 2);
        matrixW_dscal(size, 0.0, M->data + 1, 2);
      }
      else
        matrixW_zcopy(size, b->data, 1, M->data, 1);
      matrixW_ztrmm(side,           /* SIDE */
          uplo,             /* UPLO */
          'N',              /* TRANSA */
          'N',              /* DIAG */
          b->size,            /* M */
          b->level[0]->size,        /* N */
          complex_one,          /* ALPHA */
          a->data,            /* A */
          a->size,            /* LDA */
          M->data,            /* B */
          M->size);           /* LDB */
    }
  }
  else if (istype_symmetric(A) || istype_symmetric(B)) {
    char side;
    lua_Matrix *a, *b;
    if (istype_symmetric(A)) {
      a = A; b = B; side = 'L';
    }
    else { /* B is symmetric */
      a = B; b = A; side = 'R';
    }
    if (a->complex == LM_REAL) {
      if (b->complex == LM_REAL)
        matrixW_dsymm(side,         /* SIDE */
            'U',            /* UPLO */
            A->size,          /* M */
            B->level[0]->size,      /* N */
            1.0,            /* ALPHA */
            a->data,          /* A */
            a->size,          /* LDA */
            b->data,          /* B */
            b->size,          /* LDB */
            0.0,            /* BETA */
            M->data,          /* C */
            M->size);         /* LDC */
      else {
        /* create complex(a) */
        int asize = a->size * a->level[0]->size;
        lua_Number *ac = (lua_Number *) lua_newuserdata(L,
              asize * sizeof(lua_Complex));
        matrixW_dcopy(asize, a->data, 1, ac, 2);
        matrixW_dscal(asize, 0.0, ac + 1, 2);
        matrixW_zhemm(side,         /* SIDE */
            'U',            /* UPLO */
            A->size,          /* M */
            B->level[0]->size,      /* N */
            complex_one,        /* ALPHA */
            ac,             /* A */
            a->size,          /* LDA */
            b->data,          /* B */
            b->size,          /* LDB */
            complex_zero,       /* BETA */
            M->data,          /* C */
            M->size);         /* LDC */
        lua_pop(L, 1); /* ac */
      }
    }
    else {
      lua_Number *bc = b->data;
      if (b->complex == LM_REAL) {
        int bsize = b->size * b->level[0]->size;
        /* create complex(b) */
        bc = (lua_Number *) lua_newuserdata(L,
            bsize * sizeof(lua_Complex));
        matrixW_dcopy(bsize, b->data, 1, bc, 2);
        matrixW_dscal(bsize, 0.0, bc + 1, 2);
      }
      matrixW_zhemm(side,           /* SIDE */
          'U',              /* UPLO */
          A->size,            /* M */
          B->level[0]->size,        /* N */
          complex_one,          /* ALPHA */
          a->data,            /* A */
          a->size,            /* LDA */
          bc,               /* B */
          b->size,            /* LDB */
          complex_zero,         /* BETA */
          M->data,            /* C */
          M->size);           /* LDC */
      if (b->complex == LM_REAL) lua_pop(L, 1); /* allocated bc */
    }
  }
  else { /* general or posdef */
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL)
        matrixW_dgemm('N',          /* TRANSA */
            'N',            /* TRANSB */
            A->size,          /* M */
            B->level[0]->size,      /* N */
            B->size,          /* K */
            1.0,            /* ALPHA */
            A->data,          /* A */
            A->size,          /* LDA */
            B->data,          /* B */
            B->size,          /* LDB */
            0.0,            /* BETA */
            M->data,          /* C */
            M->size);         /* LDC */
      else {
        /* create complex(A) */
        int Asize = A->size * A->level[0]->size;
        lua_Number *Ac = (lua_Number *) lua_newuserdata(L,
              Asize * sizeof(lua_Complex));
        matrixW_dcopy(Asize, A->data, 1, Ac, 2);
        matrixW_dscal(Asize, 0.0, Ac + 1, 2);
        matrixW_zgemm('N',          /* TRANSA */
            'N',            /* TRANSB */
            A->size,          /* M */
            B->level[0]->size,      /* N */
            B->size,          /* K */
            complex_one,        /* ALPHA */
            Ac,             /* A */
            A->size,          /* LDA */
            B->data,          /* B */
            B->size,          /* LDB */
            complex_zero,       /* BETA */
            M->data,          /* C */
            M->size);         /* LDC */
        lua_pop(L, 1); /* Ac */
      }
    }
    else {
      lua_Number *Bc = B->data;
      if (B->complex == LM_REAL) {
        /* create complex(B) */
        int Bsize = B->size * B->level[0]->size;
        Bc = (lua_Number *) lua_newuserdata(L,
            Bsize * sizeof(lua_Complex));
        matrixW_dcopy(Bsize, B->data, 1, Bc, 2);
        matrixW_dscal(Bsize, 0.0, Bc + 1, 2);
      }
      matrixW_zgemm('N',            /* TRANSA */
          'N',              /* TRANSB */
          A->size,            /* M */
          B->level[0]->size,        /* N */
          B->size,            /* K */
          complex_one,          /* ALPHA */
          A->data,            /* A */
          A->size,            /* LDA */
          Bc,               /* B */
          B->size,            /* LDB */
          complex_zero,         /* BETA */
          M->data,            /* C */
          M->size);           /* LDC */
      if (B->complex == LM_REAL) lua_pop(L, 1); /* allocated Bc */
    }
  }
  return M;
}


/* {====================       Utils        ========================} */

/* pushes _array_ M' (transpose) on the stack */
LUAMATRIX_API lua_Matrix *matrix_transpose (lua_State *L, lua_Matrix *M) {
  lua_Matrix *T;
  if (M->dim == 1) {
    T = matrix_copy(L, M);
    /* conjugate */
    if (M->complex == LM_COMPLEX)
      matrixW_dscal(T->size, -1.0, T->data + 1, 2);
  }
  else {  /* M->dim == 2 */
    int i;
    T = matrix_pusharray(L, M->level[0]->size, M->size, M->complex);
    /* transpose */
    if (M->complex == LM_REAL)
      for (i = 0; i < M->level[0]->size; i++)
        matrixW_dcopy(M->size, M->data + i * M->size, 1,
            T->data + i, T->size);
    else {
      for (i = 0; i < M->level[0]->size; i++)
        matrixW_zcopy(M->size, M->data + 2 * i * M->size, 1,
            T->data + 2 * i, T->size);
      /* conjugate */
      matrixW_dscal(T->size * M->size, -1.0, T->data + 1, 2);
    }
    /* set type */
    T->type = M->type;
    /* alternate upper and lower */
    if ((T->type ^ LM_UPPER) & LM_LOWER) /* strictly lower? */
      settype_upper(T);
    else if ((T->type ^ LM_LOWER) & LM_UPPER) /* strictly upper? */
      settype_lower(T);
  }
  return T;
}


/* {====================      matrix_inner      ====================} */

/* pushes A'*B on the stack */
LUAMATRIX_API lua_Matrix *matrix_inner (lua_State *L,
    lua_Matrix *A, lua_Matrix *B) {
  lua_Matrix *M;
  matrixA_checkinner(L, A, B);
  /* =========== first case: vector and vector ========== */
  if (A->dim == 1 && B->dim == 1) {
    int Astride = (A->sup) ? A->sup->size : 1;
    int Bstride = (B->sup) ? B->sup->size : 1;
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL)
        lua_pushnumber(L, matrixW_ddot(A->size, A->data, Astride,
            B->data, Bstride));
      else
        complex_push(L,
            matrixW_ddot(A->size, A->data, Astride,
                B->data, 2 * Bstride),
            matrixW_ddot(A->size, A->data, Astride,
                B->data + 1, 2 * Bstride));
    }
    else {
      if (B->complex == LM_REAL)
        complex_push(L,
            matrixW_ddot(A->size, A->data, 2 * Astride,
                B->data, Bstride),
            -matrixW_ddot(A->size, A->data + 1, 2 * Astride,
                B->data, Bstride));
      else
        matrixW_zdotc(complex_pushzero(L),
            A->size, A->data, Astride, B->data, Bstride);
    }
    return NULL;
  }
  /* =========== second case: array and vector =========== */
  if (A->dim == 1 || B->dim == 1) {
    lua_Matrix *a, *b;
    int stride;
    if (A->dim == 1) {
      a = B; b = A;
    }
    else {
      a = A; b = B;
    }
    M = matrix_pushvector(L, a->level[0]->size, a->complex | b->complex);
    stride = matrix_stride(b);
    if (istype_triangular(a)) {
      char uplo = istype_upper(a) ? LM_TAG_UPPER : LM_TAG_LOWER;
      if (a->complex == LM_REAL) {
        if (b->complex == LM_REAL) {
          /* copy b->data */
          matrixW_dcopy(b->size, b->data, stride, M->data, 1);
          matrixW_dtrmv(uplo,         /* UPLO */
                'C',          /* TRANS */
                'N',          /* DIAG */
                a->size,        /* N */
                a->data,        /* A */
                a->size,        /* LDA */
                M->data,        /* X */
                1);           /* INCX */
        }
        else {
          /* copy b->data */
          matrixW_zcopy(b->size, b->data, stride, M->data, 1);
          /* real part */
          matrixW_dtrmv(uplo,         /* UPLO */
                'C',          /* TRANS */
                'N',          /* DIAG */
                a->size,        /* N */
                a->data,        /* A */
                a->size,        /* LDA */
                M->data,        /* X */
                2);           /* INCX */
          /* imag part */
          matrixW_dtrmv(uplo,         /* UPLO */
                'C',          /* TRANS */
                'N',          /* DIAG */
                a->size,        /* N */
                a->data,        /* A */
                a->size,        /* LDA */
                M->data + 1,      /* X */
                2);           /* INCX */
        }
      }
      else {
        /* copy b->data */
        if (b->complex == LM_REAL) {
          matrixW_dcopy(b->size, b->data, stride, M->data, 2);
          matrixW_dscal(b->size, 0.0, M->data + 1, 2);
        }
        else
          matrixW_zcopy(b->size, b->data, stride, M->data, 1);
        matrixW_ztrmv(uplo,           /* UPLO */
              'C',            /* TRANS */
              'N',            /* DIAG */
              a->size,          /* N */
              a->data,          /* A */
              a->size,          /* LDA */
              M->data,          /* X */
              1);             /* INCX */
      }
    }
    else if (istype_symmetric(a)) {
      if (a->complex == LM_REAL) {
        if (b->complex == LM_REAL)
          matrixW_dsymv('U',          /* UPLO */
              a->size,          /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              stride,           /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        else {
          /* real part */
          matrixW_dsymv('U',          /* UPLO */
              a->size,          /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              2);             /* INCY */
          /* imag part */
          matrixW_dsymv('U',          /* UPLO */
              a->size,          /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data + 1,        /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data + 1,        /* Y */
              2);             /* INCY */
        }
      }
      else {
        lua_Number *bc = b->data;
        if (b->complex == LM_REAL) {
          /* create complex(b) */
          bc = (lua_Number *) lua_newuserdata(L,
              b->size * sizeof(lua_Complex));
          matrixW_dcopy(b->size, b->data, stride, bc, 2);
          matrixW_dscal(b->size, 0.0, bc + 1, 2);
        }
        if (b->dim == 1)
          matrixW_zhemv('U',          /* UPLO */
              a->size,          /* N */
              complex_one,        /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              bc,             /* X */
              /* INCX */
              b->complex == LM_REAL ? 1 : stride,
              complex_zero,       /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        else
          matrixW_zhemm('R',          /* SIDE */
              'U',            /* UPLO */
              1,              /* M */
              a->size,          /* N */
              complex_one,        /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              bc,             /* X */
              /* INCX */
              b->complex == LM_REAL ? 1 : stride,
              complex_zero,       /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        if (b->complex == LM_REAL) lua_pop(L, 1); /* allocated bc */
      }
    }
    else { /* general or posdef */
      if (a->complex == LM_REAL) {
        if (b->complex == LM_REAL)
          matrixW_dgemv('C',          /* TRANS */
              a->size,          /* M */
              a->level[0]->size,      /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              stride,           /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        else {
          /* real part */
          matrixW_dgemv('C',          /* TRANS */
              a->size,          /* M */
              a->level[0]->size,      /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              2);             /* INCY */
          /* imag part */
          matrixW_dgemv('C',          /* TRANS */
              a->size,          /* M */
              a->level[0]->size,      /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data + 1,        /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data + 1,        /* Y */
              2);             /* INCY */
        }
      }
      else {
        lua_Number *bc = b->data;
        if (b->complex == LM_REAL) {
          /* create complex(b) */
          bc = (lua_Number *) lua_newuserdata(L,
              b->size * sizeof(lua_Complex));
          matrixW_dcopy(b->size, b->data, stride, bc, 2);
          matrixW_dscal(b->size, 0.0, bc + 1, 2);
        }
        matrixW_zgemv('C',            /* TRANS */
            a->size,            /* M */
            a->level[0]->size,        /* N */
            complex_one,          /* ALPHA */
            a->data,            /* A */
            a->size,            /* LDA */
            bc,               /* X */
            /* INCX */
            b->complex == LM_REAL ? 1 : stride,
            complex_zero,         /* BETA */
            M->data,            /* Y */
            1);               /* INCY */
        if (b->complex == LM_REAL) lua_pop(L, 1); /* allocated bc */
      }
    }
    /* conjugate result if applicable */
    if (A->dim == 1 && M->complex == LM_COMPLEX)
      matrixW_dscal(M->size, -1.0, M->data + 1, 2);
    return M;
  }
  /* =========== last case: array and array =========== */
  M = matrix_pusharray(L, A->level[0]->size, B->level[0]->size,
      A->complex | B->complex);
  M->type = A->type;
  if (A != B) {
    /* transpose A type */
    if ((A->type ^ LM_UPPER) & LM_LOWER) /* strictly lower? */
      settype_upper(M);
    else if ((A->type ^ LM_LOWER) & LM_UPPER) /* strictly upper? */
      settype_lower(M);
    M->type &= B->type; /* common types */
    M->type &= ~LM_POSDEF; /* POSDEF off */
  }
  else M->type = LM_SYMMETRIC;
  if (istype_triangular(A)) {
    char uplo = istype_upper(A) ? LM_TAG_UPPER : LM_TAG_LOWER;
    int size = B->size * B->level[0]->size;
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL) {
        matrixW_dcopy(size, B->data, 1, M->data, 1);
        matrixW_dtrmm('L',            /* SIDE */
            uplo,             /* UPLO */
            'C',              /* TRANSA */
            'N',              /* DIAG */
            B->size,            /* M */
            B->level[0]->size,        /* N */
            1.0,              /* ALPHA */
            A->data,            /* A */
            A->size,            /* LDA */
            M->data,            /* B */
            M->size);           /* LDB */
      }
      else {
        /* create complex(A) */
        int Asize = A->size * A->level[0]->size;
        lua_Number *Ac = (lua_Number *) lua_newuserdata(L,
              Asize * sizeof(lua_Complex));
        matrixW_dcopy(Asize, A->data, 1, Ac, 2);
        matrixW_dscal(Asize, 0.0, Ac + 1, 2);
        /* copy B */
        matrixW_zcopy(size, B->data, 1, M->data, 1);
        matrixW_ztrmm('L',            /* SIDE */
            uplo,             /* UPLO */
            'C',              /* TRANSA */
            'N',              /* DIAG */
            B->size,            /* M */
            B->level[0]->size,        /* N */
            complex_one,          /* ALPHA */
            Ac,               /* A */
            A->size,            /* LDA */
            M->data,            /* B */
            M->size);           /* LDB */
        lua_pop(L, 1); /* Ac */
      }
    }
    else {
      if (B->complex == LM_REAL) {
        matrixW_dcopy(size, B->data, 1, M->data, 2);
        matrixW_dscal(size, 0.0, M->data + 1, 2);
      }
      else
        matrixW_zcopy(size, B->data, 1, M->data, 1);
      matrixW_ztrmm('L',              /* SIDE */
          uplo,               /* UPLO */
          'C',                /* TRANSA */
          'N',                /* DIAG */
          B->size,              /* M */
          B->level[0]->size,          /* N */
          complex_one,            /* ALPHA */
          A->data,              /* A */
          A->size,              /* LDA */
          M->data,              /* B */
          M->size);             /* LDB */
    }
  }
  else if (A == B) {
    int i = 0, s = 0;
    if (A->complex == LM_REAL) {
      matrixW_dsyrk('L',              /* UPLO */
          'C',                /* TRANS */
          A->level[0]->size,          /* N */
          A->size,              /* K */
          1.0,                /* ALPHA */
          A->data,              /* A */
          A->size,              /* LDA */
          0.0,                /* BETA */
          M->data,              /* C */
          M->size);             /* LDC */
      /* reflect columns to rows */
      for ( ; i < M->size - 1; i++, s += M->size)
        matrixW_dcopy(M->size - i - 1,
            M->data + s + i + 1, 1,
            M->data + s + i + M->size, M->size);
    }
    else {
      matrixW_zherk('L',              /* UPLO */
          'C',                /* TRANS */
          A->level[0]->size,          /* N */
          A->size,              /* K */
          1.0,                /* ALPHA */
          A->data,              /* A */
          A->size,              /* LDA */
          0.0,                /* BETA */
          M->data,              /* C */
          M->size);             /* LDC */
      /* reflect columns to rows */
      for ( ; i < M->size - 1; i++, s += M->size) {
        matrixW_zcopy(M->size - i - 1,
            M->data + 2 * (s + i + 1), 1,
            M->data + 2 * (s + i + M->size), M->size);
        /* conjugate */
        matrixW_dscal(M->size - i - 1, -1.0,
            M->data + 2 * (s + i + M->size) + 1, 2 * M->size);
      }
    }
  }
  else if (istype_symmetric(A)) {
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL)
        matrixW_dsymm('L',            /* SIDE */
            'U',              /* UPLO */
            A->level[0]->size,        /* M */
            B->level[0]->size,        /* N */
            1.0,              /* ALPHA */
            A->data,            /* A */
            A->size,            /* LDA */
            B->data,            /* B */
            B->size,            /* LDB */
            0.0,              /* BETA */
            M->data,            /* C */
            M->size);           /* LDC */
      else {
        /* create complex(A) */
        int Asize = A->size * A->level[0]->size;
        lua_Number *Ac = (lua_Number *) lua_newuserdata(L,
              Asize * sizeof(lua_Complex));
        matrixW_dcopy(Asize, A->data, 1, Ac, 2);
        matrixW_dscal(Asize, 0.0, Ac + 1, 2);
        matrixW_zhemm('L',            /* SIDE */
            'U',              /* UPLO */
            A->level[0]->size,        /* M */
            B->level[0]->size,        /* N */
            complex_one,          /* ALPHA */
            Ac,               /* A */
            A->size,            /* LDA */
            B->data,            /* B */
            B->size,            /* LDB */
            complex_zero,         /* BETA */
            M->data,            /* C */
            M->size);           /* LDC */
        lua_pop(L, 1); /* Ac */
      }
    }
    else {
      lua_Number *Bc = B->data;
      if (B->complex == LM_REAL) {
        int Bsize = B->size * B->level[0]->size;
        /* create complex(B) */
        Bc = (lua_Number *) lua_newuserdata(L,
            Bsize * sizeof(lua_Complex));
        matrixW_dcopy(Bsize, B->data, 1, Bc, 2);
        matrixW_dscal(Bsize, 0.0, Bc + 1, 2);
      }
      matrixW_zhemm('L',              /* SIDE */
          'U',                /* UPLO */
          A->level[0]->size,          /* M */
          B->level[0]->size,          /* N */
          complex_one,            /* ALPHA */
          A->data,              /* A */
          A->size,              /* LDA */
          Bc,                 /* B */
          B->size,              /* LDB */
          complex_zero,           /* BETA */
          M->data,              /* C */
          M->size);             /* LDC */
      if (B->complex == LM_REAL) lua_pop(L, 1); /* allocated Bc */
    }
  }
  else { /* general or posdef */
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL)
        matrixW_dgemm('C',            /* TRANSA */
            'N',              /* TRANSB */
            A->level[0]->size,        /* M */
            B->level[0]->size,        /* N */
            B->size,            /* K */
            1.0,              /* ALPHA */
            A->data,            /* A */
            A->size,            /* LDA */
            B->data,            /* B */
            B->size,            /* LDB */
            0.0,              /* BETA */
            M->data,            /* C */
            M->size);           /* LDC */
      else {
        /* create complex(A) */
        int Asize = A->size * A->level[0]->size;
        lua_Number *Ac = (lua_Number *) lua_newuserdata(L,
              Asize * sizeof(lua_Complex));
        matrixW_dcopy(Asize, A->data, 1, Ac, 2);
        matrixW_dscal(Asize, 0.0, Ac + 1, 2);
        matrixW_zgemm('C',            /* TRANSA */
            'N',              /* TRANSB */
            A->level[0]->size,        /* M */
            B->level[0]->size,        /* N */
            B->size,            /* K */
            complex_one,          /* ALPHA */
            Ac,               /* A */
            A->size,            /* LDA */
            B->data,            /* B */
            B->size,            /* LDB */
            complex_zero,         /* BETA */
            M->data,            /* C */
            M->size);           /* LDC */
        lua_pop(L, 1); /* Ac */
      }
    }
    else {
      lua_Number *Bc = B->data;
      if (B->complex == LM_REAL) {
        /* create complex(B) */
        int Bsize = B->size * B->level[0]->size;
        Bc = (lua_Number *) lua_newuserdata(L,
            Bsize * sizeof(lua_Complex));
        matrixW_dcopy(Bsize, B->data, 1, Bc, 2);
        matrixW_dscal(Bsize, 0.0, Bc + 1, 2);
      }
      matrixW_zgemm('C',              /* TRANSA */
          'N',                /* TRANSB */
          A->level[0]->size,          /* M */
          B->level[0]->size,          /* N */
          B->size,              /* K */
          complex_one,            /* ALPHA */
          A->data,              /* A */
          A->size,              /* LDA */
          Bc,                 /* B */
          B->size,              /* LDB */
          complex_zero,           /* BETA */
          M->data,              /* C */
          M->size);             /* LDC */
      if (B->complex == LM_REAL) lua_pop(L, 1); /* allocated Bc */
    }
  }
  return M;
}


/* {====================      matrix_outer      ====================} */

/* pushes A*B' on the stack */
LUAMATRIX_API lua_Matrix *matrix_outer (lua_State *L,
    lua_Matrix *A, lua_Matrix *B) {
  lua_Matrix *M;
  matrixA_checkouter(L, A, B);
  /* =========== first case: vector and vector ========== */
  if (A->dim == 1 && B->dim == 1) {
    int Astride = (A->sup) ? A->sup->size : 1;
    int Bstride = (B->sup) ? B->sup->size : 1;
    M = matrix_pusharray(L, A->size, B->size, A->complex | B->complex);
    if (M->complex == LM_REAL)
      matrixW_dscal(A->size * B->size, 0.0, M->data, 1);
    else
      matrixW_zdscal(A->size * B->size, 0.0, M->data, 1);
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL)
        matrixW_dger(A->size,         /* M */
            A->level[0]->size,        /* N */
            1.0,              /* ALPHA */
            A->data,            /* X */
            Astride,            /* INCX */
            B->data,            /* Y */
            Bstride,            /* INCY */
            M->data,            /* A */
            M->size);           /* LDA */
      else {
        lua_Number *Ac = (lua_Number *) lua_newuserdata(L,
            A->size * sizeof(lua_Complex));
        matrixW_dcopy(A->size, A->data, Astride, Ac, 2);
        matrixW_dscal(A->size, 0.0, Ac + 1, 2);
        matrixW_zgerc(A->size,          /* M */
            A->level[0]->size,        /* N */
            complex_one,          /* ALPHA */
            Ac,               /* X */
            1,                /* INCX */
            B->data,            /* Y */
            Bstride,            /* INCY */
            M->data,            /* A */
            M->size);           /* LDA */
        lua_pop(L, 1); /* allocated Ac */
      }
    }
    else {
      if (B->complex == LM_REAL) {
        lua_Number *Bc = (lua_Number *) lua_newuserdata(L,
            B->size * sizeof(lua_Complex));
        matrixW_dcopy(B->size, B->data, Bstride, Bc, 2);
        matrixW_dscal(B->size, 0.0, Bc + 1, 2);
        matrixW_zgerc(A->size,          /* M */
            A->level[0]->size,        /* N */
            complex_one,          /* ALPHA */
            A->data,            /* X */
            Astride,            /* INCX */
            Bc,               /* Y */
            1,                /* INCY */
            M->data,            /* A */
            M->size);           /* LDA */
        lua_pop(L, 1); /* allocated Bc */
      }
      else
        matrixW_zgerc(A->size,          /* M */
            A->level[0]->size,        /* N */
            complex_one,          /* ALPHA */
            A->data,            /* X */
            Astride,            /* INCX */
            B->data,            /* Y */
            Bstride,            /* INCY */
            M->data,            /* A */
            M->size);           /* LDA */
    }
    return M;
  }
  /* =========== second case: array and vector =========== */
  if (A->dim == 1 || B->dim == 1) {
    lua_Matrix *a, *b;
    int stride;
    if (A->dim == 1) {
      a = B; b = A;
    }
    else {
      a = A; b = B;
    }
    M = matrix_pushvector(L, a->size, a->complex | b->complex);
    stride = matrix_stride(b);
    if (istype_triangular(a)) {
      char uplo = istype_upper(a) ? LM_TAG_UPPER : LM_TAG_LOWER;
      if (a->complex == LM_REAL) {
        if (b->complex == LM_REAL) {
          /* copy b->data */
          matrixW_dcopy(b->size, b->data, stride, M->data, 1);
          matrixW_dtrmv(uplo,         /* UPLO */
                'N',          /* TRANS */
                'N',          /* DIAG */
                b->size,        /* N */
                a->data,        /* A */
                a->size,        /* LDA */
                M->data,        /* X */
                1);           /* INCX */
        }
        else {
          /* copy b->data */
          matrixW_zcopy(b->size, b->data, stride, M->data, 1);
          /* conjugate */
          matrixW_dscal(M->size, -1.0, M->data + 1, 2);
          /* real part */
          matrixW_dtrmv(uplo,         /* UPLO */
                'N',          /* TRANS */
                'N',          /* DIAG */
                b->size,        /* N */
                a->data,        /* A */
                a->size,        /* LDA */
                M->data,        /* X */
                2);           /* INCX */
          /* imag part */
          matrixW_dtrmv(uplo,         /* UPLO */
                'N',          /* TRANS */
                'N',          /* DIAG */
                b->size,        /* N */
                a->data,        /* A */
                a->size,        /* LDA */
                M->data + 1,      /* X */
                2);           /* INCX */
        }
      }
      else {
        /* copy b->data */
        if (b->complex == LM_REAL) {
          matrixW_dcopy(b->size, b->data, stride, M->data, 2);
          matrixW_dscal(b->size, 0.0, M->data + 1, 2);
        }
        else {
          matrixW_zcopy(b->size, b->data, stride, M->data, 1);
          matrixW_dscal(M->size, -1.0, M->data + 1, 2); /* conj */
        }
        matrixW_ztrmv(uplo,           /* UPLO */
              'N',            /* TRANS */
              'N',            /* DIAG */
              b->size,          /* N */
              a->data,          /* A */
              a->size,          /* LDA */
              M->data,          /* X */
              1);             /* INCX */
      }
    }
    else if (istype_symmetric(a)) {
      if (a->complex == LM_REAL) {
        if (b->complex == LM_REAL)
          matrixW_dsymv('U',          /* UPLO */
              b->size,          /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              stride,           /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        else {
          /* real part */
          matrixW_dsymv('U',          /* UPLO */
              b->size,          /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              2);             /* INCY */
          /* imag part */
          matrixW_dsymv('U',          /* UPLO */
              b->size,          /* N */
              -1.0,           /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data + 1,        /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data + 1,        /* Y */
              2);             /* INCY */
        }
      }
      else {
        lua_Number *bc = (lua_Number *) lua_newuserdata(L,
            b->size * sizeof(lua_Complex));
        if (b->complex == LM_REAL) { /* copy b */
          matrixW_dcopy(b->size, b->data, stride, bc, 2);
          matrixW_dscal(b->size, 0.0, bc + 1, 2);
        }
        else { /* conjugate */
          matrixW_zcopy(b->size, b->data, stride, bc, 1);
          matrixW_dscal(b->size, -1.0, bc + 1, 2);
        }
        if (b->dim == 1)
          matrixW_zhemv('U',          /* UPLO */
              b->size,          /* N */
              complex_one,        /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              bc,             /* X */
              1,              /* INCX */
              complex_zero,       /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        else
          matrixW_zhemm('R',          /* SIDE */
              'U',            /* UPLO */
              1,              /* M */
              b->size,          /* N */
              complex_one,        /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              bc,             /* X */
              1,              /* INCX */
              complex_zero,       /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        lua_pop(L, 1); /* allocated bc */
      }
    }
    else { /* general or posdef */
      if (a->complex == LM_REAL) {
        if (b->complex == LM_REAL)
          matrixW_dgemv('N',          /* TRANS */
              a->size,          /* M */
              a->level[0]->size,      /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              stride,           /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              1);             /* INCY */
        else {
          /* real part */
          matrixW_dgemv('N',          /* TRANS */
              a->size,          /* M */
              a->level[0]->size,      /* N */
              1.0,            /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data,          /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data,          /* Y */
              2);             /* INCY */
          /* imag part */
          matrixW_dgemv('N',          /* TRANS */
              a->size,          /* M */
              a->level[0]->size,      /* N */
              -1.0,           /* ALPHA */
              a->data,          /* A */
              a->size,          /* LDA */
              b->data + 1,        /* X */
              2 * stride,         /* INCX */
              0.0,            /* BETA */
              M->data + 1,        /* Y */
              2);             /* INCY */
        }
      }
      else {
        lua_Number *bc = (lua_Number *) lua_newuserdata(L,
              b->size * sizeof(lua_Complex));
        if (b->complex == LM_REAL) { /* copy b */
          matrixW_dcopy(b->size, b->data, stride, bc, 2);
          matrixW_dscal(b->size, 0.0, bc + 1, 2);
        }
        else { /* conjugate */
          matrixW_zcopy(b->size, b->data, stride, bc, 1);
          matrixW_dscal(b->size, -1.0, bc + 1, 2);
        }
        matrixW_zgemv('N',            /* TRANS */
            a->size,            /* M */
            a->level[0]->size,        /* N */
            complex_one,          /* ALPHA */
            a->data,            /* A */
            a->size,            /* LDA */
            bc,               /* X */
            1,                /* INCX */
            complex_zero,         /* BETA */
            M->data,            /* Y */
            1);               /* INCY */
        lua_pop(L, 1); /* allocated bc */
      }
    }
    /* conjugate result if applicable */
    if (A->dim == 1 && M->complex == LM_COMPLEX)
      matrixW_dscal(M->size, -1.0, M->data + 1, 2);
    return M;
  }
  /* =========== last case: array and array =========== */
  M = matrix_pusharray(L, A->size, B->size, A->complex | B->complex);
  M->type = A->type;
  if (A != B) {
    /* transpose B type */
    if ((B->type ^ LM_UPPER) & LM_LOWER) /* strictly lower? */
      settype_upper(M);
    else if ((B->type ^ LM_LOWER) & LM_UPPER) /* strictly upper? */
      settype_lower(M);
    M->type &= A->type; /* common types */
    M->type &= ~LM_POSDEF; /* POSDEF off */
  }
  else M->type = LM_SYMMETRIC;
  if (istype_triangular(B)) {
    char uplo = istype_upper(B) ? LM_TAG_UPPER : LM_TAG_LOWER;
    int size = A->size * A->level[0]->size;
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL) {
        matrixW_dcopy(size, A->data, 1, M->data, 1);
        matrixW_dtrmm('R',            /* SIDE */
            uplo,             /* UPLO */
            'C',              /* TRANSA */
            'N',              /* DIAG */
            A->size,            /* M */
            A->level[0]->size,        /* N */
            1.0,              /* ALPHA */
            B->data,            /* A */
            B->size,            /* LDA */
            M->data,            /* B */
            M->size);           /* LDB */
      }
      else {
        matrixW_dcopy(size, A->data, 1, M->data, 2);
        matrixW_dscal(size, 0.0, M->data + 1, 2);
        matrixW_ztrmm('R',            /* SIDE */
            uplo,             /* UPLO */
            'C',              /* TRANSA */
            'N',              /* DIAG */
            A->size,            /* M */
            A->level[0]->size,        /* N */
            complex_one,          /* ALPHA */
            B->data,            /* A */
            B->size,            /* LDA */
            M->data,            /* B */
            M->size);           /* LDB */
      }
    }
    else {
      lua_Number *Bc = B->data;
      if (B->complex == LM_REAL) {
        int bsize = B->size * B->level[0]->size;
        Bc = (lua_Number *) lua_newuserdata(L,
          bsize * sizeof(lua_Complex)); 
        matrixW_dcopy(bsize, B->data, 1, Bc, 2);
        matrixW_dscal(bsize, 0.0, Bc + 1, 2);
      }
      matrixW_zcopy(size, A->data, 1, M->data, 1);
      matrixW_ztrmm('R',              /* SIDE */
          uplo,               /* UPLO */
          'C',                /* TRANSA */
          'N',                /* DIAG */
          A->size,              /* M */
          A->level[0]->size,          /* N */
          complex_one,            /* ALPHA */
          Bc,                 /* A */
          B->size,              /* LDA */
          M->data,              /* B */
          M->size);             /* LDB */
      if (B->complex == LM_REAL) lua_pop(L, 1); /* allocated Bc */
    }
  }
  else if (A == B) {
    int i = 0, s = 0;
    if (A->complex == LM_REAL) {
      matrixW_dsyrk('L',              /* UPLO */
          'N',                /* TRANS */
          A->size,              /* N */
          A->level[0]->size,          /* K */
          1.0,                /* ALPHA */
          A->data,              /* A */
          A->size,              /* LDA */
          0.0,                /* BETA */
          M->data,              /* C */
          M->size);             /* LDC */
      /* reflect columns to rows */
      for ( ; i < M->size - 1; i++, s += M->size)
        matrixW_dcopy(M->size - i - 1,
            M->data + s + i + 1, 1,
            M->data + s + i + M->size, M->size);
    }
    else {
      matrixW_zherk('L',              /* UPLO */
          'N',                /* TRANS */
          A->size,              /* N */
          A->level[0]->size,          /* K */
          1.0,                /* ALPHA */
          A->data,              /* A */
          A->size,              /* LDA */
          0.0,                /* BETA */
          M->data,              /* C */
          M->size);             /* LDC */
      /* reflect columns to rows */
      for ( ; i < M->size - 1; i++, s += M->size) {
        matrixW_zcopy(M->size - i - 1,
            M->data + 2 * (s + i + 1), 1,
            M->data + 2 * (s + i + M->size), M->size);
        /* conjugate */
        matrixW_dscal(M->size - i - 1, -1.0,
            M->data + 2 * (s + i + M->size) + 1, 2 * M->size);
      }
    }
  }
  else if (istype_symmetric(B)) {
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL)
        matrixW_dsymm('R',            /* SIDE */
            'U',              /* UPLO */
            A->size,            /* M */
            B->size,            /* N */
            1.0,              /* ALPHA */
            B->data,            /* A */
            B->size,            /* LDA */
            A->data,            /* B */
            A->size,            /* LDB */
            0.0,              /* BETA */
            M->data,            /* C */
            M->size);           /* LDC */
      else {
        /* create complex(A) */
        int Asize = A->size * A->level[0]->size;
        lua_Number *Ac = (lua_Number *) lua_newuserdata(L,
              Asize * sizeof(lua_Complex));
        matrixW_dcopy(Asize, A->data, 1, Ac, 2);
        matrixW_dscal(Asize, 0.0, Ac + 1, 2);
        matrixW_zhemm('R',            /* SIDE */
            'U',              /* UPLO */
            A->size,            /* M */
            B->size,            /* N */
            complex_one,          /* ALPHA */
            B->data,            /* A */
            B->size,            /* LDA */
            Ac,               /* B */
            A->size,            /* LDB */
            complex_zero,         /* BETA */
            M->data,            /* C */
            M->size);           /* LDC */
        lua_pop(L, 1); /* Ac */
      }
    }
    else {
      lua_Number *Bc = B->data;
      if (B->complex == LM_REAL) {
        int Bsize = B->size * B->level[0]->size;
        /* create complex(b) */
        Bc = (lua_Number *) lua_newuserdata(L,
            Bsize * sizeof(lua_Complex));
        matrixW_dcopy(Bsize, B->data, 1, Bc, 2);
        matrixW_dscal(Bsize, 0.0, Bc + 1, 2);
      }
      matrixW_zhemm('R',              /* SIDE */
          'U',                /* UPLO */
          A->size,              /* M */
          B->size,              /* N */
          complex_one,            /* ALPHA */
          Bc,                 /* A */
          B->size,              /* LDA */
          A->data,              /* B */
          A->size,              /* LDB */
          complex_zero,           /* BETA */
          M->data,              /* C */
          M->size);             /* LDC */
      if (B->complex == LM_REAL) lua_pop(L, 1); /* allocated Bc */
    }
  }
  else { /* general or posdef */
    if (A->complex == LM_REAL) {
      if (B->complex == LM_REAL)
        matrixW_dgemm('N',            /* TRANSA */
            'C',              /* TRANSB */
            A->size,            /* M */
            B->size,            /* N */
            B->level[0]->size,        /* K */
            1.0,              /* ALPHA */
            A->data,            /* A */
            A->size,            /* LDA */
            B->data,            /* B */
            B->size,            /* LDB */
            0.0,              /* BETA */
            M->data,            /* C */
            M->size);           /* LDC */
      else {
        /* create complex(A) */
        int Asize = A->size * A->level[0]->size;
        lua_Number *Ac = (lua_Number *) lua_newuserdata(L,
              Asize * sizeof(lua_Complex));
        matrixW_dcopy(Asize, A->data, 1, Ac, 2);
        matrixW_dscal(Asize, 0.0, Ac + 1, 2);
        matrixW_zgemm('N',            /* TRANSA */
            'C',              /* TRANSB */
            A->size,            /* M */
            B->size,            /* N */
            B->level[0]->size,        /* K */
            complex_one,          /* ALPHA */
            Ac,               /* A */
            A->size,            /* LDA */
            B->data,            /* B */
            B->size,            /* LDB */
            complex_zero,         /* BETA */
            M->data,            /* C */
            M->size);           /* LDC */
        lua_pop(L, 1); /* Ac */
      }
    }
    else {
      lua_Number *Bc = B->data;
      if (B->complex == LM_REAL) {
        /* create complex(B) */
        int Bsize = B->size * B->level[0]->size;
        Bc = (lua_Number *) lua_newuserdata(L,
            Bsize * sizeof(lua_Complex));
        matrixW_dcopy(Bsize, B->data, 1, Bc, 2);
        matrixW_dscal(Bsize, 0.0, Bc + 1, 2);
      }
      matrixW_zgemm('N',              /* TRANSA */
          'C',                /* TRANSB */
          A->size,              /* M */
          B->size,              /* N */
          B->level[0]->size,          /* K */
          complex_one,            /* ALPHA */
          A->data,              /* A */
          A->size,              /* LDA */
          Bc,                 /* B */
          B->size,              /* LDB */
          complex_zero,           /* BETA */
          M->data,              /* C */
          M->size);             /* LDC */
      if (B->complex == LM_REAL) lua_pop(L, 1); /* allocated Bc */
    }
  }
  return M;
}


/* {====================     Functional     ========================} */

/* apply a function at top of stack to each entry of a matrix */
LUAMATRIX_API void matrix_map (lua_State *L, lua_Matrix *M) {
  int i;
  int stride = matrix_stride(M); 
  int size = matrixA_datasize(M) * stride;
  if (M->complex == LM_REAL) {
    for (i = 0; i < size; i += stride) {
      lua_pushvalue(L, -1); /* function */
      lua_pushnumber(L, M->data[i]); /* entry */
      lua_call(L, 1, 1);
      if (lua_isnumber(L, -1))
        M->data[i] = lua_tonumber(L, -1);
      lua_pop(L, 1);  /* value from call */
    }
  }
  else {
    lua_Complex *c;
    size *= 2;
    stride *= 2;
    for (i = 0; i < size; i += stride) {
      lua_pushvalue(L, -1); /* function */
      complex_push(L, M->data[i], M->data[i + 1]); /* entry */
      lua_call(L, 1, 1);
      if (complex_checktype(L, -1)) {
        c = complex_to(L, -1);
        M->data[i] = c->r;
        M->data[i + 1] = c->i;
      }
      else if (lua_isnumber(L, -1)) {
        M->data[i] = lua_tonumber(L, -1);
        M->data[i + 1] = 0;
      }
      lua_pop(L, 1);  /* value from call */
    }
  }
  lua_pop(L, 1);  /* function */
  M->type = LM_GENERAL; /* reset type */
}

/* apply a function F (at position -2) to each entry and partial result. F
 * should ideally be a commutative and associative operator on 2 elements.
 * An initial value should be at top of stack. */
LUAMATRIX_API void matrix_reduce (lua_State *L, lua_Matrix *M) {
  int i;
  int stride = matrix_stride(M);
  int size = matrixA_datasize(M) * stride;
  if (M->complex == LM_REAL) {
    for (i = 0; i < size; i += stride) {
      lua_pushvalue(L, -2); /* function */
      lua_insert(L, -2);
      lua_pushnumber(L, M->data[i]); /* entry */
      lua_call(L, 2, 1);
    }
  }
  else {
    size *= 2;
    stride *= 2;
    for (i = 0; i < size; i += stride) {
      lua_pushvalue(L, -2); /* function */
      lua_insert(L, -2);
      complex_push(L, M->data[i], M->data[i + 1]); /* entry */
      lua_call(L, 2, 1);
    }
  }
}

