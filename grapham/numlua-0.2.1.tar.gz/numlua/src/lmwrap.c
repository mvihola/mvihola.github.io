/* {=================================================================
 * 
 * BLAS/LAPACK wrapping for Matrix library
 * See Copyright Notice in luamatrix.h
 * $Id: lmwrap.c,v 1.3 2006-09-11 02:25:38 carvalho Exp $
 * 
 * ==================================================================} */

#include "lmwrap.h"

/* {=================================================================
 *    BLAS                      Level 1
 * ==================================================================} */

/* xSCAL: y <- alpha*x */
int matrixW_dscal (int n, lua_Number alpha, lua_Number *x, int incx) {
  return dscal_(&n, &alpha, x, &incx);
}

int matrixW_zdscal (int n, lua_Number alpha, lua_Number *x, int incx) {
  return zdscal_(&n, &alpha, (lua_Complex *) x, &incx);
}

/* xAXPY: y <- alpha*x + y */
int matrixW_daxpy (int n, lua_Number alpha, lua_Number *x, int incx,
    lua_Number *y, int incy) {
  return daxpy_(&n, &alpha, x, &incx, y, &incy);
}

int matrixW_zaxpy (int n, lua_Complex alpha, lua_Number *x, int incx,
    lua_Number* y, int incy) {
  return zaxpy_(&n, &alpha, (lua_Complex *) x, &incx,
      (lua_Complex *) y, &incy);
}

/* DDOT: dot <- x^T y */
lua_Number matrixW_ddot (int n, lua_Number *x, int incx,
    lua_Number *y, int incy) {
  return ddot_(&n, x, &incx, y, &incy);
}

/* ZDOTC: dot <- x^H y */
void matrixW_zdotc (lua_Complex *retval, int n, lua_Number *x, int incx,
    lua_Number *y, int incy) {
  zdotc_(retval, &n, (lua_Complex *) x, &incx, (lua_Complex *) y, &incy);
}

/* ZDOTU: dot <- x^T y */
void matrixW_zdotu (lua_Complex *retval, int n, lua_Number *x, int incx,
    lua_Number *y, int incy) {
  zdotu_(retval, &n, (lua_Complex *) x, &incx, (lua_Complex *) y, &incy);
}

/* xCOPY: y <- x */
int matrixW_dcopy (int n, lua_Number *x, int incx, lua_Number *y, int incy) {
  return dcopy_(&n, x, &incx, y, &incy);
}

int matrixW_zcopy (int n, lua_Number *x, int incx, lua_Number *y, int incy) {
  return zcopy_(&n, (lua_Complex *) x, &incx, (lua_Complex *) y, &incy);
}

int matrixW_dswap (int n, lua_Number *x, int incx, lua_Number *y, int incy) {
  return dswap_(&n, x, &incx, y, &incy);
}

int matrixW_zswap (int n, lua_Number *x, int incx, lua_Number *y, int incy) {
  return zswap_(&n, (lua_Complex *) x, &incx, (lua_Complex *) y, &incy);
}

int matrixW_idamax (int n, lua_Number *x, int incx) {
  return idamax_(&n, x, &incx);
}

int matrixW_izamax (int n, lua_Number *x, int incx) {
  return izamax_(&n, (lua_Complex *) x, &incx);
}


/* {=================================================================
 *    BLAS                      Level 2
 * ==================================================================} */

/* xGEMV: y <- alpha*op(A)*x + beta*y, A(m, n)
 * GEMV (TRANS, M, N, ALPHA, A, LDA, X, INCX, BETA, Y, INCY ) */
int matrixW_dgemv (char trans, int m, int n, lua_Number alpha,
    lua_Number *A, int lda, lua_Number *x, int incx, lua_Number beta,
    lua_Number *y, int incy) {
  return dgemv_(&trans, &m, &n, &alpha, A, &lda, x, &incx, &beta,
      y, &incy, 1);
}

int matrixW_zgemv (char trans, int m, int n, lua_Complex alpha,
    lua_Number *A, int lda, lua_Number *x, int incx, lua_Complex beta,
    lua_Number *y, int incy) {
  return zgemv_(&trans, &m, &n, &alpha, (lua_Complex *) A, &lda,
      (lua_Complex *) x, &incx, &beta, (lua_Complex *) y, &incy, 1);
}

/* xSYMV: y <- alpha*A*x + beta*y, A symmetric
 * DSYMV ( UPLO, N, ALPHA, A, LDA, X, INCX, BETA, Y, INCY ) */
int matrixW_dsymv (char uplo, int n, lua_Number alpha, lua_Number *A, int lda,
    lua_Number *x, int incx, lua_Number beta, lua_Number *y, int incy) {
  return dsymv_(&uplo, &n, &alpha, A, &lda, x, &incx, &beta, y, &incy, 1);
}

/* xHEMV: y <- alpha*A*x + beta*y, A hermitian
 * ZHEMV ( UPLO, N, ALPHA, A, LDA, X, INCX, BETA, Y, INCY ) */
int matrixW_zhemv (char uplo, int n, lua_Complex alpha, lua_Number *A, int lda,
    lua_Number *x, int incx, lua_Complex beta, lua_Number *y, int incy) {
  return zhemv_(&uplo, &n, &alpha, (lua_Complex *) A, &lda,
      (lua_Complex *) x, &incx, &beta, (lua_Complex *) y, &incy, 1);
}

/* xTRMV: x <- op(A)*x, A triangular
 * TRMV ( UPLO, TRANS, DIAG, N, A, LDA, X, INCX ) */
int matrixW_dtrmv (char uplo, char trans, char diag, int n,
    lua_Number *A, int lda, lua_Number *x, int incx) {
  return dtrmv_(&uplo, &trans, &diag, &n, A, &lda, x, &incx, 1, 1, 1);
}

int matrixW_ztrmv (char uplo, char trans, char diag, int n,
    lua_Number *A, int lda, lua_Number *x, int incx) {
  return ztrmv_(&uplo, &trans, &diag, &n, (lua_Complex *) A, &lda,
      (lua_Complex *) x, &incx, 1, 1, 1);
}

/* xTRSV: x <- op(A^-1)*x, A triangular
 * TRSV ( UPLO, TRANS, DIAG, N, A, LDA, X, INCX ) */
int matrixW_dtrsv (char uplo, char trans, char diag, int n,
    lua_Number *A, int lda, lua_Number *x, int incx) {
  return dtrsv_(&uplo, &trans, &diag, &n, A, &lda, x, &incx, 1, 1, 1);
}

int matrixW_ztrsv (char uplo, char trans, char diag, int n,
    lua_Number *A, int lda, lua_Number *x, int incx) {
  return ztrsv_(&uplo, &trans, &diag, &n, (lua_Complex *) A, &lda,
      (lua_Complex *) x, &incx, 1, 1, 1);
}

/* xGER: A <- alpha*x*y^T + A, A(m, n)
 * DGER ( M, N, ALPHA, X, INCX, Y, INCY, A, LDA ) */
int matrixW_dger (int m, int n, lua_Number alpha, lua_Number *x, int incx,
    lua_Number *y, int incy, lua_Number *A, int lda) {
  return dger_(&m, &n, &alpha, x, &incx, y, &incy, A, &lda);
}

/* xGERC: A <- alpha*x*y^H + A, A(m, n)
 * ZGERC ( M, N, ALPHA, X, INCX, Y, INCY, A, LDA ) */
int matrixW_zgerc (int m, int n, lua_Complex alpha, lua_Number *x, int incx,
    lua_Number *y, int incy, lua_Number *A, int lda) {
  return zgerc_(&m, &n, &alpha, (lua_Complex *) x, &incx,
      (lua_Complex *) y, &incy, (lua_Complex *) A, &lda);
}

/* xSYR: A <- alpha*x*x^T + A, A(n, n)
 * DSYR ( UPLO, N, ALPHA, X, INCX, A, LDA ) */
int matrixW_dsyr (char uplo, int n, lua_Number alpha, lua_Number *x, int incx,
    lua_Number *A, int lda) {
  return dsyr_(&uplo, &n, &alpha, x, &incx, A, &lda, 1);
}

/* xHER: A <- alpha*x*x^H + A, A(n, n)
 * ZHER ( UPLO, N, ALPHA, X, INCX, A, LDA ) */
int matrixW_zher (char uplo, int n, lua_Number alpha, lua_Number *x, int incx,
    lua_Number *A, int lda) {
  return zher_(&uplo, &n, &alpha, (lua_Complex *) x, &incx,
      (lua_Complex *) A, &lda, 1);
}


/* {=================================================================
 *    BLAS                      Level 3
 * ==================================================================} */

/* xGEMM: C <- alpha*op(A)*op(B) + beta*C, C(m, n)
 * GEMM ( TRANSA, TRANSB, M, N, K, ALPHA, A, LDA, B, LDB, BETA, C, LDC ) */
int matrixW_dgemm (char transA, char transB, int m, int n, int k,
    lua_Number alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb, lua_Number beta,
    lua_Number *C, int ldc) {
  return dgemm_(&transA, &transB, &m, &n, &k, &alpha, A, &lda,
      B, &ldb, &beta, C, &ldc, 1, 1);
}

int matrixW_zgemm (char transA, char transB, int m, int n, int k,
    lua_Complex alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb, lua_Complex beta,
    lua_Number *C, int ldc) {
  return zgemm_(&transA, &transB, &m, &n, &k, &alpha,
      (lua_Complex *) A, &lda,
      (lua_Complex *) B, &ldb, &beta,
      (lua_Complex *) C, &ldc, 1, 1);
}

/* xSYMM: C <- alpha*A*B + beta*C || alpha*B*A + beta*C, C(m, n), A symm.
 * DSYMM ( SIDE, UPLO, M, N, ALPHA, A, LDA, B, LDB, BETA, C, LDC ) */
int matrixW_dsymm (char side, char uplo, int m, int n,
    lua_Number alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb, lua_Number beta,
    lua_Number *C, int ldc) {
  return dsymm_(&side, &uplo, &m, &n, &alpha, A, &lda, B, &ldb, &beta,
      C, &ldc, 1, 1);
}

/* xHEMM: C <- alpha*A*B + beta*C || alpha*B*A + beta*C, C(m, n), A herm.
 * ZHEMM ( SIDE, UPLO, M, N, ALPHA, A, LDA, B, LDB, BETA, C, LDC ) */
int matrixW_zhemm (char side, char uplo, int m, int n,
    lua_Complex alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb, lua_Complex beta,
    lua_Number *C, int ldc) {
  return zhemm_(&side, &uplo, &m, &n, &alpha, (lua_Complex *) A, &lda,
      (lua_Complex *) B, &ldb, &beta,
      (lua_Complex *) C, &ldc, 1, 1);
}

/* xSYRK: C <- alpha*A*A^T + beta*C || alpha*A^T*A + beta*C, C(n, n)
 * DSYRK ( UPLO, TRANS, N, K, ALPHA, A, LDA, BETA, C, LDC ) */
int matrixW_dsyrk (char uplo, char trans, int n, int k, lua_Number alpha,
    lua_Number *A, int lda, lua_Number beta, lua_Number *C, int ldc) {
  return dsyrk_(&uplo, &trans, &n, &k, &alpha, A, &lda, &beta, C, &ldc, 1, 1);
}

/* xHERK: C <- alpha*A*A^T + beta*C || alpha*A^T*A + beta*C, C(n, n)
 * ZHERK ( UPLO, TRANS, N, K, ALPHA, A, LDA, BETA, C, LDC ) */
int matrixW_zherk (char uplo, char trans, int n, int k, lua_Number alpha,
    lua_Number *A, int lda, lua_Number beta, lua_Number *C, int ldc) {
  return zherk_(&uplo, &trans, &n, &k, &alpha, (lua_Complex *) A, &lda,
      &beta, (lua_Complex *) C, &ldc, 1, 1);
}

/* xTRMM: B <- alpha*op(A)*B || alpha*B*op(A), B(m, n)
 * TRMM ( SIDE, UPLO, TRANSA, DIAG, M, N, ALPHA, A, LDA, B, LDB ) */
int matrixW_dtrmm (char side, char uplo, char transA, char diag,
    int m, int n, lua_Number alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb) {
  return dtrmm_(&side, &uplo, &transA, &diag, &m, &n, &alpha, A, &lda,
      B, &ldb, 1, 1, 1, 1);
}

int matrixW_ztrmm (char side, char uplo, char transA, char diag,
    int m, int n, lua_Complex alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb) {
  return ztrmm_(&side, &uplo, &transA, &diag, &m, &n, &alpha,
      (lua_Complex *) A, &lda, (lua_Complex *) B, &ldb, 1, 1, 1, 1);
}

/* xTRSM: B <- alpha*op(A^-1)*B || alpha*B*op(A^-1), B(m, n)
 * TRSM ( SIDE, UPLO, TRANSA, DIAG, M, N, ALPHA, A, LDA, B, LDB ) */
int matrixW_dtrsm (char side, char uplo, char transA, char diag,
    int m, int n, lua_Number alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb) {
  return dtrsm_(&side, &uplo, &transA, &diag, &m, &n, &alpha, A, &lda,
      B, &ldb, 1, 1, 1, 1);
}

int matrixW_ztrsm (char side, char uplo, char transA, char diag,
    int m, int n, lua_Complex alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb) {
  return ztrsm_(&side, &uplo, &transA, &diag, &m, &n, &alpha, 
      (lua_Complex *) A, &lda, (lua_Complex *) B, &ldb, 1, 1, 1, 1);
}


/* {=================================================================
 *    LAPACK                  Internals
 * ==================================================================} */

/* DLAMCH - determine double precision machine parameters */
lua_Number matrixW_dlamch (char cmach) {
  return dlamch_(&cmach, 1);
}

/* xLANGE - return the value of the one norm, or the Frobenius norm, or the
 * infinity norm, or the element of largest absolute value of a real [complex]
 * matrix A */
lua_Number matrixW_dlange (char norm, int m, int n, lua_Number *A, int lda,
    lua_Number *work) {
  return dlange_(&norm, &m, &n, A, &lda, work, 1);
}

lua_Number matrixW_zlange (char norm, int m, int n, lua_Number *A, int lda,
    lua_Number *work) {
  return zlange_(&norm, &m, &n, (lua_Complex *) A, &lda, work, 1);
}

/* xLASET - initialize an m-by-n matrix A to BETA on the diagonal and
 * ALPHA on the offdiagonals */
int matrixW_dlaset (char uplo, int m, int n, lua_Number alpha,
    lua_Number beta, lua_Number *A, int lda) {
  return dlaset_(&uplo, &m, &n, &alpha, &beta, A, &lda, 1);
}
int matrixW_zlaset (char uplo, int m, int n, lua_Complex alpha,
    lua_Complex beta, lua_Number *A, int lda) {
  return zlaset_(&uplo, &m, &n, &alpha, &beta, (lua_Complex *) A, &lda, 1);
}


/* {=================================================================
 *    LAPACK                  General
 * ==================================================================} */

/* xGEBAL - balance a general real [complex] matrix A */
int matrixW_dgebal (char job, int n, lua_Number *A, int lda,
    int *ilo, int *ihi, lua_Number *scale, int *info) {
  return dgebal_(&job, &n, A, &lda, ilo, ihi, scale, info, 1);
}

int matrixW_zgebal (char job, int n, lua_Number *A, int lda,
    int *ilo, int *ihi, lua_Number *scale, int *info) {
  return zgebal_(&job, &n, (lua_Complex *) A, &lda, ilo, ihi, scale, info, 1);
}

/* xGECON - estimate the reciprocal of the condition number of a general real
 * [complex] matrix A, in either the 1-norm or the infinity-norm, using the LU
 * factorization computed by xGETRF */
int matrixW_dgecon (char norm, int n, lua_Number *A, int lda,
    lua_Number anorm, lua_Number *rcond, lua_Number *work,
    int *iwork, int *info) {
  return dgecon_(&norm, &n, A, &lda, &anorm, rcond, work, iwork, info, 1);
}

int matrixW_zgecon (char norm, int n, lua_Number *A, int lda,
    lua_Number anorm, lua_Number *rcond, lua_Number *work,
    lua_Number *rwork, int *info) {
  return zgecon_(&norm, &n, (lua_Complex *) A, &lda, &anorm, rcond,
      (lua_Complex *) work, rwork, info, 1);
}

/* xGETRF - compute an LU factorization of a general M-by-N matrix A using
 * partial pivoting with row interchanges */
int matrixW_dgetrf (int m, int n, lua_Number *A, int lda, int *ipiv,
    int *info) {
  return dgetrf_(&m, &n, A, &lda, ipiv, info);
}

int matrixW_zgetrf (int m, int n, lua_Number *A, int lda, int *ipiv,
    int *info) {
  return zgetrf_(&m, &n, (lua_Complex *) A, &lda, ipiv, info);
}

/* xGETRI - compute the inverse of a matrix using the LU factorization
 * computed by xGETRF */
int matrixW_dgetri (int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int lwork, int *info) {
  return dgetri_(&n, A, &lda, ipiv, work, &lwork, info);
}

int matrixW_zgetri (int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int lwork, int *info) {
  return zgetri_(&n, (lua_Complex *) A, &lda, ipiv, (lua_Complex *) work,
      &lwork, info);
}

/* xGETRS - solve a system of linear equations A * X = B or A**T * X = B with
 * a general N-by-N matrix A using the LU factorization computed by xGETRF */
int matrixW_dgetrs (char trans, int n, int nrhs, lua_Number *A, int lda,
    int *ipiv, lua_Number *B, int ldb, int *info) {
  return dgetrs_(&trans, &n, &nrhs, A, &lda, ipiv, B, &ldb, info, 1);
}

int matrixW_zgetrs (char trans, int n, int nrhs, lua_Number *A, int lda,
    int *ipiv, lua_Number *B, int ldb, int *info) {
  return zgetrs_(&trans, &n, &nrhs, (lua_Complex *) A, &lda, ipiv,
      (lua_Complex *) B, &ldb, info, 1);
}

/* xGESVD - compute the singular value decomposition (SVD) of a real [complex]
 * M-by-N matrix A, optionally computing the left and/or right singular
 * vectors */
int matrixW_dgesvd (char jobu, char jobvt, int m, int n, lua_Number *A,
    int lda, lua_Number *S, lua_Number *U, int ldu, lua_Number *Vt,
    int ldvt, lua_Number *work, int lwork, int *info) {
  return dgesvd_(&jobu, &jobvt, &m, &n, A, &lda, S, U, &ldu, Vt, &ldvt,
        work, &lwork, info, 1, 1);
}

int matrixW_zgesvd (char jobu, char jobvt, int m, int n, lua_Number *A,
    int lda, lua_Number *S, lua_Number *U, int ldu, lua_Number *Vt,
    int ldvt, lua_Number *work, int lwork, lua_Number *rwork, int *info) {
  return zgesvd_(&jobu, &jobvt, &m, &n, (lua_Complex *) A, &lda, S,
        (lua_Complex *) U, &ldu, (lua_Complex *) Vt, &ldvt,
        (lua_Complex *) work, &lwork, rwork, info, 1, 1);
}

/* xGELSY  - compute the minimum-norm solution to a real [complex] linear
 * least squares problem using complete orthogonal decomposition */
int matrixW_dgelsy (int m, int n, int nrhs, lua_Number *A, int lda,
    lua_Number *B, int ldb, int *jpvt, lua_Number rcond, int *rank,
    lua_Number *work, int lwork, int *info) {
  return dgelsy_(&m, &n, &nrhs, A, &lda, B, &ldb, jpvt, &rcond, rank,
      work, &lwork, info);
}

int matrixW_zgelsy (int m, int n, int nrhs, lua_Number *A, int lda,
    lua_Number *B, int ldb, int *jpvt, lua_Number rcond, int *rank,
    lua_Number *work, int lwork, lua_Number *rwork, int *info) {
  return zgelsy_(&m, &n, &nrhs, (lua_Complex *) A, &lda,
      (lua_Complex *) B, &ldb, jpvt, &rcond, rank, (lua_Complex *) work,
      &lwork, rwork, info);
}

/* xGELSS  - compute the minimum norm solution to a real [complex] linear
 * least squares problem using SVD decomposition */
int matrixW_dgelss (int m, int n, int nrhs, lua_Number *A,
    int lda, lua_Number *B, int ldb, lua_Number *s,
    lua_Number rcond, int *rank, lua_Number *work, int lwork,
    int *info) {
  return dgelss_(&m, &n, &nrhs, A, &lda, B, &ldb, s, &rcond, rank, work,
      &lwork, info);
}

int matrixW_zgelss (int m, int n, int nrhs, lua_Number *A,
    int lda, lua_Number *B, int ldb, lua_Number *s,
    lua_Number rcond, int *rank, lua_Number *work, int lwork,
    lua_Number *rwork, int *info) {
  return zgelss_(&m, &n, &nrhs, (lua_Complex *) A, &lda,
      (lua_Complex *) B, &ldb, s, &rcond, rank, (lua_Complex *) work,
      &lwork, rwork, info);
}

/* xGEQRF - compute a QR factorization of a real [complex] M-by-N matrix A */
int matrixW_dgeqrf (int m, int n, lua_Number *A, int lda, lua_Number *tau,
    lua_Number *work, int lwork, int *info) {
  return dgeqrf_(&m, &n, A, &lda, tau, work, &lwork, info);
}

int matrixW_zgeqrf (int m, int n, lua_Number *A, int lda, lua_Number *tau,
    lua_Number *work, int lwork, int *info) {
  return zgeqrf_(&m, &n, (lua_Complex *) A, &lda, (lua_Complex *) tau,
      (lua_Complex *) work, &lwork, info);
}

/* xGEQP3 - compute a QR factorization with column pivoting of a matrix A */
int matrixW_dgeqp3 (int m, int n, lua_Number *A, int lda, int *jpvt,
    lua_Number *tau, lua_Number *work, int lwork, int *info) {
  return dgeqp3_(&m, &n, A, &lda, jpvt, tau, work, &lwork, info);
}

int matrixW_zgeqp3 (int m, int n, lua_Number *A, int lda, int *jpvt,
    lua_Number *tau, lua_Number *work, int lwork, lua_Number *rwork,
    int *info) {
  return zgeqp3_(&m, &n, (lua_Complex *) A, &lda, jpvt, (lua_Complex *) tau,
      (lua_Complex *) work, &lwork, rwork, info);
}

/* xOR[UN]GQR - generate an M-by-N real [complex] matrix Q with orthonormal
 * columns */
int matrixW_dorgqr (int m, int n, int k, lua_Number *A, int lda,
    lua_Number *tau, lua_Number *work, int lwork, int *info) {
  return dorgqr_(&m, &n, &k, A, &lda, tau, work, &lwork, info);
}

int matrixW_zungqr (int m, int n, int k, lua_Number *A, int lda,
    lua_Number *tau, lua_Number *work, int lwork, int *info) {
  return zungqr_(&m, &n, &k, (lua_Complex *) A, &lda, (lua_Complex *) tau,
      (lua_Complex *) work, &lwork, info);
}

/* xOR[UN]MQR - overwrite the general real M-by-N matrix C with op(Q) * C or
 * C * op(Q) where Q is an orthogonal matrix defined as the product of k
 * elementary reflectors as returned by xGEQRF */
int matrixW_dormqr (char size, char trans, int m, int n, int k, lua_Number *A,
    int lda, lua_Number *tau, lua_Number *C, int ldc, lua_Number *work,
    int lwork, int *info) {
  return dormqr_(&size, &trans, &m, &n, &k, A, &lda, tau, C, &ldc, work,
      &lwork, info, 1, 1);
}

int matrixW_zunmqr (char size, char trans, int m, int n, int k, lua_Number *A,
    int lda, lua_Number *tau, lua_Number *C, int ldc, lua_Number *work,
    int lwork, int *info) {
  return zunmqr_(&size, &trans, &m, &n, &k, (lua_Complex *) A, &lda,
      (lua_Complex *) tau, (lua_Complex *) C, &ldc, (lua_Complex *) work,
      &lwork, info, 1, 1);
}

/* xGEEV - compute for an N-by-N real [complex] nonsymmetric matrix A, the
 * eigenvalues and, optionally, the left and/or right eigenvectors */
int matrixW_dgeev (char jobvl, char jobvr, int n, lua_Number *A, int lda,
    lua_Number *wr, lua_Number *wi, lua_Number *vl, int ldvl,
    lua_Number *vr, int ldvr, lua_Number *work, int lwork, int *info) {
  return dgeev_(&jobvl, &jobvr, &n, A, &lda, wr, wi, vl, &ldvl,
      vr, &ldvr, work, &lwork, info, 1, 1);
}

int matrixW_zgeev (char jobvl, char jobvr, int n, lua_Number *A, int lda,
    lua_Number *w, lua_Number *vl, int ldvl, lua_Number *vr, int ldvr,
    lua_Number *work, int lwork, lua_Number *rwork, int *info) {
  return zgeev_(&jobvl, &jobvr, &n, (lua_Complex *) A, &lda,
      (lua_Complex *) w, (lua_Complex *) vl, &ldvl,
      (lua_Complex *) vr, &ldvr, (lua_Complex *) work, &lwork,
      rwork, info, 1, 1);
}


/* {=================================================================
 *    LAPACK                  Posdef Symm
 * ==================================================================} */

/* xPOCON - estimate the reciprocal of the condition number (in the 1-norm) of
 * a real [complex] symmetric positive definite matrix using the Cholesky 
 * factorization A = U**H*U or A = L*L**H computed by xPOTRF */
int matrixW_dpocon (char uplo, int n, lua_Number *A, int lda,
    lua_Number anorm, lua_Number *rcond, lua_Number *work,
    int *iwork, int *info) {
  return dpocon_(&uplo, &n, A, &lda, &anorm, rcond, work, iwork, info, 1);
}

int matrixW_zpocon (char uplo, int n, lua_Number *A, int lda,
    lua_Number anorm, lua_Number *rcond, lua_Number *work,
    lua_Number *rwork, int *info) {
  return zpocon_(&uplo, &n, (lua_Complex *) A, &lda, &anorm, rcond,
      (lua_Complex *) work, rwork, info, 1);
}

/* xPOTRF - compute the Cholesky factorization of a real [complex] symmetric
 * [Hermitian] positive definite matrix A */
int matrixW_dpotrf (char uplo, int n, lua_Number *A, int lda, int *info) {
  return dpotrf_(&uplo, &n, A, &lda, info, 1);
}

int matrixW_zpotrf (char uplo, int n, lua_Number *A, int lda, int *info) {
  return zpotrf_(&uplo, &n, (lua_Complex *) A, &lda, info, 1);
}

/* xPOTRI - compute the inverse of a real [complex] symmetric [Hermitian]
 * positive definite matrix A using the Cholesky factorization A = U**H*U
 * or A = L*L**H computed by xPOTRF */
int matrixW_dpotri (char uplo, int n, lua_Number *A, int lda, int *info) {
  return dpotri_(&uplo, &n, A, &lda, info, 1);
}

int matrixW_zpotri (char uplo, int n, lua_Number *A, int lda, int *info) {
  return zpotri_(&uplo, &n, (lua_Complex *) A, &lda, info, 1);
}

/* xPOTRS - solve a system of linear equations A*X = B with a symmetric
 * [Hermitian] positive definite matrix A using the Cholesky factorization
 * A = U**H*U or A = L*L**H computed by xPOTRF */
int matrixW_dpotrs (char uplo, int n, int nrhs, lua_Number *A, int lda,
    lua_Number *B, int ldb, int *info) {
  return dpotrs_(&uplo, &n, &nrhs, A, &lda, B, &ldb, info, 1);
}

int matrixW_zpotrs (char uplo, int n, int nrhs, lua_Number *A, int lda,
    lua_Number *B, int ldb, int *info) {
  return zpotrs_(&uplo, &n, &nrhs, (lua_Complex *) A, &lda,
      (lua_Complex *) B, &ldb, info, 1);
}


/* {=================================================================
 *    LAPACK                  Symmetric
 * ==================================================================} */

/* xSY[HE]CON - estimate the reciprocal of the condition number (in the 1-norm)
 * of a real symmetric [SY] or complex Hermitian [HE] matrix A using the
 * factorization  A = U*D*U**H or A = L*D*L**H computed by xSY[HE]TRF */
int matrixW_dsycon (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number anorm, lua_Number *rcond, lua_Number *work,
    int *iwork, int *info) {
  return dsycon_(&uplo, &n, A, &lda, ipiv, &anorm, rcond, work, iwork,
      info, 1);
}

int matrixW_zhecon (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number anorm, lua_Number *rcond, lua_Number *work, int *info) {
  return zhecon_(&uplo, &n, (lua_Complex *) A, &lda, ipiv, &anorm, rcond,
      (lua_Complex *) work, info, 1);
}

/* xSY[HE]TRF - compute  the factorization of a real symmetric [SY] or complex
 * Hermitian [HE] matrix A using the Bunch-Kaufman diagonal pivoting method */
int matrixW_dsytrf (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int lwork, int *info) {
  return dsytrf_(&uplo, &n, A, &lda, ipiv, work, &lwork, info, 1);
}

int matrixW_zhetrf (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int lwork, int *info) {
  return zhetrf_(&uplo, &n, (lua_Complex *) A, &lda, ipiv,
      (lua_Complex *) work, &lwork, info, 1);
}

/* xSY[HE]TRI - compute the inverse of a real symmetric [SY] or complex
 * Hermitian [HE] indefinite matrix A using the factorization A = U*D*U**H
 * or A = L*D*L**H computed by xSY[HE]TRF */
int matrixW_dsytri (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int *info) {
  return dsytri_(&uplo, &n, A, &lda, ipiv, work, info, 1);
}

int matrixW_zhetri (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int *info) {
  return zhetri_(&uplo, &n, (lua_Complex *) A, &lda, ipiv,
      (lua_Complex *) work, info, 1);
}
 
/* xSY[HE]TRS - solve a system of linear equations A*X = B with a real
 * symmetric [SY] or complex Hermitian [HE] matrix A using the factorization
 * A = U*D*U**H or A = L*D*L**H computed by xSY[HE]TRF */
int matrixW_dsytrs (char uplo, int n, int nrhs, lua_Number *A, int lda,
    int *ipiv, lua_Number *B, int ldb, int *info) {
  return dsytrs_(&uplo, &n, &nrhs, A, &lda, ipiv, B, &ldb, info, 1);
}

int matrixW_zhetrs (char uplo, int n, int nrhs, lua_Number *A, int lda,
    int *ipiv, lua_Number *B, int ldb, int *info) {
  return zhetrs_(&uplo, &n, &nrhs, (lua_Complex *) A, &lda, ipiv,
      (lua_Complex *) B, &ldb, info, 1);
}

/* xSY[HE]EV - compute all eigenvalues and, optionally, eigenvectors of a
 * real symmetric [complex Hermitian] matrix A */
int matrixW_dsyev (char jobz, char uplo, int n, lua_Number *A, int lda,
    lua_Number *w, lua_Number *work, int lwork, int *info) {
  return dsyev_(&jobz, &uplo, &n, A, &lda, w, work, &lwork, info, 1, 1);
}

int matrixW_zheev (char jobz, char uplo, int n, lua_Number *A, int lda,
    lua_Number *w, lua_Number *work, int lwork, lua_Number *rwork,
    int *info) {
  return zheev_(&jobz, &uplo, &n, (lua_Complex *) A, &lda, w,
      (lua_Complex *) work, &lwork, rwork, info, 1, 1);
}


/* {=================================================================
 *    LAPACK                  Triangular
 * ==================================================================} */

/* xTRCON - estimate the reciprocal of the condition number of a triangular
 * matrix A, in either the 1-norm or the infinity-norm */
int matrixW_dtrcon (char norm, char uplo, char diag, int n,
    lua_Number *A, int lda, lua_Number *rcond, lua_Number *work,
    int *iwork, int *info) {
  return dtrcon_(&norm, &uplo, &diag, &n, A, &lda, rcond, work, iwork,
      info, 1, 1, 1);
}

int matrixW_ztrcon (char norm, char uplo, char diag, int n,
    lua_Number *A, int lda, lua_Number *rcond, lua_Number *work,
    lua_Number *rwork, int *info) {
  return ztrcon_(&norm, &uplo, &diag, &n, (lua_Complex *) A, &lda, rcond,
      (lua_Complex *) work, rwork, info, 1, 1, 1);
}

/* xTRTRI - compute the inverse of a real [complex] upper or lower triangular
 * matrix A */
int matrixW_dtrtri (char uplo, char diag, int n,
    lua_Number *A, int lda, int *info) {
  return dtrtri_(&uplo, &diag, &n, A, &lda, info, 1, 1);
}

int matrixW_ztrtri (char uplo, char diag, int n,
    lua_Number *A, int lda, int *info) {
  return ztrtri_(&uplo, &diag, &n, (lua_Complex *) A, &lda, info, 1, 1);
}

/* xTRTRS - solve a triangular system of the form A * X = B or A**T * X = B,
 * where A is a triangular matrix of order N, and B is an N-by-NRHS matrix. A
 * check is made to verify that A is nonsingular */
int matrixW_dtrtrs (char uplo, char trans, char diag, int n, int nrhs,
    lua_Number *A, int lda, lua_Number *B, int ldb, int *info) {
  return dtrtrs_(&uplo, &trans, &diag, &n, &nrhs, A, &lda, B, &ldb, info,
      1, 1, 1);
}
int matrixW_ztrtrs (char uplo, char trans, char diag, int n, int nrhs,
    lua_Number *A, int lda, lua_Number *B, int ldb, int *info) {
  return ztrtrs_(&uplo, &trans, &diag, &n, &nrhs, (lua_Complex *) A, &lda,
      (lua_Complex *) B, &ldb, info, 1, 1, 1);
}

