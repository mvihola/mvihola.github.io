/* {=================================================================
 *
 * luaspfun.h
 * Special function library for Lua [header file]
 * Luis Carvalho (carvalho @ dam.brown.edu)
 * See Copyright Notice at the bottom of this file
 * $Id: luaspfun.h,v 1.5 2006-09-11 02:25:38 carvalho Exp $
 *
 * ==================================================================} */

#ifndef luaspfun_h
#define luaspfun_h

#include <math.h>
#include <float.h>
#include <lua.h>

#define LUASPFUN_VERSION "LuaSpfun 0.2"
#define LUASPFUN_COPYRIGHT "Copyright (C) 2005-2006 Luis Carvalho"
#define LUASPFUN_AUTHORS "Luis Carvalho"

/* Tags */
#define LUASPFUN_INTERN static
#define LUASPFUN_API extern

/* Constants */
#define LUASPFUN_LIBNAME "spfun"
#define LUASPFUN_NMAX (100) /* used in spfun_psi */
#define LUASPFUN_MAXITER (1000) /* used in spfun_dchisq */
#define LUASPFUN_LBOUND (1.0e-20) /* ditto */

/* =============================  Basic  ============================= */
LUASPFUN_API lua_Number spfun_dawson (lua_Number x);
LUASPFUN_API lua_Number spfun_expint (lua_Number x);
LUASPFUN_API lua_Number spfun_erf (lua_Number x);
LUASPFUN_API lua_Number spfun_erfc (lua_Number x);
LUASPFUN_API lua_Number spfun_expm1 (lua_Number x);
LUASPFUN_API lua_Number spfun_log1p (lua_Number x);
LUASPFUN_API lua_Number spfun_spence (lua_Number x);

/* =============================  Bessel ============================= */
LUASPFUN_API lua_Number spfun_airy (lua_Number x, int k);
LUASPFUN_API lua_Number spfun_besseli (lua_Number x, lua_Number alpha,
    int kode);
LUASPFUN_API lua_Number spfun_besselj (lua_Number x, lua_Number alpha);
LUASPFUN_API lua_Number spfun_besselk (lua_Number x, lua_Number fnu,
    int kode);
LUASPFUN_API lua_Number spfun_bessely (lua_Number x, lua_Number fnu);

/* =============================  Gamma  ============================= */
LUASPFUN_API lua_Number spfun_beta (lua_Number a, lua_Number b);
LUASPFUN_API lua_Number spfun_lbeta (lua_Number a, lua_Number b);
LUASPFUN_API lua_Number spfun_choose (int n, int m);
LUASPFUN_API lua_Number spfun_factorial (int n);
LUASPFUN_API lua_Number spfun_gamma (lua_Number x);
LUASPFUN_API lua_Number spfun_lgamma (lua_Number x);
LUASPFUN_API lua_Number spfun_psi (lua_Number x, int n);

/* =============================  Probs  ============================= */
LUASPFUN_API lua_Number spfun_dbeta (lua_Number x, lua_Number a,
    lua_Number b);
LUASPFUN_API lua_Number spfun_pbeta (lua_Number x, lua_Number a,
    lua_Number b);
LUASPFUN_API lua_Number spfun_qbeta (lua_Number p, lua_Number a,
    lua_Number b);
LUASPFUN_API lua_Number spfun_dbinom (lua_Number s, lua_Number xn,
    lua_Number pr);
LUASPFUN_API lua_Number spfun_pbinom (lua_Number s, lua_Number xn,
    lua_Number pr);
LUASPFUN_API int spfun_qbinom (lua_Number p, lua_Number xn,
    lua_Number pr);
LUASPFUN_API lua_Number spfun_dchisq (lua_Number x, lua_Number df,
    lua_Number pnonc);
LUASPFUN_API lua_Number spfun_pchisq (lua_Number x, lua_Number df,
    lua_Number pnonc);
LUASPFUN_API lua_Number spfun_qchisq (lua_Number p, lua_Number df,
    lua_Number pnonc);
LUASPFUN_API lua_Number spfun_df (lua_Number f, lua_Number dfn,
    lua_Number dfd);
LUASPFUN_API lua_Number spfun_pf (lua_Number f, lua_Number dfn,
    lua_Number dfd, lua_Number phonc);
LUASPFUN_API lua_Number spfun_qf (lua_Number p, lua_Number dfn,
    lua_Number dfd, lua_Number phonc);
LUASPFUN_API lua_Number spfun_dgamma (lua_Number x, lua_Number shape,
    lua_Number scale);
LUASPFUN_API lua_Number spfun_pgamma (lua_Number x, lua_Number shape,
    lua_Number scale);
LUASPFUN_API lua_Number spfun_qgamma (lua_Number p, lua_Number shape,
    lua_Number scale);
LUASPFUN_API lua_Number spfun_dnbinom (lua_Number s, lua_Number xn,
    lua_Number pr);
LUASPFUN_API lua_Number spfun_pnbinom (lua_Number s, lua_Number xn,
    lua_Number pr);
LUASPFUN_API lua_Number spfun_qnbinom (lua_Number p, lua_Number xn,
    lua_Number pr);
LUASPFUN_API lua_Number spfun_dnorm (lua_Number x, lua_Number mean,
    lua_Number sd);
LUASPFUN_API lua_Number spfun_pnorm (lua_Number x, lua_Number mean,
    lua_Number sd);
LUASPFUN_API lua_Number spfun_qnorm (lua_Number p, lua_Number mean,
    lua_Number sd);
LUASPFUN_API lua_Number spfun_dpois (lua_Number s, lua_Number xlam);
LUASPFUN_API lua_Number spfun_ppois (lua_Number s, lua_Number xlam);
LUASPFUN_API lua_Number spfun_qpois (lua_Number p, lua_Number xlam);
LUASPFUN_API lua_Number spfun_dt (lua_Number x, lua_Number df);
LUASPFUN_API lua_Number spfun_pt (lua_Number t, lua_Number df);
LUASPFUN_API lua_Number spfun_qt (lua_Number p, lua_Number df);

LUASPFUN_API int luaopen_luaspfun (lua_State *L);

/* {=================================================================
*
* Copyright (c) 2005-2006 Luis Carvalho
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation files
* (the "Software"), to deal in the Software without restriction,
* including without limitation the rights to use, copy, modify,
* merge, publish, distribute, sublicense, and/or sell copies of the
* Software, and to permit persons to whom the Software is furnished
* to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
* BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
* CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* ==================================================================} */

#endif
