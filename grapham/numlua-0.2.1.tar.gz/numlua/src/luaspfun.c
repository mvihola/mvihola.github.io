/* {=================================================================
 *
 * luaspfun.c
 * Special function library for Lua
 * Luis Carvalho (carvalho @ dam.brown.edu)
 * See Copyright Notice at the bottom of this file
 * $Id: luaspfun.c,v 1.5 2006-09-11 02:25:38 carvalho Exp $
 *
 * ==================================================================} */

#include <lauxlib.h>
#include "fnlib.h"
#include "dcdflib.h"
#include "luaspfun.h"

/* {=================================================================
 *    API
 * ==================================================================} */

/* =============================  Basic  ============================= */

LUASPFUN_API lua_Number spfun_dawson (lua_Number x) {
  return ddaws_(&x);
}

LUASPFUN_API lua_Number spfun_expint (lua_Number x) {
  return de1_(&x);
}

LUASPFUN_API lua_Number spfun_erf (lua_Number x) {
  return derf_(&x);
}

LUASPFUN_API lua_Number spfun_erfc (lua_Number x) {
  return derfc_(&x);
}

LUASPFUN_API lua_Number spfun_expm1 (lua_Number x) {
  return dexprl_(&x) * x;
}

LUASPFUN_API lua_Number spfun_log1p (lua_Number x) {
  return dlnrel_(&x);
}

LUASPFUN_API lua_Number spfun_spence (lua_Number x) {
  return dspenc_(&x);
}

/* =============================  Bessel ============================= */

/* TODO: compute airy for real orders, complex arguments */
LUASPFUN_API lua_Number spfun_airy (lua_Number x, int k) {
  /* if k == 0, compute first kind, otherwise, second kind */
  return (k == 0) ? dai_(&x) : dbi_(&x);
}

LUASPFUN_API lua_Number spfun_besseli (lua_Number x, lua_Number alpha,
    int kode) {
  lua_Number y;
  int n = 1, nz;
  dbesi_(&x, &alpha, &kode, &n, &y, &nz);
  if (nz < 0) /* overflow? */
    y = (nz == -2) ? -HUGE_VAL : HUGE_VAL;
  return y;
}

LUASPFUN_API lua_Number spfun_besselj (lua_Number x, lua_Number alpha) {
  lua_Number y;
  int n = 1, nz;
  dbesj_(&x, &alpha, &n, &y, &nz);
  return y;
}

LUASPFUN_API lua_Number spfun_besselk (lua_Number x, lua_Number fnu,
    int kode) {
  lua_Number y;
  int n = 1, nz;
  if (x == 0) y = HUGE_VAL;
  else {
    dbesk_(&x, &fnu, &kode, &n, &y, &nz);
    if (nz < 0) /* overflow */
      y = (nz == -2) ? -HUGE_VAL : HUGE_VAL;
  }
  return y;
}

LUASPFUN_API lua_Number spfun_bessely (lua_Number x, lua_Number fnu) {
  lua_Number y;
  int n = 1, nz = 0;
  if (x == 0) y = -HUGE_VAL;
  else {
    dbesy_(&x, &fnu, &n, &y, &nz);
    if (nz < 0) /* overflow? */
      y = (nz == -2) ? -HUGE_VAL : HUGE_VAL;
  }
  return y;
}

/* =============================  Gamma  ============================= */

LUASPFUN_API lua_Number spfun_beta (lua_Number a, lua_Number b) {
  return dbeta_(&a, &b);
}

LUASPFUN_API lua_Number spfun_lbeta (lua_Number a, lua_Number b) {
  return dlbeta_(&a, &b);
}

LUASPFUN_API lua_Number spfun_choose (int n, int m) {
  return dbinom_(&n, &m);
}

LUASPFUN_API lua_Number spfun_factorial (int n) {
  return dfac_(&n);
}

LUASPFUN_API lua_Number spfun_gamma (lua_Number x) {
  return dgamma_(&x);
}

LUASPFUN_API lua_Number spfun_lgamma (lua_Number x) {
  return dlngam_(&x);
}

LUASPFUN_API lua_Number spfun_psi (lua_Number x, int n) {
  lua_Number ans = 0;
  if (n == 0) ans = dpsi_(&x);
  else {
    int kode = 1;
    int m = 1;
    int nz, ierr;
    dpsifn_(&x, &n, &kode, &m, &ans, &nz, &ierr);
    /* if (nz > 0) printf("Warning: underflow\n"); */
    if (ierr == 2) ans = HUGE_VAL; /* overflow */
  }
  return ans;
}

/* =============================  Probs  ============================= */

/* Failsafe: execution shouldn't reach here (!), since most errors are checked
 * out by specific check_xxx routines; the only expected error is when status
 * == 10 */
LUASPFUN_INTERN void check_status (int status, lua_Number bound) {
  if (status == 1)
    printf("Warning: result lower than search bound: %f", bound);
  if (status == 2)
    printf("Warning: result higher than search bound: %f", bound);
  if (status < 0)
    printf("Warning: out of range on parameter %d: %f", -status, bound);
  if (status == 10)
    printf("Warning: error in cumgam: %d", status);
}

LUASPFUN_API lua_Number spfun_dbeta (lua_Number x, lua_Number a,
    lua_Number b) {
  lua_Number d;
  if (x == 0 || x == 1) d = 0;
  else
    d = exp((a - 1) * log(x) + (b - 1) * log(1 - x) - dlbeta_(&a, &b));
  return d;
}

LUASPFUN_API lua_Number spfun_pbeta (lua_Number x, lua_Number a,
    lua_Number b) {
  int which = 1, status;
  lua_Number p, q, y, bound;
  y = 1 - x;
  cdfbet_(&which, &p, &q, &x, &y, &a, &b, &status, &bound);
  check_status(status, bound);
  return p;
}

LUASPFUN_API lua_Number spfun_qbeta (lua_Number p, lua_Number a,
    lua_Number b) {
  lua_Number x = p;
  if (p > 0 && p < 1) {
    int which = 2, status;
    lua_Number q, x, y, bound;
    q = 1 - p;
    cdfbet_(&which, &p, &q, &x, &y, &a, &b, &status, &bound);
    check_status(status, bound);
  }
  return x;
}

LUASPFUN_API lua_Number spfun_dbinom (lua_Number s, lua_Number xn,
    lua_Number pr) {
  int si, xni;
  lua_Number d;
  lua_number2int(si, s);
  lua_number2int(xni, xn);
  d = s * log(pr) + (xn - s) * log(1 - pr);
  d = dbinom_(&xni, &si) * exp(d);
  return d;
}

LUASPFUN_API lua_Number spfun_pbinom (lua_Number s, lua_Number xn,
    lua_Number pr) {
  int which = 1, status;
  lua_Number p, q, ompr, bound;
  ompr = 1 - pr;
  cdfbin_(&which, &p, &q, &s, &xn, &pr, &ompr, &status, &bound);
  check_status(status, bound);
  return p;
}

LUASPFUN_API int spfun_qbinom (lua_Number p, lua_Number xn,
    lua_Number pr) {
  int si;
  lua_Number s;
  if (p == 0 || p == 1) s = p * xn;
  else {
    int which = 2, status;
    lua_Number ompr = 1 - pr;
    lua_Number q = 1 - p;
    lua_Number bound;
    cdfbin_(&which, &p, &q, &s, &xn, &pr, &ompr, &status, &bound);
    check_status(status, bound);
  }
  lua_number2int(si, s);
  return si;
}

LUASPFUN_API lua_Number spfun_dchisq (lua_Number x, lua_Number df,
    lua_Number pnonc) {
  lua_Number d;
  /* compute central dchisq */
  d = df / 2;
  d = exp((d - 1) * log(x) - x / 2 - d * M_LN2 - dlngam_(&d));
  /* compute non-central if that's the case */
  if (pnonc != 0) { /* non-central? */
    /* evaluate weighted series */
    int i;
    lua_Number t = d *= exp(-pnonc / 2); /* first term */
    for (i = 1; i < LUASPFUN_MAXITER && d > LUASPFUN_LBOUND
        && t > DBL_EPSILON * d; i++)
      d += t *= x * pnonc / (2 * i * (df + 2 * (i - 1)));
  }
  return d;
}

LUASPFUN_API lua_Number spfun_pchisq (lua_Number x, lua_Number df,
    lua_Number pnonc) {
  int which = 1, status;
  lua_Number p, q, bound;
  if (pnonc == 0) /* central? */
    cdfchi_(&which, &p, &q, &x, &df, &status, &bound);
  else /* non-central */
    cdfchn_(&which, &p, &q, &x, &df, &pnonc, &status, &bound);
  check_status(status, bound);
  return p;
}

LUASPFUN_API lua_Number spfun_qchisq (lua_Number p, lua_Number df,
    lua_Number pnonc) {
  lua_Number x;
  if (p == 0 || p == 1) x = (p == 0) ? 0 : HUGE_VAL;
  else {
    lua_Number q = 1 - p;
    lua_Number bound;
    int which = 2;
    int status;
    if (pnonc == 0) /* central? */
      cdfchi_(&which, &p, &q, &x, &df, &status, &bound);
    else /* non-central */
      cdfchn_(&which, &p, &q, &x, &df, &pnonc, &status, &bound);
    check_status(status, bound);
  }
  return x;
}

LUASPFUN_API lua_Number spfun_df (lua_Number f, lua_Number dfn,
    lua_Number dfd) {
  lua_Number df1 = dfn / 2;
  lua_Number df2 = dfd / 2;
  lua_Number r = dfn / dfd;
  lua_Number d = df1 * log(r) + (df1 - 1) * log(f);
  d -= (df1 + df2) * log(1 + r * f);
  d -= dlbeta_(&df1, &df2);
  return exp(d);
}

LUASPFUN_API lua_Number spfun_pf (lua_Number f, lua_Number dfn,
    lua_Number dfd, lua_Number phonc) {
  int which = 1, status;
  lua_Number p, q, bound;
  if (phonc == 0) /* central? */
    cdff_(&which, &p, &q, &f, &dfn, &dfd, &status, &bound);
  else /* non-central */
    cdffnc_(&which, &p, &q, &f, &dfn, &dfd, &phonc, &status, &bound);
  check_status(status, bound);
  return p;
}

LUASPFUN_API lua_Number spfun_qf (lua_Number p, lua_Number dfn,
    lua_Number dfd, lua_Number phonc) {
  lua_Number f;
  if (p == 0 || p == 1) f = (p == 0) ? 0 : HUGE_VAL;
  else {
    lua_Number q = 1-p;
    lua_Number bound;
    int which = 2;
    int status;
    if (phonc == 0) /* central? */
      cdff_(&which, &p, &q, &f, &dfn, &dfd, &status, &bound);
    else /* non-central */
      cdffnc_(&which, &p, &q, &f, &dfn, &dfd, &phonc, &status, &bound);
    check_status(status, bound);
  }
  return f;
}

/* scale here is 1 / rate */
LUASPFUN_API lua_Number spfun_dgamma (lua_Number x, lua_Number shape,
    lua_Number scale) {
  lua_Number d = x * scale;
  return exp(shape * log(d) - d - dlngam_(&shape)) / x;
}

LUASPFUN_API lua_Number spfun_pgamma (lua_Number x, lua_Number shape,
    lua_Number scale) {
  int which = 1, status;
  lua_Number p, q, bound;
  cdfgam_(&which, &p, &q, &x, &shape, &scale, &status, &bound);
  check_status(status, bound);
  return p;
}

LUASPFUN_API lua_Number spfun_qgamma (lua_Number p, lua_Number shape,
    lua_Number scale) {
  lua_Number x;
  if (p == 0 || p == 1) x = (p == 0) ? 0 : HUGE_VAL;
  else {
    lua_Number q = 1 - p;
    lua_Number bound;
    int which = 2, status;
    cdfgam_(&which, &p, &q, &x, &shape, &scale, &status, &bound);
    check_status(status, bound);
  }
  return x;
}

LUASPFUN_API lua_Number spfun_dnbinom (lua_Number s, lua_Number xn,
    lua_Number pr) {
  return exp(xn * log(pr) + s * log(1 - pr) - dlbeta_(&s, &xn)) / s;
}

LUASPFUN_API lua_Number spfun_pnbinom (lua_Number s, lua_Number xn,
    lua_Number pr) {
  int which = 1, status;
  lua_Number p, q, ompr, bound;
  ompr = 1 - pr;
  cdfnbn_(&which, &p, &q, &s, &xn, &pr, &ompr, &status, &bound);
  check_status(status, bound);
  return p;
}

LUASPFUN_API lua_Number spfun_qnbinom (lua_Number p, lua_Number xn,
    lua_Number pr) {
  int which = 2, status;
  lua_Number s, q, ompr, bound;
  if (p == 0 || p == 1) s = (p == 0) ? 0 : HUGE_VAL;
  else {
    ompr = 1 - pr;
    q = 1 - p;
    cdfnbn_(&which, &p, &q, &s, &xn, &pr, &ompr, &status, &bound);
    check_status(status, bound);
  }
  return s;
}

LUASPFUN_API lua_Number spfun_dnorm (lua_Number x, lua_Number mean,
    lua_Number sd) {
  lua_Number d = (x - mean) / sd;
  return exp(-d * d / 2) / (sqrt(2 * M_PI) * sd);
}

LUASPFUN_API lua_Number spfun_pnorm (lua_Number x, lua_Number mean,
    lua_Number sd) {
  int which = 1, status;
  lua_Number p, q, bound;
  q = 1 - p;
  cdfnor_(&which, &p, &q, &x, &mean, &sd, &status, &bound);
  check_status(status, bound);
  return p;
}

LUASPFUN_API lua_Number spfun_qnorm (lua_Number p, lua_Number mean,
    lua_Number sd) {
  lua_Number x;
  if (p == 0 || p == 1) x = (p == 0) ? -HUGE_VAL : HUGE_VAL;
  else {
    lua_Number q = 1 - p;
    lua_Number bound;
    int which = 2, status;
    cdfnor_(&which, &p, &q, &x, &mean, &sd, &status, &bound);
    check_status(status, bound);
  }
  return x;
}

LUASPFUN_API lua_Number spfun_dpois (lua_Number s, lua_Number xlam) {
  lua_Number d = s + 1;
  return exp(s * log(xlam) - xlam - dlngam_(&d));
}

LUASPFUN_API lua_Number spfun_ppois (lua_Number s, lua_Number xlam) {
  int which = 1, status;
  lua_Number p, q, bound;
  q = 1 - p;
  cdfpoi_(&which, &p, &q, &s, &xlam, &status, &bound);
  check_status(status, bound);
  return p;
}

LUASPFUN_API lua_Number spfun_qpois (lua_Number p, lua_Number xlam) {
  lua_Number s;
  if (p==0 || p==1) s = (p==0) ? 0 : HUGE_VAL;
  else {
    lua_Number q = 1 - p;
    lua_Number bound;
    int which = 2, status;
    cdfpoi_(&which, &p, &q, &s, &xlam, &status, &bound);
    check_status(status, bound);
  }
  return s;
}

LUASPFUN_API lua_Number spfun_dt (lua_Number x, lua_Number df) {
  lua_Number t = 0.5;
  lua_Number d = df / 2;
  d = -dlbeta_(&d, &t) - (df + 1) / 2 * log(1 + x * x / df);
  return exp(d) / sqrt(df);
}

LUASPFUN_API lua_Number spfun_pt (lua_Number t, lua_Number df) {
  int which = 1, status;
  lua_Number p, q, bound;
  q = 1 - p;
  cdft_(&which, &p, &q, &t, &df, &status, &bound);
  check_status(status, bound);
  return p;
}

LUASPFUN_API lua_Number spfun_qt (lua_Number p, lua_Number df) {
  lua_Number t;
  if (p == 0 || p == 1) t = (p == 0) ? -HUGE_VAL : HUGE_VAL;
  else {
    lua_Number q = 1 - p;
    lua_Number bound;
    int which = 2, status;
    cdft_(&which, &p, &q, &t, &df, &status, &bound);
    check_status(status, bound);
  }
  return t;
}


/* {=================================================================
 *    Basic
 * ==================================================================} */

static int dawson_spfun (lua_State *L) {
  lua_pushnumber(L, spfun_dawson(luaL_checknumber(L, 1)));
  return 1;
}

static int expint_spfun (lua_State *L) {
  lua_pushnumber(L, spfun_expint(luaL_checknumber(L, 1)));
  return 1;
}

static int erf_spfun (lua_State *L) {
  lua_pushnumber(L, spfun_erf(luaL_checknumber(L, 1)));
  return 1;
}

static int erfc_spfun (lua_State *L) {
  lua_pushnumber(L, spfun_erfc(luaL_checknumber(L, 1)));
  return 1;
}

static int expm1_spfun (lua_State *L) {
  lua_pushnumber(L, spfun_expm1(luaL_checknumber(L, 1)));
  return 1;
}

static int log1p_spfun (lua_State *L) {
  lua_pushnumber(L, spfun_log1p(luaL_checknumber(L, 1)));
  return 1;
}

static int spence_spfun (lua_State *L) {
  lua_pushnumber(L, spfun_spence(luaL_checknumber(L, 1)));
  return 1;
}

static int isinf_spfun (lua_State *L) {
  lua_pushboolean(L, isinf((double) luaL_checknumber(L, 1)));
  return 1;
}

static int isnan_spfun (lua_State *L) {
  lua_pushboolean(L, isnan((double) luaL_checknumber(L, 1)));
  return 1;
}


/* {=================================================================
 *    Bessel related
 * ==================================================================} */

static int airy_spfun (lua_State *L) {
  /* stack contains x and opt. k */
  lua_Number x = luaL_checknumber(L, 1);
  int k = luaL_optinteger(L, 2, 0);
  lua_pushnumber(L, spfun_airy(x, k));
  return 1;
}

static int besseli_spfun (lua_State *L) {
  /* stack contains x, alpha and opt. kode */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number alpha = luaL_checknumber(L, 2);
  int kode = lua_toboolean(L, 3) + 1;
  luaL_argcheck(L, x >= 0, 1, "negative");
  luaL_argcheck(L, alpha >= 0, 2, "negative");
  lua_pushnumber(L, spfun_besseli(x, alpha, kode));
  return 1;
}

static int besselj_spfun (lua_State *L) {
  /* stack contains x and alpha */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number alpha = luaL_checknumber(L, 2);
  luaL_argcheck(L, x >= 0, 1, "negative");
  luaL_argcheck(L, alpha >= 0, 2, "negative");
  lua_pushnumber(L, spfun_besselj(x, alpha));
  return 1;
}

static int besselk_spfun (lua_State *L) {
  /* stack contains x, fnu and opt. kode */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number fnu = luaL_checknumber(L, 2);
  int kode = lua_toboolean(L, 3) + 1;
  luaL_argcheck(L, x >= 0, 1, "negative");
  luaL_argcheck(L, fnu >= 0, 2, "negative");
  lua_pushnumber(L, spfun_besselk(x, fnu, kode));
  return 1;
}

static int bessely_spfun (lua_State *L) {
  /* stack contains x and fnu */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number fnu = luaL_checknumber(L, 2);
  luaL_argcheck(L, x >= 0, 1, "negative");
  luaL_argcheck(L, fnu >= 0, 2, "negative");
  lua_pushnumber(L, spfun_bessely(x, fnu));
  return 1;
}

/* {=================================================================
 *    Gamma related
 * ==================================================================} */

static int beta_spfun (lua_State *L) {
  /* stack contains a and b */
  lua_pushnumber(L, spfun_beta(luaL_checknumber(L, 1),
        luaL_checknumber(L, 2)));
  return 1;
}

static int lbeta_spfun (lua_State *L) {
  /* stack contains a and b */
  lua_pushnumber(L, spfun_lbeta(luaL_checknumber(L, 1),
        luaL_checknumber(L, 2)));
  return 1;
}

static int choose_spfun (lua_State *L) {
  /* stack contains n and m */
  lua_Integer n = luaL_checkinteger(L, 1);
  lua_Integer m = luaL_checkinteger(L, 2);
  luaL_argcheck(L, n>=0, 1, "non-negative value expected");
  luaL_argcheck(L, m>=0, 2, "non-negative value expected");
  if (n<m) luaL_error(L, "n is lesser than m: %d < %d", n, m);
  lua_pushnumber(L, spfun_choose(n, m));
  return 1;
}

static int factorial_spfun (lua_State *L) {
  /* stack contains n */
  lua_Integer n = luaL_checkinteger(L, 1);
  luaL_argcheck(L, n>=0, 1, "non-negative value expected");
  lua_pushnumber(L, spfun_factorial(n));
  return 1;
}

static int gamma_spfun (lua_State *L) {
  /* stack contains x */
  lua_pushnumber(L, spfun_gamma(luaL_checknumber(L, 1)));
  return 1;
}

static int lgamma_spfun (lua_State *L) {
  /* stack contains x */
  lua_pushnumber(L, spfun_lgamma(luaL_checknumber(L, 1)));
  return 1;
}

static int psi_spfun (lua_State *L) {
  /* stack contains x and opt. n */
  lua_Number x = luaL_checknumber(L, 1);
  int n = luaL_optinteger(L, 2, 0);
  /* check ierr 1 */
  luaL_argcheck(L, x>=0, 1, "non-negative value expected");
  luaL_argcheck(L, n>=0, 2, "non-negative value expected");
  /* check ierr 3 */
  luaL_argcheck(L, n<=LUASPFUN_NMAX, 2, "too large");
  lua_pushnumber(L, spfun_psi(x, n));
  return 1;
}

/* {=================================================================
 *    Probability distributions
 * ==================================================================} */

/* =============================   Beta  ============================= */

LUASPFUN_INTERN void check_beta (lua_State *L, int which, lua_Number x,
    lua_Number a, lua_Number b) {
  (void) which;
  luaL_argcheck(L, x>=0 && x<=1, 1, "out of range");
  luaL_argcheck(L, a>=0, 2, "non-negative value expected");
  luaL_argcheck(L, b>=0, 3, "non-negative value expected");
}

static int dbeta_spfun (lua_State *L) {
  /* stack should contain x, a and b */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number a = luaL_checknumber(L, 2);
  lua_Number b = luaL_checknumber(L, 3);
  check_beta(L, 1, x, a, b);
  lua_pushnumber(L, spfun_dbeta(x, a, b));
  return 1;
}

static int pbeta_spfun (lua_State *L) {
  /* stack should contain x, a and b */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number a = luaL_checknumber(L, 2);
  lua_Number b = luaL_checknumber(L, 3);
  check_beta(L, 1, x, a, b);
  lua_pushnumber(L, spfun_pbeta(x, a, b));
  return 1;
}

static int qbeta_spfun (lua_State *L) {
  /* stack should contain p, a and b */
  lua_Number p = luaL_checknumber(L, 1);
  lua_Number a = luaL_checknumber(L, 2);
  lua_Number b = luaL_checknumber(L, 3);
  check_beta(L, 2, p, a, b);
  lua_pushnumber(L, spfun_qbeta(p, a, b));
  return 1;
}

/* =============================  Binom  ============================= */

LUASPFUN_INTERN void check_binom (lua_State *L, int which, lua_Number x,
    lua_Number xn, lua_Number pr) {
  luaL_argcheck(L, ((which == 1 && (x >= 0 && x <= xn)) /* x */
      || (which == 2 && (x >= 0 && x <= 1))), /* p */
      1, "out of range");
  luaL_argcheck(L, xn >= 0, 2, "non-negative value expected");
  luaL_argcheck(L, pr >= 0 && pr <= 1, 3, "out of range");
}

static int dbinom_spfun (lua_State *L) {
  /* stack should contain s, xn, pr */
  lua_Number s = luaL_checknumber(L, 1);
  lua_Number xn = luaL_checknumber(L, 2);
  lua_Number pr = luaL_checknumber(L, 3);
  check_binom(L, 1, s, xn, pr);
  lua_pushnumber(L, spfun_dbinom(s, xn, pr));
  return 1;
}

static int pbinom_spfun (lua_State *L) {
  /* stack should contain s, xn, pr */
  lua_Number s = luaL_checknumber(L, 1);
  lua_Number xn = luaL_checknumber(L, 2);
  lua_Number pr = luaL_checknumber(L, 3);
  check_binom(L, 1, s, xn, pr);
  lua_pushnumber(L, spfun_pbinom(s, xn, pr));
  return 1;
}

static int qbinom_spfun (lua_State *L) {
  /* stack should contain p, xn, pr */
  lua_Number p = luaL_checknumber(L, 1);
  lua_Number xn = luaL_checknumber(L, 2);
  lua_Number pr = luaL_checknumber(L, 3);
  check_binom(L, 2, p, xn, pr);
  lua_pushinteger(L, spfun_qbinom(p, xn, pr));
  return 1;
}

/* =============================  Chisq  ============================= */

LUASPFUN_INTERN void check_chisq (lua_State *L, int which, lua_Number x,
    lua_Number df, lua_Number pnonc) {
  luaL_argcheck(L, ((which == 1 && x >= 0)  /* x */
      || (which == 2 && (x >= 0 && x <= 1))), /* p */
      1, "out of range");
  if (pnonc == 0)
    luaL_argcheck(L, df > 0, 2, "positive value expected");
  else
    luaL_argcheck(L, df >= 0, 2, "non-negative value expected");
}

static int dchisq_spfun (lua_State *L) {
  /* stack should contain x, df and opt. pnonc */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number df = luaL_checknumber(L, 2);
  lua_Number pnonc = luaL_optnumber(L, 3, 0);
  check_chisq(L, 1, x, df, pnonc);
  lua_pushnumber(L, spfun_dchisq(x, df, pnonc));
  return 1;
}

static int pchisq_spfun (lua_State *L) {
  /* stack should contain x, df and opt. pnonc */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number df = luaL_checknumber(L, 2);
  lua_Number pnonc = luaL_optnumber(L, 3, 0);
  check_chisq(L, 1, x, df, pnonc);
  lua_pushnumber(L, spfun_pchisq(x, df, pnonc));
  return 1;
}

static int qchisq_spfun (lua_State *L) {
  /* stack should contain p, df and opt. pnonc */
  lua_Number p = luaL_checknumber(L, 1);
  lua_Number df = luaL_checknumber(L, 2);
  lua_Number pnonc = luaL_optnumber(L, 3, 0);
  check_chisq(L, 2, p, df, pnonc);
  lua_pushnumber(L, spfun_qchisq(p, df, pnonc));
  return 1;
}

/* =============================   Exp   ============================= */

static int dexp_spfun (lua_State *L) {
  /* stack should contain x and rate */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number l = luaL_checknumber(L, 2);
  lua_pushnumber(L, exp(-l * x) * l);
  return 1;
}

static int pexp_spfun (lua_State *L) {
  /* stack should contain x and rate */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number l = luaL_checknumber(L, 2);
  lua_pushnumber(L, 1 - exp(-l * x));
  return 1;
}

static int qexp_spfun (lua_State *L) {
  /* stack should contain p and rate */
  lua_Number p = luaL_checknumber(L, 1);
  lua_Number l = luaL_checknumber(L, 2);
  luaL_argcheck(L, p >= 0 && p <= 1, 1, "out of range");
  lua_pushnumber(L, (p < 1) ? -log(1 - p) / l : HUGE_VAL);
  return 1;
}

/* =============================    F    ============================= */

LUASPFUN_INTERN void check_f (lua_State *L, int which, lua_Number x,
    lua_Number dfn, lua_Number dfd) {
  luaL_argcheck(L, ((which == 1 && x >= 0)  /* x */
      || (which == 2 && (x >= 0 && x <= 1))), /* p */
      1, "out of range");
  luaL_argcheck(L, dfn >= 0, 2, "non-negative value expected");
  luaL_argcheck(L, dfd >= 0, 3, "non-negative value expected");
}

static int df_spfun (lua_State *L) {
  /* stack should contain f, dfn, dfd */
  lua_Number f = luaL_checknumber(L, 1);
  lua_Number dfn = luaL_checknumber(L, 2);
  lua_Number dfd = luaL_checknumber(L, 3);
  check_f(L, 1, f, dfn, dfd);
  lua_pushnumber(L, spfun_df(f, dfn, dfd));
  return 1;
}

static int pf_spfun (lua_State *L) {
  /* stack should contain f, dfn, dfd and opt. phonc */
  lua_Number f = luaL_checknumber(L, 1);
  lua_Number dfn = luaL_checknumber(L, 2);
  lua_Number dfd = luaL_checknumber(L, 3);
  lua_Number phonc = luaL_optnumber(L, 4, 0);
  check_f(L, 1, f, dfn, dfd);
  lua_pushnumber(L, spfun_pf(f, dfn, dfd, phonc));
  return 1;
}

static int qf_spfun (lua_State *L) {
  /* stack should contain p, dfn, dfd and opt. phonc */
  lua_Number p = luaL_checknumber(L, 1);
  lua_Number dfn = luaL_checknumber(L, 2);
  lua_Number dfd = luaL_checknumber(L, 3);
  lua_Number phonc = luaL_optnumber(L, 4, 0);
  check_f(L, 2, p, dfn, dfd);
  lua_pushnumber(L, spfun_qf(p, dfn, dfd, phonc));
  return 1;
}

/* =============================  Gamma  ============================= */

LUASPFUN_INTERN void check_gamma (lua_State *L, int which, lua_Number x,
    lua_Number shape, lua_Number scale) {
  luaL_argcheck(L, ((which == 1 && x >= 0)  /* x */
      || (which == 2 && (x >= 0 && x <= 1))), /* p */
      1, "out of range");
  luaL_argcheck(L, shape >= 0, 2, "non-negative value expected");
  luaL_argcheck(L, scale >= 0, 3, "non-negative value expected");
}

static int dgamma_spfun (lua_State *L) {
  /* stack should contain x, shape and opt. scale */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number shape = luaL_checknumber(L, 2);
  lua_Number scale = luaL_optnumber(L, 3, 1);
  check_gamma(L, 1, x, shape, scale);
  lua_pushnumber(L, spfun_dgamma(x, shape, scale));
  return 1;
}

static int pgamma_spfun (lua_State *L) {
  /* stack should contain x, shape and opt. scale */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number shape = luaL_checknumber(L, 2);
  lua_Number scale = luaL_optnumber(L, 3, 1);
  check_gamma(L, 1, x, shape, scale);
  lua_pushnumber(L, spfun_pgamma(x, shape, scale));
  return 1;
}

static int qgamma_spfun (lua_State *L) {
  /* stack should contain p, shape and opt. scale */
  lua_Number p = luaL_checknumber(L, 1);
  lua_Number shape = luaL_checknumber(L, 2);
  lua_Number scale = luaL_optnumber(L, 3, 1);
  check_gamma(L, 2, p, shape, scale);
  lua_pushnumber(L, spfun_qgamma(p, shape, scale));
  return 1;
}

/* =============================  Nbinom  ============================ */

LUASPFUN_INTERN void check_nbinom (lua_State *L, int which, lua_Number x,
    lua_Number xn, lua_Number pr) {
  luaL_argcheck(L, ((which == 1 && x >= 0)  /* x */
      || (which == 2 && (x >= 0 && x <= 1))), /* p */
      1, "out of range");
  luaL_argcheck(L, xn >= 0, 2, "non-negative value expected");
  luaL_argcheck(L, pr >= 0 && pr <= 1, 3, "out of range");
}

static int dnbinom_spfun (lua_State *L) {
  /* stack should contain s, xn, pr */
  lua_Number s = luaL_checknumber(L, 1);
  lua_Number xn = luaL_checknumber(L, 2);
  lua_Number pr = luaL_checknumber(L, 3);
  check_nbinom(L, 1, s, xn, pr);
  lua_pushnumber(L, spfun_dnbinom(s, xn, pr));
  return 1;
}

static int pnbinom_spfun (lua_State *L) {
  /* stack should contain s, xn, pr */
  lua_Number s = luaL_checknumber(L, 1);
  lua_Number xn = luaL_checknumber(L, 2);
  lua_Number pr = luaL_checknumber(L, 3);
  check_nbinom(L, 1, s, xn, pr);
  lua_pushnumber(L, spfun_pnbinom(s, xn, pr));
  return 1;
}

static int qnbinom_spfun (lua_State *L) {
  /* stack should contain p, xn, pr */
  lua_Number p = luaL_checknumber(L, 1);
  lua_Number xn = luaL_checknumber(L, 2);
  lua_Number pr = luaL_checknumber(L, 3);
  int si = 0;
  check_nbinom(L, 2, p, xn, pr);
  if (p==1) {
    lua_pushnumber(L, HUGE_VAL);
    return 1;
  }
  if (p>0) {
    lua_Number s = spfun_qnbinom(p, xn, pr);
    lua_number2int(si, s);
  }
  lua_pushinteger(L, si);
  return 1;
}

/* =============================  Normal  ============================ */

LUASPFUN_INTERN void check_norm (lua_State *L, int which, lua_Number x,
    lua_Number sd) {
  if (which == 2) luaL_argcheck(L, x >= 0 && x <= 1,  /* p */
      1, "out of range");
  luaL_argcheck(L, sd >= 0, 3, "non-negative value expected");
}

static int dnorm_spfun (lua_State *L) {
  /* stack should contain x, and opt. mean and sd */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number mean = luaL_optnumber(L, 2, 0);
  lua_Number sd = luaL_optnumber(L, 3, 1);
  check_norm(L, 1, x, sd);
  lua_pushnumber(L, spfun_dnorm(x, mean, sd));
  return 1;
}

static int pnorm_spfun (lua_State *L) {
  /* stack should contain x, and opt. mean and sd */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number mean = luaL_optnumber(L, 2, 0);
  lua_Number sd = luaL_optnumber(L, 3, 1);
  check_norm(L, 1, x, sd);
  lua_pushnumber(L, spfun_pnorm(x, mean, sd));
  return 1;
}

static int qnorm_spfun (lua_State *L) {
  /* stack should contain p, and opt. mean and sd */
  lua_Number p = luaL_checknumber(L, 1);
  lua_Number mean = luaL_optnumber(L, 2, 0);
  lua_Number sd = luaL_optnumber(L, 3, 1);
  check_norm(L, 2, p, sd);
  lua_pushnumber(L, spfun_qnorm(p, mean, sd));
  return 1;
}

/* ============================  Poisson  ============================ */

LUASPFUN_INTERN void check_pois (lua_State *L, int which, lua_Number x,
    lua_Number xlam) {
  luaL_argcheck(L, ((which == 1 && x >= 0)  /* x */
      || (which == 2 && (x >= 0 && x <= 1))), /* p */
      1, "out of range");
  luaL_argcheck(L, xlam >= 0, 2, "non-negative value expected");
}

static int dpois_spfun (lua_State *L) {
  /* stack should contain s and xlam */
  lua_Number s = luaL_checknumber(L, 1);
  lua_Number xlam = luaL_checknumber(L, 2);
  check_pois(L, 1, s, xlam);
  lua_pushnumber(L, spfun_dpois(s, xlam));
  return 1;
}

static int ppois_spfun (lua_State *L) {
  /* stack should contain s and xlam */
  lua_Number s = luaL_checknumber(L, 1);
  lua_Number xlam = luaL_checknumber(L, 2);
  check_pois(L, 1, s, xlam);
  lua_pushnumber(L, spfun_ppois(s, xlam));
  return 1;
}

static int qpois_spfun (lua_State *L) {
  /* stack should contain p and xlam */
  lua_Number p = luaL_checknumber(L, 1);
  lua_Number xlam = luaL_checknumber(L, 2);
  int si = 0;
  check_pois(L, 2, p, xlam);
  if (p==1) {
    lua_pushnumber(L, HUGE_VAL);
    return 1;
  }
  if (p>0) {
    lua_Number s = spfun_qpois(p, xlam);
    lua_number2int(si, s);
  }
  lua_pushinteger(L, si);
  return 1;
}

/* =============================    t    ============================= */

LUASPFUN_INTERN void check_t (lua_State *L, int which, lua_Number x,
    lua_Number df) {
  if (which == 2) luaL_argcheck(L, x >= 0 && x <= 1,  /* p */
      1, "out of range");
  luaL_argcheck(L, df >= 0, 3, "non-negative value expected");
}

static int dt_spfun (lua_State *L) {
  /* stack should contain x and df */
  lua_Number x = luaL_checknumber(L, 1);
  lua_Number df = luaL_checknumber(L, 2);
  check_t(L, 1, x, df);
  lua_pushnumber(L, spfun_dt(x, df));
  return 1;
}

static int pt_spfun (lua_State *L) {
  /* stack should contain t and df */
  lua_Number t = luaL_checknumber(L, 1);
  lua_Number df = luaL_checknumber(L, 2);
  check_t(L, 1, t, df);
  lua_pushnumber(L, spfun_pt(t, df));
  return 1;
}

static int qt_spfun (lua_State *L) {
  /* stack should contain p and df */
  lua_Number p = luaL_checknumber(L, 1);
  lua_Number df = luaL_checknumber(L, 2);
  check_t(L, 2, p, df);
  lua_pushnumber(L, spfun_qt(p, df));
  return 1;
}

/* {=================================================================
 *    Interface
 * ==================================================================} */

static const luaL_reg spfun_lib[] = {
  /* basic */
  {"dawson", dawson_spfun},
  {"expint", expint_spfun},
  {"erf", erf_spfun},
  {"erfc", erfc_spfun},
  {"expm1", expm1_spfun},
  {"log1p", log1p_spfun},
  {"spence", spence_spfun},
  {"isinf", isinf_spfun},
  {"isnan", isnan_spfun},
  /* bessel related */
  {"airy", airy_spfun},
  {"besseli", besseli_spfun},
  {"besselj", besselj_spfun},
  {"besselk", besselk_spfun},
  {"bessely", bessely_spfun},
  /* gamma related */
  {"beta", beta_spfun},
  {"lbeta", lbeta_spfun},
  {"choose", choose_spfun},
  {"factorial", factorial_spfun},
  {"gamma", gamma_spfun},
  {"lgamma", lgamma_spfun},
  {"psi", psi_spfun},
  /* probability dists */
  {"dbeta", dbeta_spfun},
  {"pbeta", pbeta_spfun},
  {"qbeta", qbeta_spfun},
  {"dbinom", dbinom_spfun},
  {"pbinom", pbinom_spfun},
  {"qbinom", qbinom_spfun},
  {"dchisq", dchisq_spfun},
  {"pchisq", pchisq_spfun},
  {"qchisq", qchisq_spfun},
  {"dexp", dexp_spfun},
  {"pexp", pexp_spfun},
  {"qexp", qexp_spfun},
  {"df", df_spfun},
  {"pf", pf_spfun},
  {"qf", qf_spfun},
  {"dgamma", dgamma_spfun},
  {"pgamma", pgamma_spfun},
  {"qgamma", qgamma_spfun},
  {"dnbinom", dnbinom_spfun},
  {"pnbinom", pnbinom_spfun},
  {"qnbinom", qnbinom_spfun},
  {"dnorm", dnorm_spfun},
  {"pnorm", pnorm_spfun},
  {"qnorm", qnorm_spfun},
  {"dpois", dpois_spfun},
  {"ppois", ppois_spfun},
  {"qpois", qpois_spfun},
  {"dt", dt_spfun},
  {"pt", pt_spfun},
  {"qt", qt_spfun},
  {NULL, NULL}
};

LUASPFUN_API int luaopen_luaspfun (lua_State *L) {
  luaL_register(L, LUASPFUN_LIBNAME, spfun_lib);
  lua_pushstring(L, LUASPFUN_VERSION);
  lua_setfield(L, -2, "_VERSION");
  return 1;
}

/* {=================================================================
*
* Copyright (c) 2004 Luis Carvalho
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation files
* (the "Software"), to deal in the Software without restriction,
* including without limitation the rights to use, copy, modify,
* merge, publish, distribute, sublicense, and/or sell copies of the
* Software, and to permit persons to whom the Software is furnished
* to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
* BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
* CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* ==================================================================} */


