/* {=================================================================
 * 
 * Auxiliar functions for lua matrix
 * See Copyright Notice in luamatrix.h
 * $Id: lmaux.c,v 1.3 2006-09-11 02:25:38 carvalho Exp $
 *  
 * ==================================================================} */

#include <string.h>
#include <lauxlib.h>
#include "luamatrix.h"
#include "lmwrap.h"

/* {=================================================================
 *    C Methods (Auxiliary API)
 * ==================================================================} */

/* return M->data size for a matrix M */
int matrixA_datasize (lua_Matrix *M) {
  lua_Matrix *m = M;
  int i, size = 1;
  for (i = 0; i < M->dim-1; i++) {
    size *= m->size;
    m = m->level[0];
  }
  size *= m->size;
  return size;
}

/* updates (in place) a size array for a matrix */
void matrixA_getsizes (lua_Matrix *M, int *size) {
  int i;
  lua_Matrix *m = M;
  for (i = 0; i < M->dim-1; i++) {
    size[i] = m->size;
    m = m->level[0];
  }
  size[i] = m->size; /* i = M->dim-1 */
}

/* initialize (in place) index and size arrays */
void matrixA_initindex (lua_Matrix *M, int *index, int *size) {
  int i;
  lua_Matrix *m = M;
  for (i = 0; i < M->dim-1; i++) {
    size[i] = m->size;
    index[i] = 1;
    m = m->level[0];
  }
  size[i] = m->size; /* i = M->dim-1 */
  index[i] = 0;
}

/* update (in place) index for iteration */
int matrixA_next (lua_Matrix *M, int *index, int *size) {
  int pos = M->dim-1;
  short back_update = 1;
  while (back_update) {
    if (index[pos] == size[pos]) {
      index[pos--] = 1;
      back_update = (pos >= 0);
    }
    else {
      index[pos]++;
      back_update = 0;
    }
  }
  return (pos >= 0);
}

/* given a lua_Matrix M, pushes some indexes on the stack and returns a
 * pointer to M->data[indexes] for later treatment */
lua_Number *matrixA_pushindex (lua_State *L, lua_Matrix *M, int *index) {
  lua_Matrix *m = M;
  int i;
  for (i = 0; i < M->dim-1; i++) {
    lua_pushinteger(L, index[i]); /* index */
    m = m->level[index[i]-1];
  }
  lua_pushinteger(L, index[i]); /* last index */
  /* value */
  i = (index[i] - 1) * matrix_stride(m);
  if (m->complex == LM_COMPLEX) i *= 2; 
  return m->data + i;
}

/* for two matrices A and B, checks if A->dim == B->dim and if sizes(A) ==
 * sizes(B) := _size_, returning size if so */
int matrixA_checkconsistency (lua_State *L, lua_Matrix *A, lua_Matrix *B) {
  /* check dims first */
  if (A->dim != B->dim)
    luaL_error(L, "inconsistent dimensions: %d and %d", A->dim, B->dim);
  else {
    /* check sizes */
    lua_Matrix *a = A, *b = B;
    int i, size = 1;
    for (i = 0; i < A->dim-1; i++) {
      if (a->size != b->size)
        luaL_error(L, "inconsistent sizes on dimension %d: %d and %d",
            i+1, a->size, b->size);
      size *= a->size;
      a = a->level[0];
      b = b->level[0];
    }
    if (a->size != b->size)
      luaL_error(L, "inconsistent sizes on dimension %d: %d and %d",
          i+1, a->size, b->size);
    size *= a->size;
    return size;
  }
  return 0;
}

/* for two matrices A and B, checks if A->dim <= 2, B->dim <= 2, and
 *  o if A->dim == B->dim == 1, checks if A->size == B->size [dot(A,B)]
 *  o if A->dim == 2 and B->dim == 1, checks if cols(A) == B->size [A*B]
 *  o if A->dim == 1 and B->dim == 2, checks if A->size == B->size [A'*B]
 *  o if A->dim == B->dim == 2, checks if cols(A) == B->size [A*B]
 * if any of these is satisfied, return _size_ from last comparison */
int matrixA_checkmultiply (lua_State *L, lua_Matrix *A, lua_Matrix *B) {
  int size;
  if ((A->dim > 2) || (B->dim > 2))
    luaL_error(L, "dimensions too large to operate: %d and %d",
        A->dim, B->dim);
  size = (A->dim == 1) ? A->size : A->level[0]->size;
  if (size != B->size)
    luaL_error(L, "inconsistent sizes: %d and %d", size, B->size);
  return size;
}

/* for two matrices A and B, checks if A->dim <= 2, B->dim <= 2, and
 *  o if A->dim == B->dim == 1, checks if A->size == B->size [dot(A,B)]
 *  o if A->dim == 2 and B->dim == 1, checks if A->size == B->size [A'*B]
 *  o if A->dim == 1 and B->dim == 2, checks if A->size == B->size [A'*B]
 *  o if A->dim == B->dim == 2, checks if A->size == B->size [A'*B]
 * if any of these is satisfied, return _size_ from last comparison */
int matrixA_checkinner (lua_State *L, lua_Matrix *A, lua_Matrix *B) {
  if ((A->dim > 2) || (B->dim > 2))
    luaL_error(L, "dimensions too large to operate: %d and %d",
        A->dim, B->dim);
  if (A->size != B->size)
    luaL_error(L, "inconsistent sizes: %d and %d", A->size, B->size);
  return A->size;
}

/* for two matrices A and B, checks if A->dim <= 2, B->dim <= 2, and
 *  o if A->dim == B->dim == 1, checks if A->size == B->size [A*B']
 *  o if A->dim == 2 and B->dim == 1, checks if cols(A) == B->size [A*B]
 *  o if A->dim == 1 and B->dim == 2, checks if A->size == cols(B) [A*B']
 *  o if A->dim == B->dim == 2, checks if cols(A) == cols(B) [A*B']
 * if any of these is satisfied, return _size_ from last comparison */
int matrixA_checkouter (lua_State *L, lua_Matrix *A, lua_Matrix *B) {
  int sizeA, sizeB;
  if ((A->dim > 2) || (B->dim > 2))
    luaL_error(L, "dimensions too large to operate: %d and %d",
        A->dim, B->dim);
  sizeA = (A->dim == 1) ? A->size : A->level[0]->size;
  sizeB = (B->dim == 1) ? B->size : B->level[0]->size;
  if (sizeA != sizeB)
    luaL_error(L, "inconsistent sizes: %d and %d", sizeA, sizeB);
  return sizeA;
}

