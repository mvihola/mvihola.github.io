/* {=================================================================
 *
 * Auxiliary matrix API
 * See Copyright Notice in luamatrix.h
 * $Id: lmaux.h,v 1.2 2006/02/12 20:53:14 carvalho Exp $
 *
 * ==================================================================} */

#ifndef lmaux_h
#define lmaux_h

#include "luamatrix.h"

/* {=================================================================
 *    C Methods (Auxiliary API)
 * ==================================================================} */

int matrixA_datasize (lua_Matrix *M);
void matrixA_getsizes (lua_Matrix *M, int *size);
void matrixA_initindex (lua_Matrix *M, int *index, int *size);
int matrixA_next (lua_Matrix *M, int *index, int *size);
lua_Number *matrixA_pushindex (lua_State *L, lua_Matrix *M, int *index);
int matrixA_checkconsistency (lua_State *L, lua_Matrix *A, lua_Matrix *B);
int matrixA_checkmultiply (lua_State *L, lua_Matrix *A, lua_Matrix *B);
int matrixA_checkinner (lua_State *L, lua_Matrix *A, lua_Matrix *B);
int matrixA_checkouter (lua_State *L, lua_Matrix *A, lua_Matrix *B);

#endif

