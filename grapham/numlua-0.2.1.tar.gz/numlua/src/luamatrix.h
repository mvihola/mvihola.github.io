/* {=================================================================
 *
 * Matrix library API
 * See Copyright Notice at the bottom of this file
 * $Id: luamatrix.h,v 1.4 2006-09-11 02:25:38 carvalho Exp $
 *
 * ==================================================================} */

#ifndef luamatrix_h
#define luamatrix_h

#include <float.h>
#include <lua.h>
#include "luacomplex.h"

#define LUAMATRIX_VERSION "LuaMatrix 0.2"
#define LUAMATRIX_COPYRIGHT "Copyright (C) 2004-2005 Luis Carvalho"
#define LUAMATRIX_AUTHORS "Luis Carvalho"

/* Tags */
#define LUAMATRIX_INTERN static
#define LUAMATRIX_API extern

/* Constants */
#define LUAMATRIX_LIBNAME "matrix"
#define LUAMATRIX_MT "_matrix"
#define LUAMATRIX_BUFFER "_lm_buffer"
#define LM_MAXDIMS (10)
#define LM_EPS DBL_EPSILON    /* eps */
#define LM_RMIN DBL_MIN     /* underflow */
#define LM_RMAX DBL_MAX     /* overflow */

/* Types */
typedef enum { LM_REAL, LM_COMPLEX } lua_Matrix_complexity;
typedef enum {
  LM_UNKNOWN    = -1, /* error type */
  LM_GENERAL    = 0,  /* general (fallback) */
  LM_SYMMETRIC  = 1,  /* symmetric/hermitian */
  LM_UPPER    = 2,  /* upper triangular */
  LM_LOWER    = 4,  /* lower triangular */
  LM_POSDEF   = 8   /* positive definite */
} lua_Matrix_type;
#define LM_DIAGONAL (6)   /* upper + lower */

#define LM_TAG_GENERAL 'G'
#define LM_TAG_SYMMETRIC 'S'
#define LM_TAG_UPPER 'U'
#define LM_TAG_LOWER 'L'
#define LM_TAG_DIAGONAL 'D'
#define LM_TAG_POSDEF 'P'

/* type handling */
#define LM_TO_SYMMETRIC (9) /* symm + posdef */
#define LM_TO_UPPER (10)  /* upper + posdef */
#define LM_TO_LOWER (12)  /* lower + posdef */
#define LM_TO_DIAGONAL (15) /* symm + upper + lower + posdef */
#define LM_TO_POSDEF (15) /* symm + upper + lower + posdef */
/* query */
#define istype_general(m)   ((m)->type == LM_GENERAL)
#define istype_symmetric(m)   ((m)->type & LM_SYMMETRIC)
#define istype_upper(m)     ((m)->type & LM_UPPER)
#define istype_lower(m)     ((m)->type & LM_LOWER)
#define istype_diagonal(m)    (((m)->type & LM_DIAGONAL) == LM_DIAGONAL)
#define istype_triangular(m)  (((m)->type & LM_UPPER) | \
    ((m)->type & LM_LOWER))
#define istype_posdef(m)    ((m)->type & LM_POSDEF)
/* set */
#define settype_general(m)    (m)->type &= LM_GENERAL
#define settype_symmetric(m)  (m)->type |= LM_SYMMETRIC, \
    (m)->type &= LM_TO_SYMMETRIC
#define settype_upper(m)    (m)->type |= LM_UPPER, \
    (m)->type &= LM_TO_UPPER
#define settype_lower(m)    (m)->type |= LM_LOWER, \
    (m)->type &= LM_TO_LOWER
#define settype_diagonal(m)   (m)->type |= LM_DIAGONAL, \
    (m)->type &= LM_TO_DIAGONAL
#define settype_posdef(m)   (m)->type |= LM_POSDEF, \
    (m)->type &= LM_TO_POSDEF

/* Main object */
/* _sup_ is used to update type after __newindex is called on an _array_ */
typedef struct lua_Matrix_struct *lua_Matrix_ptr;
typedef struct lua_Matrix_struct {
  int size;
  int dim;
  lua_Matrix_type type;
  lua_Matrix_complexity complex; 
  lua_Number *data;
  lua_Matrix_ptr sup;   /* parent level matrix */
  lua_Matrix_ptr *level;
} lua_Matrix;

/* Macros */
#define EQ(a, b) ((a) - (b) < LM_EPS && (a) - (b) > -LM_EPS)
#define EQZERO(a) ((a) < LM_RMIN && (a) > -LM_RMIN)

#define matrix_stride(M) (((M)->dim == 1 && (M)->sup) ? (M)->sup->size : 1)
/* a vector is a simple level matrix */
#define matrix_pushvector(L, size, complex) \
    matrix_pushtop((L), (size), 1, (size), (complex))
/* a diagonal matrix is both upper and lower */
#define matrix_isdiagonal(M) (matrix_isupper(M) && matrix_islower(M))
#define matrix_istriangular(M) (matrix_isupper(M) || matrix_islower(M))

/* {=================================================================
 *    C Methods (Matrix API)
 * ==================================================================} */

LUAMATRIX_API int matrix_istype (lua_State *L, int pos);
LUAMATRIX_API lua_Matrix *matrix_checktype (lua_State *L, int pos);
LUAMATRIX_API lua_Matrix *matrix_pushtop (lua_State *L,
    int size, int dim, int datasize, lua_Matrix_complexity complex);
LUAMATRIX_API lua_Matrix *matrix_pushshallow (lua_State *L,
    int *dim, int dims, int size, lua_Number *data,
    lua_Matrix_complexity complex);
LUAMATRIX_API lua_Matrix *matrix_pushmatrix (lua_State *L, int *dim,
    int dims, lua_Matrix_complexity complex);
LUAMATRIX_API lua_Matrix *matrix_pusharray (lua_State *L, int row, int col,
    lua_Matrix_complexity complex);
LUAMATRIX_API void matrix_free (lua_State *L, lua_Matrix *M);
LUAMATRIX_API lua_Matrix *matrix_copyshallow (lua_State *L, lua_Matrix *M,
    lua_Matrix_complexity complex);
LUAMATRIX_API lua_Matrix *matrix_copy (lua_State *L, lua_Matrix *M);
LUAMATRIX_API lua_Matrix *matrix_fromtable (lua_State *L, int pos);
LUAMATRIX_API lua_Matrix *matrix_toreal (lua_State *L, lua_Matrix *M);
LUAMATRIX_API lua_Matrix *matrix_tocomplex (lua_State *L, lua_Matrix *M);
LUAMATRIX_API lua_Matrix *matrix_slice (lua_State *L, lua_Matrix *M,
    int from, int to);
LUAMATRIX_API void matrix_pushtag (lua_State *L, lua_Matrix *M);
LUAMATRIX_API lua_Matrix_type matrix_guesstype (lua_State *L, lua_Matrix *M);
/* utils */
LUAMATRIX_API lua_Matrix *matrix_transpose (lua_State *L, lua_Matrix *M);
LUAMATRIX_API lua_Matrix *matrix_inner (lua_State *L,
    lua_Matrix *A, lua_Matrix *B);
LUAMATRIX_API lua_Matrix *matrix_outer (lua_State *L,
    lua_Matrix *A, lua_Matrix *B);
/* info */
LUAMATRIX_API int matrix_issquare (lua_Matrix *M);
LUAMATRIX_API int matrix_issymmetric (lua_Matrix *M);
LUAMATRIX_API int matrix_isupper (lua_Matrix *M);
LUAMATRIX_API int matrix_islower (lua_Matrix *M);
/* functional */
LUAMATRIX_API void matrix_map (lua_State *L, lua_Matrix *M);
LUAMATRIX_API void matrix_reduce (lua_State *L, lua_Matrix *M);
/* linear algebra */
LUAMATRIX_API lua_Number matrix_norm (lua_State *L, lua_Matrix *M, char norm);
LUAMATRIX_API lua_Number matrix_rcond (lua_State *L, lua_Matrix *M,
    int *info);
LUAMATRIX_API lua_Number matrix_inv (lua_State *L, lua_Matrix *M,
    lua_Number tol, int *info);
LUAMATRIX_API void matrix_lu (lua_State *L, lua_Matrix *M, int *info);
LUAMATRIX_API void matrix_balance (lua_State *L, lua_Matrix *M, int *info);
LUAMATRIX_API void matrix_chol (lua_State *L, lua_Matrix *M, int *info);
LUAMATRIX_API int matrix_isposdef (lua_State *L, lua_Matrix *M);
LUAMATRIX_API void matrix_svdv (lua_State *L, lua_Matrix *M, int *info);
LUAMATRIX_API void matrix_svd (lua_State *L, lua_Matrix *M, int *info);
LUAMATRIX_API void matrix_qr (lua_State *L, lua_Matrix *M, int *info);
LUAMATRIX_API void matrix_qrp (lua_State *L, lua_Matrix *M, int *info);
LUAMATRIX_API void matrix_ls (lua_State *L, lua_Matrix *A, lua_Matrix *B,
    lua_Number tol, int *rank, int *info);
LUAMATRIX_API void matrix_lss (lua_State *L, lua_Matrix *A, lua_Matrix *B,
    lua_Number tol, int *rank, int *info);
LUAMATRIX_API void matrix_eigv (lua_State *L, lua_Matrix *M, int *info);
LUAMATRIX_API void matrix_eig (lua_State *L, lua_Matrix *M, int *info);
/* operations */
LUAMATRIX_API lua_Matrix *matrix_add (lua_State *L,
    lua_Matrix *A, lua_Matrix *B);
LUAMATRIX_API lua_Matrix *matrix_sub (lua_State *L,
    lua_Matrix *A, lua_Matrix *B);
LUAMATRIX_API lua_Matrix *matrix_unm (lua_State *L, lua_Matrix *A);
LUAMATRIX_API lua_Matrix *matrix_mul (lua_State *L,
    lua_Matrix *A, lua_Matrix *B);

/* open lib */
LUAMATRIX_API int luaopen_luamatrix (lua_State *L);


/* {=================================================================
*
* Copyright (c) 2005-2006 Luis Carvalho
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation files
* (the "Software"), to deal in the Software without restriction,
* including without limitation the rights to use, copy, modify,
* merge, publish, distribute, sublicense, and/or sell copies of the
* Software, and to permit persons to whom the Software is furnished
* to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
* BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
* CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* ==================================================================} */

#endif

