/* {=================================================================
 *
 * BLAS/LAPACK wrapping API
 * See Copyright Notice in luamatrix.h
 * $Id: lmwrap.h,v 1.4 2006-09-11 02:25:38 carvalho Exp $
 *
 * ==================================================================} */

#ifndef lmwrap_h
#define lmwrap_h

#include "luamatrix.h"

/* Fortran-to-C definitions, adapted from f2c.h */
typedef int integer;
typedef lua_Number doublereal;
typedef lua_Complex doublecomplex;
typedef int logical;

#include "blas.h"
#include "lapack.h"

/* {=================================================================
 *    BLAS
 * ==================================================================} */

/* ============================= Level 1 ============================= */

int matrixW_dscal (int n, lua_Number alpha, lua_Number *x, int incx);
int matrixW_zdscal (int n, lua_Number alpha, lua_Number *x, int incx);
int matrixW_daxpy (int n, lua_Number alpha, lua_Number *x, int incx,
    lua_Number *y, int incy);
int matrixW_zaxpy (int n, lua_Complex alpha, lua_Number *x, int incx,
    lua_Number* y, int incy);
lua_Number matrixW_ddot(int n, lua_Number *x, int incx,
    lua_Number *y, int incy);
void matrixW_zdotc (lua_Complex *retval, int n, lua_Number *x, int incx,
    lua_Number *y, int incy);
void matrixW_zdotu (lua_Complex *retval, int n, lua_Number *x, int incx,
    lua_Number *y, int incy);
int matrixW_dcopy (int n, lua_Number *x, int incx, lua_Number *y, int incy);
int matrixW_zcopy (int n, lua_Number *x, int incx, lua_Number *y, int incy);
int matrixW_dswap (int n, lua_Number *x, int incx, lua_Number *y, int incy);
int matrixW_zswap (int n, lua_Number *x, int incx, lua_Number *y, int incy);
int matrixW_idamax (int n, lua_Number *x, int incx);
int matrixW_izamax (int n, lua_Number *x, int incx);

/* ============================= Level 2 ============================= */

int matrixW_dgemv (char trans, int m, int n, lua_Number alpha,
    lua_Number *A, int lda, lua_Number *x, int incx, lua_Number beta,
    lua_Number *y, int incy);
int matrixW_zgemv (char trans, int m, int n, lua_Complex alpha,
    lua_Number *A, int lda, lua_Number *x, int incx, lua_Complex beta,
    lua_Number *y, int incy);
int matrixW_dsymv (char uplo, int n, lua_Number alpha, lua_Number *A, int lda,
    lua_Number *x, int incx, lua_Number beta, lua_Number *y, int incy);
int matrixW_zhemv (char uplo, int n, lua_Complex alpha, lua_Number *A, int lda,
    lua_Number *x, int incx, lua_Complex beta, lua_Number *y, int incy);
int matrixW_dtrmv (char uplo, char trans, char diag, int n,
    lua_Number *A, int lda, lua_Number *x, int incx);
int matrixW_ztrmv (char uplo, char trans, char diag, int n,
    lua_Number *A, int lda, lua_Number *x, int incx);
int matrixW_dtrsv (char uplo, char trans, char diag,
    int n, lua_Number *A, int lda, lua_Number *x, int incx);
int matrixW_ztrsv (char uplo, char trans, char diag,
    int n, lua_Number *A, int lda, lua_Number *x, int incx);
int matrixW_dger (int m, int n, lua_Number alpha, lua_Number *x, int incx,
    lua_Number *y, int incy, lua_Number *A, int lda);
int matrixW_zgerc (int m, int n, lua_Complex alpha, lua_Number *x, int incx,
    lua_Number *y, int incy, lua_Number *A, int lda);
int matrixW_dsyr (char uplo, int n, lua_Number alpha, lua_Number *x, int incx,
    lua_Number *A, int lda);
int matrixW_zher (char uplo, int n, lua_Number alpha, lua_Number *x, int incx,
    lua_Number *A, int lda);

/* ============================= Level 3 ============================= */

int matrixW_dgemm (char transA, char transB, int m, int n, int k,
    lua_Number alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb, lua_Number beta,
    lua_Number *C, int ldc);
int matrixW_zgemm (char transA, char transB, int m, int n, int k,
    lua_Complex alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb, lua_Complex beta,
    lua_Number *C, int ldc);
int matrixW_dsymm (char side, char uplo, int m, int n,
    lua_Number alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb, lua_Number beta,
    lua_Number *C, int ldc);
int matrixW_zhemm (char side, char uplo, int m, int n,
    lua_Complex alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb, lua_Complex beta,
    lua_Number *C, int ldc);
int matrixW_dsyrk (char uplo, char trans, int n, int k, lua_Number alpha,
    lua_Number *A, int lda, lua_Number beta, lua_Number *C, int ldc);
int matrixW_zherk (char uplo, char trans, int n, int k, lua_Number alpha,
    lua_Number *A, int lda, lua_Number beta, lua_Number *C, int ldc);
int matrixW_dtrmm (char side, char uplo, char transA, char diag,
    int m, int n, lua_Number alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb);
int matrixW_ztrmm (char side, char uplo, char transA, char diag,
    int m, int n, lua_Complex alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb);
int matrixW_dtrsm (char side, char uplo, char transA, char diag,
    int m, int n, lua_Number alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb);
int matrixW_ztrsm (char side, char uplo, char transA, char diag,
    int m, int n, lua_Complex alpha, lua_Number *A, int lda,
    lua_Number *B, int ldb);


/* {=================================================================
 *    LAPACK
 * ==================================================================} */

/* ============================ Internals ============================ */

lua_Number matrixW_dlamch (char cmach);
lua_Number matrixW_dlange (char norm, int m, int n, lua_Number *A, int lda,
    lua_Number *work);
lua_Number matrixW_zlange (char norm, int m, int n, lua_Number *A, int lda,
    lua_Number *work);
int matrixW_dlaset (char uplo, int m, int n, lua_Number alpha,
    lua_Number beta, lua_Number *A, int lda);
int matrixW_zlaset (char uplo, int m, int n, lua_Complex alpha,
    lua_Complex beta, lua_Number *A, int lda);

/* ============================= General ============================= */

int matrixW_dgebal (char job, int n, lua_Number *A, int lda,
    int *ilo, int *ihi, lua_Number *scale, int *info);
int matrixW_zgebal (char job, int n, lua_Number *A, int lda,
    int *ilo, int *ihi, lua_Number *scale, int *info);
int matrixW_dgecon (char norm, int n, lua_Number *A, int lda,
    lua_Number anorm, lua_Number *rcond, lua_Number *work,
    int *iwork, int *info);
int matrixW_zgecon (char norm, int n, lua_Number *A, int lda,
    lua_Number anorm, lua_Number *rcond, lua_Number *work,
    lua_Number *rwork, int *info);
int matrixW_dgetrf (int m, int n, lua_Number *A, int lda, int *ipiv,
    int *info);
int matrixW_zgetrf (int m, int n, lua_Number *A, int lda, int *ipiv,
    int *info);
int matrixW_dgetri(int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int lwork, int *info);
int matrixW_zgetri(int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int lwork, int *info);
int matrixW_dgetrs (char trans, int n, int nrhs, lua_Number *A, int lda,
    int *ipiv, lua_Number *B, int ldb, int *info);
int matrixW_zgetrs (char trans, int n, int nrhs, lua_Number *A, int lda,
    int *ipiv, lua_Number *B, int ldb, int *info);
int matrixW_dgesvd (char jobu, char jobvt, int m, int n, lua_Number *A,
    int lda, lua_Number *S, lua_Number *U, int ldu, lua_Number *Vt,
    int ldvt, lua_Number *work, int lwork, int *info);
int matrixW_zgesvd (char jobu, char jobvt, int m, int n, lua_Number *A,
    int lda, lua_Number *S, lua_Number *U, int ldu, lua_Number *Vt,
    int ldvt, lua_Number *work, int lwork, lua_Number *rwork, int *info);
int matrixW_dgelsy (int m, int n, int nrhs, lua_Number *A, int lda,
    lua_Number *B, int ldb, int *jpvt, lua_Number rcond, int *rank,
    lua_Number *work, int lwork, int *info);
int matrixW_zgelsy (int m, int n, int nrhs, lua_Number *A, int lda,
    lua_Number *B, int ldb, int *jpvt, lua_Number rcond, int *rank,
    lua_Number *work, int lwork, lua_Number *rwork, int *info);
int matrixW_dgelss (int m, int n, int nrhs, lua_Number *A,
    int lda, lua_Number *B, int ldb, lua_Number *s,
    lua_Number rcond, int *rank, lua_Number *work, int lwork, int *info);
int matrixW_zgelss (int m, int n, int nrhs, lua_Number *A,
    int lda, lua_Number *B, int ldb, lua_Number *s,
    lua_Number rcond, int *rank, lua_Number *work, int lwork,
    lua_Number *rwork, int *info);
int matrixW_dgeqrf (int m, int n, lua_Number *A, int lda, lua_Number *tau,
    lua_Number *work, int lwork, int *info);
int matrixW_zgeqrf (int m, int n, lua_Number *A, int lda, lua_Number *tau,
    lua_Number *work, int lwork, int *info);
int matrixW_dgeqp3 (int m, int n, lua_Number *A, int lda, int *jpvt,
    lua_Number *tau, lua_Number *work, int lwork, int *info);
int matrixW_zgeqp3 (int m, int n, lua_Number *A, int lda, int *jpvt,
    lua_Number *tau, lua_Number *work, int lwork, lua_Number *rwork,
    int *info);
int matrixW_dorgqr (int m, int n, int k, lua_Number *A, int lda,
    lua_Number *tau, lua_Number *work, int lwork, int *info);
int matrixW_zungqr (int m, int n, int k, lua_Number *A, int lda,
    lua_Number *tau, lua_Number *work, int lwork, int *info);
int matrixW_dormqr (char size, char trans, int m, int n, int k, lua_Number *A,
    int lda, lua_Number *tau, lua_Number *C, int ldc, lua_Number *work,
    int lwork, int *info);
int matrixW_zunmqr (char size, char trans, int m, int n, int k, lua_Number *A,
    int lda, lua_Number *tau, lua_Number *C, int ldc, lua_Number *work,
    int lwork, int *info);
int matrixW_dgeev (char jobvl, char jobvr, int n, lua_Number *A, int lda,
    lua_Number *wr, lua_Number *wi, lua_Number *vl, int ldvl,
    lua_Number *vr, int ldvr, lua_Number *work, int lwork, int *info);
int matrixW_zgeev (char jobvl, char jobvr, int n, lua_Number *A, int lda,
    lua_Number *w, lua_Number *vl, int ldvl, lua_Number *vr, int ldvr,
    lua_Number *work, int lwork, lua_Number *rwork, int *info);

/* ============================ Posdef Symm ========================== */

int matrixW_dpocon (char uplo, int n, lua_Number *A, int lda,
    lua_Number anorm, lua_Number *rcond, lua_Number *work,
    int *iwork, int *info);
int matrixW_zpocon (char uplo, int n, lua_Number *A, int lda,
    lua_Number anorm, lua_Number *rcond, lua_Number *work,
    lua_Number *rwork, int *info);
int matrixW_dpotrf (char uplo, int n, lua_Number *A, int lda, int *info);
int matrixW_zpotrf (char uplo, int n, lua_Number *A, int lda, int *info);
int matrixW_dpotri (char uplo, int n, lua_Number *A, int lda, int *info);
int matrixW_zpotri (char uplo, int n, lua_Number *A, int lda, int *info);
int matrixW_dpotrs (char uplo, int n, int nrhs, lua_Number *A, int lda,
    lua_Number *B, int ldb, int *info);
int matrixW_zpotrs (char uplo, int n, int nrhs, lua_Number *A, int lda,
    lua_Number *B, int ldb, int *info);

/* ============================= Symmetric =========================== */

int matrixW_dsycon (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number anorm, lua_Number *rcond, lua_Number *work,
    int *iwork, int *info);
int matrixW_zhecon (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number anorm, lua_Number *rcond, lua_Number *work, int *info);
int matrixW_dsytrf (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int lwork, int *info);
int matrixW_zhetrf (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int lwork, int *info);
int matrixW_dsytri (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int *info);
int matrixW_zhetri (char uplo, int n, lua_Number *A, int lda, int *ipiv,
    lua_Number *work, int *info);
int matrixW_dsytrs (char uplo, int n, int nrhs, lua_Number *A, int lda,
    int *ipiv, lua_Number *B, int ldb, int *info);
int matrixW_zhetrs (char uplo, int n, int nrhs, lua_Number *A, int lda,
    int *ipiv, lua_Number *B, int ldb, int *info);
int matrixW_dsyev (char jobz, char uplo, int n, lua_Number *A, int lda,
    lua_Number *w, lua_Number *work, int lwork, int *info);
int matrixW_zheev (char jobz, char uplo, int n, lua_Number *A, int lda,
    lua_Number *w, lua_Number *work, int lwork, lua_Number *rwork,
    int *info);

/* ============================ Triangular =========================== */

int matrixW_dtrcon (char norm, char uplo, char diag, int n,
    lua_Number *A, int lda, lua_Number *rcond, lua_Number *work,
    int *iwork, int *info);
int matrixW_ztrcon (char norm, char uplo, char diag, int n,
    lua_Number *A, int lda, lua_Number *rcond, lua_Number *work,
    lua_Number *rwork, int *info);
int matrixW_dtrtri (char uplo, char diag, int n,
    lua_Number *A, int lda, int *info);
int matrixW_ztrtri (char uplo, char diag, int n,
    lua_Number *A, int lda, int *info);
int matrixW_dtrtrs (char uplo, char trans, char diag, int n, int nrhs,
    lua_Number *A, int lda, lua_Number *B, int ldb, int *info);
int matrixW_ztrtrs (char uplo, char trans, char diag, int n, int nrhs,
    lua_Number *A, int lda, lua_Number *B, int ldb, int *info);

#endif

