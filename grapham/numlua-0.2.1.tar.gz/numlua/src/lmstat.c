/* {=================================================================
 * 
 * LuaMatrix statistics methods
 * See Copyright Notice in luamatrix.h
 * $Id: lmstat.c,v 1.6 2006-09-11 02:25:38 carvalho Exp $
 *  
 * ==================================================================} */

#include <lauxlib.h>

#include "luamatrix.h"
#include "lmaux.h"

/* {=================================================================
 *    Methods
 * ==================================================================} */

static int sum_matrix (lua_State *L) {
  /* only matrix on stack */
  lua_Matrix *M = matrix_checktype(L, 1);
  int stride = matrix_stride(M);
  int i, size = matrixA_datasize(M) * stride;
  if (M->complex == LM_REAL) {
    lua_Number s = 0;
    for (i = 0; i < size; i += stride) s += M->data[i];
    lua_pushnumber(L, s);
  }
  else {
    lua_Number sr = 0, si = 0;
    size *= 2; stride *= 2;
    for (i = 0; i < size; i += stride) {
      sr += M->data[i];
      si += M->data[i + 1];
    }
    complex_push(L, sr, si);
  }
  return 1;
}

static int prod_matrix (lua_State *L) {
  /* only matrix on stack */
  lua_Matrix *M = matrix_checktype(L, 1);
  int stride = matrix_stride(M);
  int i, size = matrixA_datasize(M) * stride;
  if (M->complex == LM_REAL) {
    lua_Number p = 1;
    for (i = 0; i < size; i += stride) p *= M->data[i];
    lua_pushnumber(L, p);
  }
  else {
    lua_Number t, pr = 1, pi = 0;
    size *= 2; stride *= 2;
    for (i = 0; i < size; i += stride) {
      t = pr * M->data[i] - pi * M->data[i + 1];
      pi = pr * M->data[i + 1] + pi * M->data[i];
      pr = t;
    }
    complex_push(L, pr, pi);
  }
  return 1;
}

static int min_matrix (lua_State *L) {
  /* only matrix on stack */
  lua_Matrix *M = matrix_checktype(L, 1);
  int stride = matrix_stride(M);
  int i, index, size = matrixA_datasize(M) * stride;
  if (M->complex == LM_REAL) {
    lua_Number m = M->data[0];
    index = 0;
    for (i = 1; i < size; i += stride)
      if (m > M->data[i]) {
        m = M->data[i];
        index = i;
      }
    lua_pushnumber(L, m);
  }
  else {
    lua_Complex *c = (lua_Complex *) M->data;
    index = 0;
    size *= 2; stride *= 2;
    for (i = 2; i < size; i += stride)
      if (complex_lt((lua_Complex *) (M->data + i), c)) {
        c = (lua_Complex *) (M->data + i);
        index = i;
      }
    complex_push(L, c->r, c->i);
  }
  lua_pushinteger(L, index / stride + 1);
  return 2;
}
    
static int max_matrix (lua_State *L) {
  /* only matrix on stack */
  lua_Matrix *M = matrix_checktype(L, 1);
  int stride = matrix_stride(M);
  int i, index, size = matrixA_datasize(M) * stride;
  if (M->complex == LM_REAL) {
    lua_Number m = M->data[0];
    index = 0;
    for (i = 1; i < size; i += stride)
      if (m < M->data[i]) {
        m = M->data[i];
        index = i;
      }
    lua_pushnumber(L, m);
  }
  else {
    lua_Complex *c = (lua_Complex *) M->data;
    index = 0;
    size *= 2; stride *= 2;
    for (i = 2; i < size; i += stride)
      if (complex_lt(c, (lua_Complex *) (M->data + i))) {
        c = (lua_Complex *) (M->data + i);
        index = i;
      }
    complex_push(L, c->r, c->i);
  }
  lua_pushinteger(L, index / stride + 1);
  return 2;
}

static int cumsum_matrix (lua_State *L) {
  lua_Matrix *C, *M = matrix_checktype(L, 1);
  int i, size = matrixA_datasize(M);
  int stride = matrix_stride(M);
  C = matrix_copyshallow(L, M, M->complex);
  if (M->complex == LM_REAL) {
    C->data[0] = M->data[0];
    for (i = 1; i < size; i++)
      C->data[i] = C->data[i - 1] + M->data[i * stride];
  }
  else {
    size *= 2;
    C->data[0] = M->data[0];
    C->data[1] = M->data[1];
    for (i = 2; i < size; i += 2) {
      C->data[i] = C->data[i - 2] + M->data[i * stride];
      C->data[i + 1] = C->data[i - 1] + M->data[i * stride + 1];
    }
  }
  return 1;
}

static int cumprod_matrix (lua_State *L) {
  lua_Matrix *C, *M = matrix_checktype(L, 1);
  int i, size = matrixA_datasize(M);
  int stride = matrix_stride(M);
  C = matrix_copyshallow(L, M, M->complex);
  if (M->complex == LM_REAL) {
    C->data[0] = M->data[0];
    for (i = 1; i < size; i++)
      C->data[i] = C->data[i - 1] * M->data[i * stride];
  }
  else {
    size *= 2;
    C->data[0] = M->data[0];
    C->data[1] = M->data[1];
    for (i = 2; i < size; i += 2) {
      C->data[i] = C->data[i - 2] * M->data[i * stride]
        - C->data[i - 1] * M->data[i * stride + 1];
      C->data[i + 1] = C->data[i - 1] * M->data[i * stride + 1]
        + C->data[i - 1] * M->data[i * stride];
    }
  }
  return 1;
}

/* Quicksort: adapted from ltablib.c */

static void swap_pos (lua_Number *a, int i, int j) {
  lua_Number t = a[i]; a[i] = a[j]; a[j] = t;
}

static int sort_comp (lua_State *L, int a, int b) {
  if (!lua_isnil(L, 2)) { /* function? */
    int res;
    lua_pushvalue(L, 2);
    lua_pushvalue(L, a - 1); /* -1 to compensate function */
    lua_pushvalue(L, b - 2); /* -2 to compensate function and `a' */
    lua_call(L, 2, 1);
    res = lua_toboolean(L, -1);
    lua_pop(L, 1);
    return res;
  }
  else /* a < b? */
    return lua_lessthan(L, a, b);
}

/* sorts a lua_Number *_a_ in place, from index _l_ to _u_
 * assumes a function or nil at stack position 2 */
static void matrixS_sort (lua_State *L, lua_Number *a, int l, int u) {
  while (l < u) { /* for tail recursion */
    int i, j;
    /* sort elements a[l], a[(l+u)/2] and a[u] */
    lua_pushnumber(L, a[l]);
    lua_pushnumber(L, a[u]);
    if (sort_comp(L, -1, -2)) /* a[u] < a[l]? */
      swap_pos(a, l, u); /* swap a[l] - a[u] */
    lua_pop(L, 2);
    if (u - l == 1) break; /* only 2 elements */
    i = (l + u) / 2;
    lua_pushnumber(L, a[i]);
    lua_pushnumber(L, a[l]);
    if (sort_comp(L, -2, -1)) { /* a[i]<a[l]? */
      swap_pos(a, i, l);
      lua_pop(L, 2);
    }
    else {
      lua_pop(L, 1); /* remove a[l] */
      lua_pushnumber(L, a[u]);
      if (sort_comp(L, -1, -2)) /* a[u]<a[i]? */
        swap_pos(a, i, u);
      lua_pop(L, 2);
    }
    if (u - l == 2) break; /* only 3 elements */
    lua_pushnumber(L, a[i]); /* Pivot */
    swap_pos(a, i, u - 1);
    /* a[l] <= P == a[u-1] <= a[u], only need to sort from l+1 to u-2 */
    i = l; j = u - 1;
    for (;;) { /* invariant: a[l..i] <= P <= a[j..u] */
      /* repeat ++i until a[i] >= P */
      while (lua_pushnumber(L, a[++i]), sort_comp(L, -1, -2)) {
        if (i > u) luaL_error(L, "invalid order function for sorting");
        lua_pop(L, 1); /* remove a[i] */
      }
      /* repeat --j until a[j] <= P */
      while (lua_pushnumber(L, a[--j]), sort_comp(L, -3, -1)) {
        if (j < l) luaL_error(L, "invalid order function for sorting");
        lua_pop(L, 1); /* remove a[j] */
      }
      if (j < i) {
        lua_pop(L, 3); /* pop pivot, a[i], a[j] */
        break;
      }
      a[i] = lua_tonumber(L, -1);
      a[j] = lua_tonumber(L, -2);
      lua_pop(L, 2);
    }
    swap_pos(a, u - 1, i); /* swap pivot (a[u-1]) with a[i] */
    /* a[l..i-1] <= a[i] == P <= a[i+1..u] */
    /* adjust so that smaller half is in [j..i] and larger one in [l..u] */
    if (i - l < u - i) {
      j = l; i = i - 1; l = i + 2;
    }
    else {
      j = i + 1; i = u; u = j - 2;
    }
    matrixS_sort(L, a, j, i);   /* call recursively the smaller one */
  } /* repeat the routine for the larger one */
}

static int sort_matrix (lua_State *L) {
  lua_Matrix *M = matrix_checktype(L, 1);
  int size = matrixA_datasize(M);
  /* FIXME: TODO */
  if (M->complex == LM_COMPLEX)
    luaL_error(L, "matrix is not real");
  if (!lua_isnoneornil(L, 2))   /* second argument? */
    luaL_checktype(L, 2, LUA_TFUNCTION);
  lua_settop(L, 2);       /* make two arguments */
  matrixS_sort(L, M->data, 0, size - 1);
  return 0;
}


/* {=================================================================
 *    Interface
 * ==================================================================} */

static const luaL_reg stat_func[] = {
  {"sum", sum_matrix},
  {"prod", prod_matrix},
  {"min", min_matrix},
  {"max", max_matrix},
  {"cumsum", cumsum_matrix},
  {"cumprod", cumprod_matrix},
  {"sort", sort_matrix},
  {NULL, NULL}
};

int stat_open (lua_State *L) {
  luaL_register(L, NULL, stat_func);
  return 0;
}

