/* {=================================================================
 *
 * Buffer routines for lua_Matrix
 * See Copyright Notice in luamatrix.h
 * $Id: lmbuffer.h,v 1.1 2006-09-11 02:25:38 carvalho Exp $
 *
 * ==================================================================} */

#ifndef lmbuffer_h
#define lmbuffer_h

#include <lua.h>
#include <lauxlib.h>

#define LM_NBUF_BUSY "_lm_nbuf_busy"
#define LM_NBUF_FREE "_lm_nbuf_free"
#define LM_IBUF_BUSY "_lm_ibuf_busy"
#define LM_IBUF_FREE "_lm_ibuf_free"

typedef struct {
  lua_Number *data;
  size_t size;
} lm_numbuffer;

typedef struct {
  lua_Integer *data;
  size_t size;
} lm_intbuffer;

void matrixB_newbuffer (lua_State *L);
lm_numbuffer *matrixB_getnumbuffer (lua_State *L, int pos, size_t size);
int matrixB_freenumbuffer (lua_State *L, int pos, lm_numbuffer *nb);
lm_intbuffer *matrixB_getintbuffer (lua_State *L, int pos, size_t size);
int matrixB_freeintbuffer (lua_State *L, int pos, lm_intbuffer *ib);

#endif
