#ifndef fnlib_h
#define fnlib_h

/* {=================================================================
 *    Internals
 * ==================================================================} */

/*  DLAMCH determines double precision machine parameters.
 *  *
 *  *  Arguments
 *  *  =========
 *  *
 *  *  CMACH   (input) CHARACTER*1
 *  *          Specifies the value to be returned by DLAMCH:
 *  *          = 'E' or 'e',   DLAMCH := eps
 *  *          = 'S' or 's ,   DLAMCH := sfmin
 *  *          = 'B' or 'b',   DLAMCH := base
 *  *          = 'P' or 'p',   DLAMCH := eps*base
 *  *          = 'N' or 'n',   DLAMCH := t
 *  *          = 'R' or 'r',   DLAMCH := rnd
 *  *          = 'M' or 'm',   DLAMCH := emin
 *  *          = 'U' or 'u',   DLAMCH := rmin
 *  *          = 'L' or 'l',   DLAMCH := emax
 *  *          = 'O' or 'o',   DLAMCH := rmax
*/
double dlamch_ (char *cmach, int lcmach);

/*   D1MACH can be used to obtain machine-dependent parameters for the
 *   local machine environment.  It is a function subprogram with one
 *   (input) argument, and can be referenced as follows:
 *
 *        D = D1MACH(I)
 *
 *   where I=1,...,5.  The (output) value of D above is determined by
 *   the (input) value of I.  The results for various values of I are
 *   discussed below.
 *
 *   D1MACH( 1) = B**(EMIN-1), the smallest positive magnitude.
 *   D1MACH( 2) = B**EMAX*(1 - B**(-T)), the largest magnitude.
 *   D1MACH( 3) = B**(-T), the smallest relative spacing.
 *   D1MACH( 4) = B**(1-T), the largest relative spacing.
 *   D1MACH( 5) = LOG10(B)
 */
double d1mach_(int *i);

/*   I1MACH can be used to obtain machine-dependent parameters for the
 *   local machine environment.  It is a function subprogram with one
 *   (input) argument and can be referenced as follows:
 *
 *        K = I1MACH(I)
 *
 *   where I=1,...,16.  The (output) value of K above is determined by
 *   the (input) value of I.  The results for various values of I are
 *   discussed below.
 *
 *   I/O unit numbers:
 *     I1MACH( 1) = the standard input unit.
 *     I1MACH( 2) = the standard output unit.
 *     I1MACH( 3) = the standard punch unit.
 *     I1MACH( 4) = the standard error message unit.
 *
 *   Words:
 *     I1MACH( 5) = the number of bits per integer storage unit.
 *     I1MACH( 6) = the number of characters per integer storage unit.
 *
 *   Integers:
 *     assume integers are represented in the S-digit, base-A form
 *
 *                sign ( X(S-1)*A**(S-1) + ... + X(1)*A + X(0) )
 *
 *                where 0 .LE. X(I) .LT. A for I=0,...,S-1.
 *     I1MACH( 7) = A, the base.
 *     I1MACH( 8) = S, the number of base-A digits.
 *     I1MACH( 9) = A**S - 1, the largest magnitude.
 *
 *   Floating-Point Numbers:
 *     Assume floating-point numbers are represented in the T-digit,
 *     base-B form
 *                sign (B**E)*( (X(1)/B) + ... + (X(T)/B**T) )
 *
 *                where 0 .LE. X(I) .LT. B for I=1,...,T,
 *                0 .LT. X(1), and EMIN .LE. E .LE. EMAX.
 *     I1MACH(10) = B, the base.
 *
 *   Single-Precision:
 *     I1MACH(11) = T, the number of base-B digits.
 *     I1MACH(12) = EMIN, the smallest exponent E.
 *     I1MACH(13) = EMAX, the largest exponent E.
 *
 *   Double-Precision:
 *     I1MACH(14) = T, the number of base-B digits.
 *     I1MACH(15) = EMIN, the smallest exponent E.
 *     I1MACH(16) = EMAX, the largest exponent E.
 */
int i1mach_ (int *i);

/* {=================================================================
 *    Bessel related
 * ==================================================================} */

/* DAI(X) calculates the double precision Airy function for double
 * precision argument X. */
double dai_ (double *x);

/* DBI(X) calculates the double precision Airy function of the
 * second kind for double precision argument X. */
double dbi_ (double *x);

/*  DBESI: Compute an N member sequence of I Bessel functions
 *         I/SUB(ALPHA+K-1)/(X), K=1,...,N or scaled Bessel functions
 *         EXP(-X)*I/SUB(ALPHA+K-1)/(X), K=1,...,N for nonnegative
 *         ALPHA and X.
 *
 *         Input      X,ALPHA are double precision
 *           X      - X .GE. 0.0D0
 *           ALPHA  - order of first member of the sequence,
 *                    ALPHA .GE. 0.0D0
 *           KODE   - a parameter to indicate the scaling option
 *                    KODE=1 returns
 *                           Y(K)=        I/sub(ALPHA+K-1)/(X),
 *                                K=1,...,N
 *                    KODE=2 returns
 *                           Y(K)=EXP(-X)*I/sub(ALPHA+K-1)/(X),
 *                                K=1,...,N
 *           N      - number of members in the sequence, N .GE. 1
 *
 *         Output     Y is double precision
 *           Y      - a vector whose first N components contain
 *                    values for I/sub(ALPHA+K-1)/(X) or scaled
 *                    values for EXP(-X)*I/sub(ALPHA+K-1)/(X),
 *                    K=1,...,N depending on KODE
 *           NZ     - number of components of Y set to zero due to
 *                    underflow,
 *                    NZ=0   , normal return, computation completed
 *                    NZ .NE. 0, last NZ components of Y set to zero,
 *                             Y(K)=0.0D0, K=N-NZ+1,...,N.
 */
void dbesi_ (double *x, double *alpha, int *kode, int *n,
    double *y, int *nz);

/*  DBESJ: Compute an N member sequence of J Bessel functions
 *         J/SUB(ALPHA+K-1)/(X), K=1,...,N for non-negative ALPHA
 *         and X.
 *
 *         Input      X,ALPHA are double precision
 *           X      - X .GE. 0.0D0
 *           ALPHA  - order of first member of the sequence,
 *                    ALPHA .GE. 0.0D0
 *           N      - number of members in the sequence, N .GE. 1
 *
 *         Output     Y is double precision
 *           Y      - a vector whose first N components contain
 *                    values for J/sub(ALPHA+K-1)/(X), K=1,...,N
 *           NZ     - number of components of Y set to zero due to
 *                    underflow,
 *                    NZ=0   , normal return, computation completed
 *                    NZ .NE. 0, last NZ components of Y set to zero,
 *                             Y(K)=0.0D0, K=N-NZ+1,...,N.
 */
void dbesj_ (double *x, double *alpha, int *n, double *y, int *nz);

/*  DBESK: Implement forward recursion on the three term recursion
 *         relation for a sequence of non-negative order Bessel
 *         functions K/SUB(FNU+I-1)/(X), or scaled Bessel functions
 *         EXP(X)*K/SUB(FNU+I-1)/(X), I=1,...,N for real, positive
 *         X and non-negative orders FNU.
 *
 *         Input      X,FNU are double precision
 *           X      - X .GT. 0.0D0
 *           FNU    - order of the initial K function, FNU .GE. 0.0D0
 *           KODE   - a parameter to indicate the scaling option
 *                    KODE=1 returns Y(I)=       K/sub(FNU+I-1)/(X),
 *                                        I=1,...,N
 *                    KODE=2 returns Y(I)=EXP(X)*K/sub(FNU+I-1)/(X),
 *                                        I=1,...,N
 *           N      - number of members in the sequence, N .GE. 1
 *
 *         Output     Y is double precision
 *           Y      - a vector whose first N components contain values
 *                    for the sequence
 *                    Y(I)=       k/sub(FNU+I-1)/(X), I=1,...,N  or
 *                    Y(I)=EXP(X)*K/sub(FNU+I-1)/(X), I=1,...,N
 *                    depending on KODE
 *           NZ     - number of components of Y set to zero due to
 *                    underflow with KODE=1,
 *                    NZ=0   , normal return, computation completed
 *                    NZ .NE. 0, first NZ components of Y set to zero
 *                             due to underflow, Y(I)=0.0D0, I=1,...,NZ
 */
void dbesk_ (double *x, double *fnu, int *kode, int *n, double *y, int *nz);

/*  DBESY: Implement forward recursion on the three term recursion
 *         relation for a sequence of non-negative order Bessel
 *         functions Y/SUB(FNU+I-1)/(X), I=1,...,N for real, positive
 *         X and non-negative orders FNU.
 *
 *         Input
 *           X      - X .GT. 0.0D0
 *           FNU    - order of the initial Y function, FNU .GE. 0.0D0
 *           N      - number of members in the sequence, N .GE. 1
 *
 *         Output
 *           Y      - a vector whose first N components contain values
 *                    for the sequence Y(I)=Y/sub(FNU+I-1)/(X), I=1,N.
 */
void dbesy_ (double *x, double *fnu, int *n, double *y, int *nz);

/* {=================================================================
 *    Legendre
 * ==================================================================} */

/*   DXLEGF: Extended-range Double-precision Legendre Functions
 *
 *   A feature of the DXLEGF subroutine for Legendre functions is
 * the use of extended-range arithmetic, a software extension of
 * ordinary floating-point arithmetic that greatly increases the
 * exponent range of the representable numbers. This avoids the
 * need for scaling the solutions to lie within the exponent range
 * of the most restrictive manufacturer's hardware. The increased
 * exponent range is achieved by allocating an integer storage
 * location together with each floating-point storage location.
 *
 *   The interpretation of the pair (X,I) where X is floating-point
 * and I is integer is X*(IR**I) where IR is the internal radix of
 * the computer arithmetic.
 *
 *   This subroutine computes one of the following vectors:
 *
 * 1. Legendre function of the first kind of negative order, either
 *    a. P(-MU1,NU,X), P(-MU1-1,NU,X), ..., P(-MU2,NU,X) or
 *    b. P(-MU,NU1,X), P(-MU,NU1+1,X), ..., P(-MU,NU2,X)
 * 2. Legendre function of the second kind, either
 *    a. Q(MU1,NU,X), Q(MU1+1,NU,X), ..., Q(MU2,NU,X) or
 *    b. Q(MU,NU1,X), Q(MU,NU1+1,X), ..., Q(MU,NU2,X)
 * 3. Legendre function of the first kind of positive order, either
 *    a. P(MU1,NU,X), P(MU1+1,NU,X), ..., P(MU2,NU,X) or
 *    b. P(MU,NU1,X), P(MU,NU1+1,X), ..., P(MU,NU2,X)
 * 4. Normalized Legendre polynomials, either
 *    a. PN(MU1,NU,X), PN(MU1+1,NU,X), ..., PN(MU2,NU,X) or
 *    b. PN(MU,NU1,X), PN(MU,NU1+1,X), ..., PN(MU,NU2,X)
 *
 * where X = COS(THETA).
 *
 *   The input values to DXLEGF are DNU1, NUDIFF, MU1, MU2, THETA,
 * and ID. These must satisfy
 *
 *    DNU1 is DOUBLE PRECISION and greater than or equal to -0.5;
 *    NUDIFF is INTEGER and non-negative;
 *    MU1 is INTEGER and non-negative;
 *    MU2 is INTEGER and greater than or equal to MU1;
 *    THETA is DOUBLE PRECISION and in the half-open interval (0,PI/2];
 *    ID is INTEGER and equal to 1, 2, 3 or 4;
 *
 * and  additionally either NUDIFF = 0 or MU2 = MU1.
 *
 *   If ID=1 and NUDIFF=0, a vector of type 1a above is computed
 * with NU=DNU1.
 *
 *   If ID=1 and MU1=MU2, a vector of type 1b above is computed
 * with NU1=DNU1, NU2=DNU1+NUDIFF and MU=MU1.
 *
 *   If ID=2 and NUDIFF=0, a vector of type 2a above is computed
 * with NU=DNU1.
 *
 *   If ID=2 and MU1=MU2, a vector of type 2b above is computed
 * with NU1=DNU1, NU2=DNU1+NUDIFF and MU=MU1.
 *
 *   If ID=3 and NUDIFF=0, a vector of type 3a above is computed
 * with NU=DNU1.
 *
 *   If ID=3 and MU1=MU2, a vector of type 3b above is computed
 * with NU1=DNU1, NU2=DNU1+NUDIFF and MU=MU1.
 *
 *   If ID=4 and NUDIFF=0, a vector of type 4a above is computed
 * with NU=DNU1.
 *
 *   If ID=4 and MU1=MU2, a vector of type 4b above is computed
 * with NU1=DNU1, NU2=DNU1+NUDIFF and MU=MU1.
 *
 *   In each case the vector of computed Legendre function values
 * is returned in the extended-range vector (PQA(I),IPQA(I)). The
 * length of this vector is either MU2-MU1+1 or NUDIFF+1.
 *
 *   Where possible, DXLEGF returns IPQA(I) as zero. In this case the
 * value of the Legendre function is contained entirely in PQA(I),
 * so it can be used in subsequent computations without further
 * consideration of extended-range arithmetic. If IPQA(I) is nonzero,
 * then the value of the Legendre function is not representable in
 * floating-point because of underflow or overflow. The program that
 * calls DXLEGF must test IPQA(I) to ensure correct usage.
 *
 *   IERROR is an error indicator. If no errors are detected, IERROR=0
 * when control returns to the calling routine. If an error is detected,
 * IERROR is returned as nonzero. The calling routine must check the
 * value of IERROR.
 *
 *   If IERROR=210 or 211, invalid input was provided to DXLEGF.
 *   If IERROR=201,202,203, or 204, invalid input was provided to DXSET.
 *   If IERROR=205 or 206, an internal consistency error occurred in
 * DXSET (probably due to a software malfunction in the library routine
 * I1MACH).
 *   If IERROR=207, an overflow or underflow of an extended-range number
 * was detected in DXADJ.
 *   If IERROR=208, an overflow or underflow of an extended-range number
 * was detected in DXC210.
 */
void dxlegf_ (double *dnu1, int *nudiff, int *mu1, int *mu2, double *theta,
    int *id, double *pqa, int *ipqa, int *ierror);

/*  To provide double-precision floating-point arithmetic with an extended
 *  exponent range. */
void dxred_ (double *x, int *ix, int *ierror);

/* {=================================================================
 *    Gamma related
 * ==================================================================} */

/* DBETA(A,B) calculates the double precision complete beta function
 * for double precision arguments A and B. */
double dbeta_ (double *a, double *b);

/* DLBETA(A,B) calculates the double precision natural logarithm of
 * the complete beta function for double precision arguments
 * A and B. */
double dlbeta_ (double *a, double *b);

/* DBINOM(N,M) calculates the double precision binomial coefficient
 * for integer arguments N and M.  The result is (N!)/((M!)(N-M)!). */
double dbinom_ (int *n, int *m);

/* DFAC(N) calculates the double precision factorial for integer 
 * argument N. */
double dfac_ (int *n);

/* DGAMMA(X) calculates the double precision complete Gamma function
 * for double precision argument X. */
double dgamma_ (double *x);

/* DLNGAM(X) calculates the double precision logarithm of the
 * absolute value of the Gamma function for double precision
 * argument X. */
double dlngam_ (double *x);

/* DPSI calculates the double precision Psi (or Digamma) function for
 * double precision argument X.  PSI(X) is the logarithmic derivative
 * of the Gamma function of X. */
double dpsi_ (double *x);

/*      DPSIFN computes a sequence of SCALED derivatives of
 *      the PSI function; i.e. for fixed X and M it computes
 *      the M-member sequence
 *
 *                    ((-1)**(K+1)/GAMMA(K+1))*PSI(K,X)
 *                       for K = N,...,N+M-1
 *
 *      where PSI(K,X) is as defined above.   For KODE=1, DPSIFN returns
 *      the scaled derivatives as described.  KODE=2 is operative only
 *      when K=0 and in that case DPSIFN returns -PSI(X) + LN(X).  That
 *      is, the logarithmic behavior for large X is removed when KODE=2
 *      and K=0.  When sums or differences of PSI functions are computed
 *      the logarithmic terms can be combined analytically and computed
 *      separately to help retain significant digits.
 *
 *         Note that CALL DPSIFN(X,0,1,1,ANS) results in
 *                   ANS = -PSI(X)
 *
 *     Input      X is DOUBLE PRECISION
 *           X      - Argument, X .gt. 0.0D0
 *           N      - First member of the sequence, 0 .le. N .le. 100
 *                    N=0 gives ANS(1) = -PSI(X)       for KODE=1
 *                                       -PSI(X)+LN(X) for KODE=2
 *           KODE   - Selection parameter
 *                    KODE=1 returns scaled derivatives of the PSI
 *                    function.
 *                    KODE=2 returns scaled derivatives of the PSI
 *                    function EXCEPT when N=0. In this case,
 *                    ANS(1) = -PSI(X) + LN(X) is returned.
 *           M      - Number of members of the sequence, M.ge.1
 *
 *    Output     ANS is DOUBLE PRECISION
 *           ANS    - A vector of length at least M whose first M
 *                    components contain the sequence of derivatives
 *                    scaled according to KODE.
 *           NZ     - Underflow flag
 *                    NZ.eq.0, A normal return
 *                    NZ.ne.0, Underflow, last NZ components of ANS are
 *                             set to zero, ANS(M-K+1)=0.0, K=1,...,NZ
 *           IERR   - Error flag
 *                    IERR=0, A normal return, computation completed
 *                    IERR=1, Input error,     no computation
 *                    IERR=2, Overflow,        X too small or N+M-1 too
 *                            large or both
 *                    IERR=3, Error,           N too large. Dimensioned
 *                            array TRMR(NMAX) is not large enough for N
 *
 *         The nominal computational accuracy is the maximum of unit
 *         roundoff (=D1MACH(4)) and 1.0D-18 since critical constants
 *         are given to only 18 digits. */
void dpsifn_ (double *x, int *n, int *kode, int *m,
    double *ans, int *nz, int *ierr);
/* Note: ans can be made a full vector */

/* {=================================================================
 *    Complex
 * ==================================================================} */

double zabs_ (double *zr, double *zi);
void zdiv_ (double *ar, double *ai, double *br, double *bi,
    double *cr, double *ci);  /* c = a/b */
void zexp_ (double *ar, double *ai, double *br, double *bi); /* b = exp(a) */
void zsqrt_ (double *ar, double *ai, double *br, double *bi); /* b = sqrt(a) */

/* {=================================================================
 *    Miscellaneous
 * ==================================================================} */

/* DCHU(A,B,X) calculates the double precision logarithmic confluent
 * hypergeometric function U(A,B,X) for double precision arguments
 * A, B, and X. */
double dchu_ (double *a, double *b, double *x);

/*  Evaluate the N-term Chebyshev series CS at X.  Adapted from
 *  a method presented in the paper by Broucke referenced below.
 *
 *       Input Arguments --
 *  X    value at which the series is to be evaluated.
 *  CS   array of N terms of a Chebyshev series.  In evaluating
 *       CS, only half the first coefficient is summed. 
 *  N    number of terms in array CS. */
double dcsevl_ (double *x, double *cs, int *n);
/* Note: cs is a vector */

/* DDAWS(X) calculates the double precision Dawson's integral
 * for double precision argument X. */
double ddaws_ (double *x);

/* DE1 calculates the double precision exponential integral, E1(X), for
 * positive double precision argument X and the Cauchy principal value
 * for negative X.  If principal values are used everywhere, then, for
 * all X,
 *
 *    E1(X) = -Ei(-X)
 * or
 *    Ei(X) = -E1(-X). */
double de1_ (double *x);  /* expint */

/* DERF(X) calculates the double precision error function for double
 * precision argument X. */
double derf_ (double *x);

/* DERFC(X) calculates the double precision complementary error function
 * for double precision argument X. */
double derfc_ (double *x);

/* DEXPRL(X) calculates the relative error exponential (EXP(X)-1)/X. */
double dexprl_ (double *x);

/* DLNREL(X) calculates the double precision natural logarithm of
 * (1.0+X) for double precision argument X.  This routine should
 * be used when X is small and accurate to calculate the logarithm
 * accurately (in the relative error sense) in the neighborhood
 * of 1.0. */
double dlnrel_ (double *x);

/* Evaluate a double precision generalization of Pochhammer's symbol
 * (A)-sub-X = GAMMA(A+X)/GAMMA(A) for double precision A and X.
 * For X a non-negative integer, POCH(A,X) is just Pochhammer's symbol.
 * This is a preliminary version that does not handle wrong arguments
 * properly and may not properly handle the case when the result is
 * computed to less than half of double precision. */
double dpoch_ (double *a, double *x);

/* Evaluate a double precision generalization of Pochhammer's symbol
 * for double precision A and X for special situations that require
 * especially accurate values when X is small in
 *        POCH1(A,X) = (POCH(A,X)-1)/X
 *                   = (GAMMA(A+X)/GAMMA(A) - 1.0)/X .
 * This specification is particularly suited for stably computing
 * expressions such as
 *        (GAMMA(A+X)/GAMMA(A) - GAMMA(B+X)/GAMMA(B))/X
 *             = POCH1(A,X) - POCH1(B,X)
 * Note that POCH1(A,0.0) = PSI(A) */
double dpoch1_ (double *a, double *x);

/* DSPENC(X) calculates the double precision Spence's integral
 * for double precision argument X.  Spence's function defined by
 *        integral from 0 to X of  -LOG(1-Y)/Y  DY.
 * For ABS(X) .LE. 1, the uniformly convergent expansion
 *        DSPENC = sum K=1,infinity  X**K / K**2     is valid.
 * This is a form of Spence's integral due to K. Mitchell which differs
 * from the definition in the NBS Handbook of Mathematical Functions.
 *
 * Spence's function can be used to evaluate much more general integral
 * forms.  For example,
 *        integral from 0 to Z of  LOG(A*X+B)/(C*X+D)  DX  =
 *             LOG(ABS(B-A*D/C))*LOG(ABS(A*(C*X+D)/(A*D-B*C)))/C
 *             - DSPENC (A*(C*Z+D)/(A*D-B*C)) / C. */
double dspenc_ (double *x); /* spence */

#endif
