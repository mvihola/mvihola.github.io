/* {=================================================================
 *
 * luacomplex.h
 * Complex number library API
 * Luis Carvalho (carvalho @ dam.brown.edu)
 * See Copyright Notice at the bottom of this file
 * $Id: luacomplex.h,v 1.3 2006/02/18 02:06:52 carvalho Exp $
 *
 * ==================================================================} */

#ifndef luacomplex_h
#define luacomplex_h

#include <lua.h>

#define LUACOMPLEX_VERSION "LuaComplex 0.2"
#define LUACOMPLEX_COPYRIGHT "Copyright (C) 2004-2005 Luis Carvalho"
#define LUACOMPLEX_AUTHORS "Luis Carvalho"

/* tags */
#define LUACOMPLEX_INTERN static
#define LUACOMPLEX_API extern

/* constants */
#define LUACOMPLEX_LIBNAME "complex"
#define LUACOMPLEX_MT "_complex"
#define LUACOMPLEX_REAL_LABEL "re"
#define LUACOMPLEX_IMAG_LABEL "im"

/* main object */
typedef struct {
  lua_Number r;
  lua_Number i;
} lua_Complex;

/* macros */
#define complex_pushzero(L) complex_push((L), (0), (0))
#define complex_checktype(L, i) (complex_to((L), (i)) != NULL)

/* api */
LUACOMPLEX_API lua_Complex *complex_to (lua_State *L, int pos);
LUACOMPLEX_API lua_Complex *complex_push (lua_State *L, lua_Number real,
    lua_Number imag);
LUACOMPLEX_API lua_Complex *complex_pushvalue (lua_State *L, int pos);
/* operations */
LUACOMPLEX_API void complex_add (lua_Complex *c, lua_Complex *a,
    lua_Complex *b);
LUACOMPLEX_API void complex_sub (lua_Complex *c, lua_Complex *a,
    lua_Complex *b);
LUACOMPLEX_API void complex_mul (lua_Complex *c, lua_Complex *a,
    lua_Complex *b);
LUACOMPLEX_API void complex_div (lua_Complex *c, lua_Complex *a,
    lua_Complex *b);
LUACOMPLEX_API int complex_eq (lua_Complex *a, lua_Complex *b);
LUACOMPLEX_API int complex_lt (lua_Complex *a, lua_Complex *b);
LUACOMPLEX_API int complex_le (lua_Complex *a, lua_Complex *b);
/* functions */
LUACOMPLEX_API lua_Number complex_abs (lua_Complex *c);
LUACOMPLEX_API lua_Number complex_arg (lua_Complex *c);
LUACOMPLEX_API void complex_exp (lua_Complex *f, lua_Complex *c);
LUACOMPLEX_API void complex_log (lua_Complex *f, lua_Complex *c);
LUACOMPLEX_API void complex_sin (lua_Complex *f, lua_Complex *c);
LUACOMPLEX_API void complex_cos (lua_Complex *f, lua_Complex *c);
LUACOMPLEX_API void complex_sqrt (lua_Complex *f, lua_Complex *c);

/* open lib */
LUACOMPLEX_API int luaopen_luacomplex (lua_State *L);


/* {=================================================================
*
* Copyright (c) 2005-2006 Luis Carvalho
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation files
* (the "Software"), to deal in the Software without restriction,
* including without limitation the rights to use, copy, modify,
* merge, publish, distribute, sublicense, and/or sell copies of the
* Software, and to permit persons to whom the Software is furnished
* to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
* BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
* CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* ==================================================================} */

#endif

