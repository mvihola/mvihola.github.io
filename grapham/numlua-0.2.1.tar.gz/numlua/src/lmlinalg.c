/* {=================================================================
 * 
 * Matrix library linear algebra methods
 * See Copyright Notice in luamatrix.h
 * $Id: lmlinalg.c,v 1.4 2006-09-11 02:25:38 carvalho Exp $
 *  
 * ==================================================================} */

#include <math.h>
#include <ctype.h>

#include <lauxlib.h>

#include "luamatrix.h"
#include "lmaux.h"
#include "lmwrap.h"
#include "lmbuffer.h"

#define MIN(a, b) (((a) > (b)) ? (b) : (a))
#define MAX(a, b) (((b) > (a)) ? (b) : (a))

static const lua_Complex complex_one = { 1.0, 0.0 };

/* {=================================================================
 *    API methods
 * ==================================================================} */

/* computes norm of matrix M, according to _norm_: 
 *    o 'M': max(abs(A[i,j]))
 *    o '1' or 'O': one norm (maximum column sum)
 *    o 'I': infinity norm (maximum row sum)
 *    o 'F' or 'E': Frobenius or two norm (square root of sum of squares)
 * */
LUAMATRIX_API lua_Number matrix_norm (lua_State *L, lua_Matrix *M,
    char norm) {
  lm_numbuffer *work = NULL;
  lua_Number mnorm;
  int m, n, lda;
  if (M->dim == 1) { /* vector? */
    m = 1; n = M->size; /* row vector */
    lda = (M->sup) ? M->sup->size : 1; /* stride */
  }
  else {
    m = lda = M->size; n = M->level[0]->size;
  }
  if ((norm != 'M') && (norm != '1') && (norm != 'O') && (norm != 'I') 
      && (norm != 'F') && (norm != 'E'))
    luaL_error(L, "unknown type of norm: %c", norm);
  if (M->complex == LM_REAL) {
    if (norm == 'I') work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX,
        M->size);
    mnorm = matrixW_dlange(norm,  /* NORM */
        m,       /* M */
        n,       /* N */
        M->data, /* A */
        lda,     /* LDA */
        (norm == 'I') ? work->data : NULL);   /* WORK */
  }
  else {
    if (norm == 'I') work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX,
        2 * M->size);
    mnorm = matrixW_zlange(norm,  /* NORM */
        m,       /* M */
        n,       /* N */
        M->data, /* A */
        lda,     /* LDA */
        (norm == 'I') ? work->data : NULL);   /* WORK */
  }
  if (norm == 'I') matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  return mnorm;
}

/* return the reciprocal of the condition number of M using 1-norm */
LUAMATRIX_API lua_Number matrix_rcond (lua_State *L, lua_Matrix *M,
    int *info) {
  lua_Number norm, rcond;
  lm_numbuffer *work, *buf;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to rcond: %d", M->dim);
  if (M->size != M->level[0]->size)
    luaL_error(L, "cannot compute rcond of non square matrix");
  /* compute rcond */
  if (istype_diagonal(M)) {
    /* note that 1 / ||M^-1||_1 = min_{i=1,n} { M[i][i] } */
    int i, index;
    if (M->complex == LM_REAL) {
      index = matrixW_idamax(M->size, M->data, M->size + 1) - 1;
      index *= M->size + 1; /* stride on diagonal */
      norm = (lua_Number) fabs(M->data[index]);
      rcond = (lua_Number) fabs(M->data[0]);
      for (i = 1; i < M->size; i++) { /* diagonal */
        rcond = MIN(rcond,
            (lua_Number) fabs(M->data[i * (M->size + 1)]));
        if (EQZERO(rcond)) break;
      }
    }
    else {
      index = matrixW_izamax(M->size, M->data, M->size + 1) - 1;
      index *= M->size + 1; /* stride on diagonal */
      norm = complex_abs((lua_Complex *) (M->data + 2 * index));
      rcond = complex_abs((lua_Complex *) M->data);
      for (i = 1; i < M->size; i++) { /* diagonal */
        rcond = MIN(rcond, complex_abs(
            (lua_Complex *) (M->data + 2 * i * (M->size + 1))));
        if (EQZERO(rcond)) break;
      }
    }
    *info = 0;
    return rcond / norm;
  }
  /* compute norm */
  if (M->complex == LM_REAL)
    norm = matrixW_dlange('1',  /* NORM */
        M->size,      /* M */
        M->size,      /* N */
        M->data,      /* A */
        M->size,      /* LDA */
        NULL);        /* WORK */
  else
    norm = matrixW_zlange('1',  /* NORM */
        M->size,      /* M */
        M->size,      /* N */
        M->data,      /* A */
        M->size,      /* LDA */
        NULL);        /* WORK */
  /* push workspace: */
  /* space needed for _work_ is 4 * N * lua_Number
   * or 2 * N * lua_Complex (both on gecon) */
  work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 4 * M->size);
  if (istype_triangular(M)) {
    char tag = (istype_upper(M)) ? LM_TAG_UPPER : LM_TAG_LOWER;
    /* compute rcond */
    if (M->complex == LM_REAL) {
      lm_intbuffer *iwork = matrixB_getintbuffer(L, LUA_ENVIRONINDEX,
          M->size);
      matrixW_dtrcon('1', /* NORM */
          tag,         /* UPLO */
          'N',         /* DIAG */
          M->size,     /* N */
          M->data,     /* A */
          M->size,     /* LDA */
          &rcond,      /* RCOND */
          work->data,  /* WORK */
          iwork->data, /* IWORK */
          info);       /* INFO */
      matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, iwork);
    }
    else {
      lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX,
          M->size);
      matrixW_ztrcon('1',   /* NORM */
          tag,         /* UPLO */
          'N',         /* DIAG */
          M->size,     /* N */
          M->data,     /* A */
          M->size,     /* LDA */
          &rcond,      /* RCOND */
          work->data,  /* WORK */
          rwork->data, /* RWORK */
          info);       /* INFO */
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
    }
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
    return rcond;
  }
  /* allocate space for factorizations */
  if (M->complex == LM_REAL) {
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size * M->size);
    matrixW_dcopy(M->size * M->size, M->data, 1, buf->data, 1);
  }
  else {
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * M->size * M->size);
    matrixW_zcopy(M->size * M->size, M->data, 1, buf->data, 1);
  }
  if (istype_symmetric(M) && istype_posdef(M)) {
    if (M->complex == LM_REAL) {
      lm_intbuffer *iwork = matrixB_getintbuffer(L, LUA_ENVIRONINDEX,
          M->size);
      matrixW_dpotrf('L', /* UPLO */
          M->size,     /* N */
          buf->data,   /* A */
          M->size,     /* LDA */
          info);       /* INFO */
      if (*info > 0) { /* M is not posdef? */
        matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, iwork);
        matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
        matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
        return 0;
      }
      matrixW_dpocon('L', /* UPLO */
          M->size,     /* N */
          buf->data,   /* A */
          M->size,     /* LDA */
          norm,        /* ANORM */
          &rcond,      /* RCOND */
          work->data,  /* WORK */
          iwork->data, /* IWORK */
          info);       /* INFO */
      matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, iwork);
    }
    else {
      lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX,
          2 * M->size);
      matrixW_zpotrf('L', /* UPLO */
          M->size,     /* N */
          buf->data,   /* A */
          M->size,     /* LDA */
          info);       /* INFO */
      if (*info > 0) { /* M is not posdef? */
        matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
        matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
        matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
        return 0;
      }
      matrixW_zpocon('L', /* UPLO */
          M->size,     /* N */
          buf->data,   /* A */
          M->size,     /* LDA */
          norm,        /* ANORM */
          &rcond,      /* RCOND */
          work->data,  /* WORK */
          rwork->data, /* RWORK */
          info);       /* INFO */
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
    }
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
    return rcond;
  }
  /* general case */
  if (M->complex == LM_REAL) {
    lm_intbuffer *iwork = matrixB_getintbuffer(L, LUA_ENVIRONINDEX, M->size);
    matrixW_dgetrf(M->size, /* M */
        M->size,     /* N */
        buf->data,   /* A */
        M->size,     /* LDA */
        iwork->data, /* IPIV */
        info);       /* INFO */
    if (*info > 0) { /* U[info,info] == 0? */
      matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, iwork);
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
      return 0;
    }
    matrixW_dgecon('1', /* NORM */
        M->size,     /* N */
        buf->data,   /* A */
        M->size,     /* LDA */
        norm,        /* ANORM */
        &rcond,      /* RCOND */
        work->data,  /* WORK */
        iwork->data, /* IWORK */
        info);       /* INFO */
    matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, iwork);
  }
  else {
    lm_numbuffer *rwork;
    lm_intbuffer *iwork = matrixB_getintbuffer(L, LUA_ENVIRONINDEX, M->size);
    matrixW_zgetrf(M->size, /* M */
        M->size,     /* N */
        buf->data,   /* A */
        M->size,     /* LDA */
        iwork->data, /* IPIV */
        info);       /* INFO */
    if (*info > 0) { /* U[info,info] == 0? */
      matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, iwork);
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
      return 0;
    }
    rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 4 * M->size);
    matrixW_zgecon('1', /* NORM */
        M->size,     /* N */
        buf->data,   /* A */
        M->size,     /* LDA */
        norm,        /* ANORM */
        &rcond,      /* RCOND */
        work->data,  /* WORK */
        rwork->data, /* RWORK */
        info);       /* INFO */
    matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, iwork);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
  }
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  return rcond;
}

/* pushes inverse of matrix M if rcond > EPS or _nil_ if rcond < EPS,
 * i.e., if M is singular to machine precision */
LUAMATRIX_API lua_Number matrix_inv (lua_State *L, lua_Matrix *M,
    lua_Number tol, int *info) {
  int lwork;
  lua_Number norm, rcond;
  lm_numbuffer *work;
  lm_intbuffer *ipiv;
  lua_Matrix *I;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to rcond: %d", M->dim);
  if (M->size != M->level[0]->size)
    luaL_error(L, "cannot invert non square matrix");
  if (tol <= 0) tol = LM_EPS;
  if (istype_diagonal(M)) {
    /* compute rcond */
    /* note that 1 / ||M^-1||_1 = min_{i=1,n} { M[i][i] } */
    int i, index;
    if (M->complex == LM_REAL) {
      index = matrixW_idamax(M->size, M->data, M->size + 1) - 1;
      index *= M->size + 1; /* stride on diagonal */
      norm = (lua_Number) fabs(M->data[index]);
      rcond = (lua_Number) fabs(M->data[0]);
      for (i = 1; i < M->size; i++) { /* diagonal */
        rcond = MIN(rcond,
            (lua_Number) fabs(M->data[i * (M->size + 1)]));
        if (EQZERO(rcond)) break;
      }
    }
    else {
      index = matrixW_izamax(M->size, M->data, M->size + 1) - 1;
      index *= M->size + 1; /* stride on diagonal */
      norm = complex_abs((lua_Complex *) (M->data + 2 * index));
      rcond = complex_abs((lua_Complex *) M->data);
      for (i = 1; i < M->size; i++) { /* diagonal */
        rcond = MIN(rcond, complex_abs(
            (lua_Complex *) (M->data + 2 * i * (M->size + 1))));
        if (EQZERO(rcond)) break;
      }
    }
    *info = (EQZERO(rcond)) ? i + 1 : 0;
    rcond /= norm;
    /* compute inverse */
    if (rcond < tol) lua_pushnil(L); /* nearly singular? */
    else {
      I = matrix_copy(L, M);
      if (M->complex == LM_REAL) {
        for (i = 0; i < M->size * M->size; i += M->size + 1)
          I->data[i] = 1.0 / M->data[i];
      }
      else {
        for (i = 0; i < 2*M->size*M->size; i += 2*(M->size + 1)) {
          norm = M->data[i] * M->data[i] +
              M->data[i + 1] * M->data[i + 1];
          I->data[i] /= norm;
          I->data[i + 1] /= -norm;
        }
      }
    }
    return rcond;
  }
  /* compute norm and optimal lwork */
  /* min space needed for _work_ is 4 * N * lua_Number
   * or 2 * N * lua_Complex (both on gecon) */
  lwork = 4 * M->size;
  if (M->complex == LM_REAL) {
    norm = matrixW_dlange('1',  /* NORM */
        M->size,    /* M */
        M->size,    /* N */
        M->data,    /* A */
        M->size,    /* LDA */
        NULL);      /* WORK */
    if (!istype_triangular(M) 
        && !(istype_symmetric(M) && istype_posdef(M))) { /* query? */
      lua_Number qwork;
      matrixW_dgetri(M->size, /* N */
          M->data,  /* A */
          M->size,  /* LDA */
          NULL,     /* IPIV */
          &qwork,   /* WORK */
          -1,       /* LWORK */
          info);    /* INFO */
      lua_number2int(lwork, qwork);
    }
  }
  else {
    norm = matrixW_zlange('1',  /* NORM */
        M->size,      /* M */
        M->size,      /* N */
        M->data,      /* A */
        M->size,      /* LDA */
        NULL);        /* WORK */
    if (!istype_triangular(M) 
        && !(istype_symmetric(M) && istype_posdef(M))) { /* query? */
      lua_Complex qwork;
      matrixW_zgetri(M->size, /* N */
          M->data,    /* A */
          M->size,    /* LDA */
          NULL,       /* IPIV */
          (lua_Number *) &qwork, /* WORK */
          -1,         /* LWORK */
          info);      /* INFO */
      lua_number2int(lwork, qwork.r);
      lwork *= 2;
    }
  }
  /* workspace: */
  work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
  if (istype_triangular(M)) {
    char tag = (istype_upper(M)) ? LM_TAG_UPPER : LM_TAG_LOWER;
    /* compute rcond */
    if (M->complex == LM_REAL) {
      lm_intbuffer *iwork = matrixB_getintbuffer(L, LUA_ENVIRONINDEX,
          M->size);
      matrixW_dtrcon('1', /* NORM */
          tag,         /* UPLO */
          'N',         /* DIAG */
          M->size,     /* N */
          M->data,     /* A */
          M->size,     /* LDA */
          &rcond,      /* RCOND */
          work->data,  /* WORK */
          iwork->data, /* IWORK */
          info);       /* INFO */
      matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, iwork);
    }
    else {
      lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX,
          M->size);
      matrixW_ztrcon('1', /* NORM */
          tag,         /* UPLO */
          'N',         /* DIAG */
          M->size,     /* N */
          M->data,     /* A */
          M->size,     /* LDA */
          &rcond,      /* RCOND */
          work->data,  /* WORK */
          rwork->data, /* RWORK */
          info);       /* INFO */
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
    }
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
    /* invert */
    if (rcond < tol) lua_pushnil(L); /* nearly singular? */
    else {
      I = matrix_copy(L, M);
      if (M->complex == LM_REAL)
        matrixW_dtrtri(tag, /* UPLO */
            'N',     /* DIAG */
            I->size, /* N */
            I->data, /* A */
            I->size, /* LDA */
            info);   /* INFO */
      else
        matrixW_ztrtri(tag, /* UPLO */
            'N',     /* DIAG */
            I->size, /* N */
            I->data, /* A */
            I->size, /* LDA */
            info);   /* INFO */
    }
    return rcond;
  }
  /* inverse matrix can be allocated now: we need some space for
   * factorizations */
  I = matrix_copy(L, M);
  if (istype_symmetric(M) && istype_posdef(M)) {
    /* decompose */
    if (M->complex == LM_REAL)
      matrixW_dpotrf('L', /* UPLO */
          I->size,   /* N */
          I->data,   /* A */
          I->size,   /* LDA */
          info);     /* INFO */
    else
      matrixW_zpotrf('L', /* UPLO */
          I->size,   /* N */
          I->data,   /* A */
          I->size,   /* LDA */
          info);     /* INFO */
    /* check early return */
    if (*info > 0) { /* U[info, info] == 0? */
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
      lua_pop(L, 1); /* I */
      lua_pushnil(L);
      return 0;
    }
    /* compute rcond */
    if (M->complex == LM_REAL) {
      lm_intbuffer *iwork = matrixB_getintbuffer(L, LUA_ENVIRONINDEX,
          M->size);
      matrixW_dpocon('L', /* UPLO */
          I->size,     /* N */
          I->data,     /* A */
          I->size,     /* LDA */
          norm,        /* ANORM */
          &rcond,      /* RCOND */
          work->data,  /* WORK */
          iwork->data, /* IWORK */
          info);       /* INFO */
      matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, iwork);
    }
    else {
      lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX,
          2 * M->size);
      matrixW_zpocon('L', /* UPLO */
          I->size,     /* N */
          I->data,     /* A */
          I->size,     /* LDA */
          norm,        /* ANORM */
          &rcond,      /* RCOND */
          work->data,  /* WORK */
          rwork->data, /* RWORK */
          info);       /* INFO */
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
    }
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
    /* invert */
    if (rcond < tol) { /* nearly singular? */
      lua_pop(L, 1); /* I */
      lua_pushnil(L);
    }
    else {
      if (M->complex == LM_REAL)
        matrixW_dpotri('L', /* UPLO */
            I->size,  /* N */
            I->data,  /* A */
            I->size,  /* LDA */
            info);    /* INFO */
      else
        matrixW_zpotri('L', /* UPLO */
            I->size,  /* N */
            I->data,  /* A */
            I->size,  /* LDA */
            info);    /* INFO */
    }
    return rcond;
  }
  /* general case */
  /* decompose */
  ipiv = matrixB_getintbuffer(L, LUA_ENVIRONINDEX, M->size);
  if (M->complex == LM_REAL)
    matrixW_dgetrf(M->size, /* M */
        I->size,    /* N */
        I->data,    /* A */
        I->size,    /* LDA */
        ipiv->data, /* IPIV */
        info);      /* INFO */
  else
    matrixW_zgetrf(M->size, /* M */
        I->size,    /* N */
        I->data,    /* A */
        I->size,    /* LDA */
        ipiv->data, /* IPIV */
        info);      /* INFO */
  /* check early return */
  if (*info > 0) { /* U[info, info] == 0? */
    matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, ipiv);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
    lua_pop(L, 1); /* I */
    lua_pushnil(L);
    return 0;
  }
  /* compute rcond */
  if (M->complex == LM_REAL) {
    lm_intbuffer *iwork = matrixB_getintbuffer(L, LUA_ENVIRONINDEX, M->size);
    matrixW_dgecon('1', /* NORM */
        I->size,     /* N */
        I->data,     /* A */
        I->size,     /* LDA */
        norm,        /* ANORM */
        &rcond,      /* RCOND */
        work->data,  /* WORK */
        iwork->data, /* IWORK */
        info);       /* INFO */
    matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, iwork);
  }
  else {
    lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX,
        4 * M->size);
    matrixW_zgecon('1', /* NORM */
        I->size,     /* N */
        I->data,     /* A */
        I->size,     /* LDA */
        norm,        /* ANORM */
        &rcond,      /* RCOND */
        work->data,  /* WORK */
        rwork->data, /* RWORK */
        info);       /* INFO */
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
  }
  /* invert */
  if (rcond < tol) { /* nearly singular? */
    lua_pop(L, 1); /* I */
    lua_pushnil(L);
  }
  else {
    if (M->complex == LM_REAL)
      matrixW_dgetri(I->size, /* N */
          I->data,     /* A */
          I->size,     /* LDA */
          ipiv->data,  /* IPIV */
          work->data,  /* WORK */
          4 * I->size, /* LWORK */
          info);       /* INFO */
    else
      matrixW_zgetri(I->size, /* N */
          I->data,     /* A */
          I->size,     /* LDA */
          ipiv->data,  /* IPIV */
          work->data,  /* WORK */
          2 * I->size, /* LWORK */
          info);       /* INFO */
  }
  matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, ipiv);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  return rcond;
}

/* given a matrix M, pushes L, U and P, where P * M = L * U, P is a
 * permutation matrix, L is lower triangular with unit diagonal and U is upper
 * triangular, returning info in params (== 0 if U[i,i] != 0 for all i and > 0
 * if U[info,info] == 0 */
LUAMATRIX_API void matrix_lu (lua_State *L, lua_Matrix *M, int *info) {
  lua_Matrix *l, *u, *p;
  lm_numbuffer *buf;
  lm_intbuffer *ipiv;
  int i, size;
  int mdim; /* MIN(M->size, M->level[0]->size) */
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to decompose: %d", M->dim);
  /* push result matrices: l, u and p */
  if (M->size > M->level[0]->size) {
    mdim = M->level[0]->size;
    l = matrix_pusharray(L, M->size, mdim, M->complex); /* push L */
    u = matrix_pusharray(L, mdim, mdim, M->complex); /* push U */
    u->type = LM_UPPER;
  }
  else {
    mdim = M->size;
    l = matrix_pusharray(L, mdim, mdim, M->complex); /* push L */
    l->type = LM_LOWER;
    /* push U */
    u = matrix_pusharray(L, mdim, M->level[0]->size, M->complex);
    if (M->size == M->level[0]->size) u->type = LM_UPPER;
  }
  p = matrix_pusharray(L, M->size, M->size, LM_REAL); /* push P */
  /* p is identity initially */
  size = M->size * M->size;
  matrixW_dscal(size, 0.0, p->data, 1);
  for (i = 0; i < size; i += M->size + 1) p->data[i] = 1.0;
  /* set ipiv */
  ipiv = matrixB_getintbuffer(L, LUA_ENVIRONINDEX, mdim);
  size = M->size * M->level[0]->size; /* datasize(M) */
  if (M->complex == LM_REAL) {
    /* push workspace, initially equal to M->data */
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, size);
    matrixW_dcopy(size, M->data, 1, buf->data, 1);
    /* decompose */
    matrixW_dgetrf(M->size, /* M */
        M->level[0]->size,  /* N */
        buf->data,          /* A */
        M->size,            /* LDA */
        ipiv->data,         /* IPIV */
        info);              /* INFO */
    /* setup l and u from data */
    for (i = 0; i < mdim; i++) {
      /* l : operate column-wise */
      int j = i * (M->size + 1); /* i-th diagonal entry */
      /* copy data below main diagonal */
      matrixW_dcopy(M->size - i - 1, buf->data + j + 1, 1,
          l->data + j + 1, 1);
      /* zeros above diagonal */
      matrixW_dscal(i, 0.0, l->data + i * M->size, 1);
      l->data[j] = 1.0; /* l is unit diagonal */
      /* u : operate row-wise*/
      /* copy data above and including main diagonal */
      matrixW_dcopy(M->level[0]->size - i, buf->data + j, M->size,
          u->data + i * (mdim + 1), mdim);
      /* zeros below diagonal */
      matrixW_dscal(i, 0.0, u->data + i, mdim);
    }
  }
  else { /* M->complex == LM_COMPLEX */
    /* push workspace, initially equal to M->data */
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * size);
    matrixW_zcopy(size, M->data, 1, buf->data, 1);
    /* decompose */
    matrixW_zgetrf(M->size, /* M */
        M->level[0]->size,  /* N */
        buf->data,          /* A */
        M->size,            /* LDA */
        ipiv->data,         /* IPIV */
        info);              /* INFO */
    /* setup l and u from data */
    for (i = 0; i < mdim; i++) {
      /* l : operate column-wise */
      int j = 2 * i * (M->size + 1); /* i-th diagonal entry */
      /* copy data below main diagonal */
      matrixW_zcopy(M->size - i - 1, buf->data + j + 2, 1,
          l->data + j + 2, 1);
      /* zeros above diagonal */
      matrixW_zdscal(i, 0.0, l->data + 2 * i * M->size, 1);
      l->data[j] = 1.0; l->data[j + 1] = 0.0; /* l is unit diagonal */
      /* u : operate row-wise*/
      /* copy data above and including main diagonal */
      matrixW_zcopy(M->level[0]->size - i, buf->data + j, M->size,
          u->data + 2 * i * (mdim + 1), mdim);
      /* zeros below diagonal */
      matrixW_zdscal(i, 0.0, u->data + 2 * i, mdim);
    }
  }
  /* setup p by switching cols according to ipiv */
  for (i = 0; i < mdim; i++) {
    int j = ipiv->data[i] - 1;
    if (i != j)
      matrixW_dswap(M->size, p->data + i * M->size, 1,
        p->data + j * M->size, 1);
  }
  matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, ipiv);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
}

/* given a matrix M, pushes a balanced version of M, _B_, and a *similarity*
 * diagonal matrix _T_ such that B = inv(T)*A*T */
/* to compensate eigenvectors -- note that M and B have the same eigenvalues
 * -- computed from B, do vM = T*vB / ||T*vB|| */
LUAMATRIX_API void matrix_balance (lua_State *L, lua_Matrix *M, int *info) {
  lua_Matrix *B, *T;
  lm_numbuffer *scale;
  int i, j, ilo, ihi;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to balance: %d", M->dim);
  if (M->size != M->level[0]->size)
    luaL_error(L, "cannot balance non square matrix");
  B = matrix_copy(L, M);
  T = matrix_pusharray(L, M->size, M->size, M->complex);
  scale = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size);
  if (M->complex == LM_REAL) {
    /* setup T */
    matrixW_dscal(T->size * T->size, 0.0, T->data, 1);
    /* balance */
    matrixW_dgebal('B', /* JOB */
        B->size,        /* N */
        B->data,        /* A */
        B->size,        /* LDA */
        &ilo,           /* ILO */
        &ihi,           /* IHI */
        scale->data,    /* SCALE */
        info);          /* INFO */
    /* compute similarity matrix */
    ilo--; ihi--; /* fix for zero offset */
    /* fill internal positions */
    matrixW_dcopy(ihi - ilo + 1, scale->data, 1, T->data, T->size + 1);
    /* swap cols */
    for (i = M->size - 1; i > ihi; i--) {
      lua_Number s = scale->data[i] - 1;
      lua_number2int(j, s);
      if (i != j)
        matrixW_dswap(T->size, T->data + i * T->size, 1,
            T->data + j * T->size, 1);
    }
    for (i = 0; i < ilo; i++) {
      lua_Number s = scale->data[i] - 1;
      lua_number2int(j, s);
      if (i != j)
        matrixW_dswap(T->size, T->data + i * T->size, 1,
            T->data + j * T->size, 1);
    }
  }
  else {
    /* setup T */
    matrixW_zdscal(M->size * M->level[0]->size, 0.0, T->data, 1);
    /* balance */
    matrixW_zgebal('B', /* JOB */
        B->size,        /* N */
        B->data,        /* A */
        B->size,        /* LDA */
        &ilo,           /* ILO */
        &ihi,           /* IHI */
        scale->data,    /* SCALE */
        info);     /* INFO */
    /* compute similarity matrix */
    ilo--; ihi--; /* fix for zero offset */
    /* fill internal positions */
    matrixW_dcopy(ihi - ilo + 1, scale->data, 1, T->data, 2 * (T->size + 1));
    /* swap cols */
    for (i = M->size - 1; i > ihi; i--) {
      lua_Number s = scale->data[i] - 1;
      lua_number2int(j, s);
      if (i != j)
        matrixW_zswap(T->size, T->data + 2 * i * T->size, 1,
            T->data + 2 * j * T->size, 1);
    }
    for (i = 0; i < ilo; i++) {
      lua_Number s = scale->data[i] - 1;
      lua_number2int(j, s);
      if (i != j)
        matrixW_zswap(T->size, T->data + 2 * i * T->size, 1,
            T->data + 2 * j * T->size, 1);
    }
  }
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, scale);
}

/* compute the Cholesky factorization of a symmetric positive definite matrix
 * M (only the upper triangle is used), pushing the result C and returning
 * info in the params; if M is not posdef, then C is of order info-1 and
 * C'*C = M[1:info-1, 1:info-1], otherwise, C is of the same order as M and
 * info = 0 */
LUAMATRIX_API void matrix_chol (lua_State *L, lua_Matrix *M, int *info) {
  lua_Matrix *C;
  int i;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to decompose: %d", M->dim);
  if (M->size != M->level[0]->size)
    luaL_error(L, "cannot decompose non square matrix");
  C = matrix_copy(L, M);
  /* decompose */
  if (M->complex == LM_REAL)
    matrixW_dpotrf('U', /* UPLO */
        C->size,  /* N */
        C->data,  /* A */
        C->size,  /* LDA */
        info);    /* INFO */
  else
    matrixW_zpotrf('U', /* UPLO */
        C->size,  /* N */
        C->data,  /* A */
        C->size,  /* LDA */
        info);    /* INFO */
  /* prepare output */
  if (*info > 0) { /* not posdef? */
    int n = (*info > 1) ? *info - 1 : 1;  /* order of R */
    lua_Matrix *R = matrix_pusharray(L, n, n, M->complex);
    if (C->complex == LM_REAL)
      for (i = 0; i < n; i++) {
        /* fill i-th column (below diagonal) with zeros */
        matrixW_dscal(n - i - 1, 0.0, R->data + 1 + i * (n + 1), 1);
        /* copy C i-th row from n-major upper triangle */
        matrixW_dcopy(n - i, C->data + i * (C->size + 1), C->size,
            R->data + i * (n + 1), n);
      }
    else
      for (i = 0; i < n; i++) {
        /* fill i-th column (below diagonal) with zeros */
        matrixW_zdscal(n - i - 1, 0.0,
            R->data + 2 * (1 + i * (n + 1)), 1);
        /* copy C i-th row from n-major upper triangle */
        matrixW_zcopy(n - i, C->data + 2 * i * (C->size + 1),
            C->size, R->data + 2 * i * (n + 1), n);
      }
    /* replace R by C */
    C = R;
    lua_replace(L, -2);
  }
  else {
    /* fill lower triangle with zeros */
    if (C->complex == LM_REAL)
      for (i = 0; i < C->size; i++)
        matrixW_dscal(C->size - i - 1, 0.0,
            C->data + 1 + i * (C->size + 1), 1);
    else
      for (i = 0; i < C->size; i++)
        matrixW_zdscal(C->size - i - 1, 0.0,
            C->data + 2 * (1 + i * (C->size + 1)), 1);
    settype_posdef(M);
  }
  C->type = LM_UPPER;
}

/* similar to above, but does not return decomposed matrix, only !info */
LUAMATRIX_API int matrix_isposdef (lua_State *L, lua_Matrix *M) {
  lm_numbuffer *buf;
  int info;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to decompose: %d", M->dim);
  if (M->size != M->level[0]->size)
    luaL_error(L, "cannot decompose non square matrix");
  /* decompose */
  if (M->complex == LM_REAL) {
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size * M->size);
    matrixW_dcopy(M->size * M->size, M->data, 1, buf->data, 1);
    matrixW_dpotrf('U', /* UPLO */
        M->size,   /* N */
        buf->data, /* A */
        M->size,   /* LDA */
        &info);    /* INFO */
  }
  else {
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * M->size * M->size);
    matrixW_zcopy(M->size * M->size, M->data, 1, buf->data, 1);
    matrixW_zpotrf('U', /* UPLO */
        M->size,   /* N */
        buf->data, /* A */
        M->size,   /* LDA */
        &info);    /* INFO */
  }
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
  return (info == 0);
}

/* compute singular values for matrix M and push a vector containing them */
LUAMATRIX_API void matrix_svdv (lua_State *L, lua_Matrix *M, int *info) {
  lua_Matrix *S;
  lm_numbuffer *work, *buf;
  int mdim, msize, lwork;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to svd: %d", M->dim);
  mdim = MIN(M->size, M->level[0]->size);
  msize = M->size * M->level[0]->size;
  S = matrix_pushvector(L, mdim, LM_REAL);
  if (M->complex == LM_REAL) {
    lua_Number qwork;
    /* copy M */
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, msize);
    matrixW_dcopy(msize, M->data, 1, buf->data, 1);
    /* query for best lwork */
    matrixW_dgesvd('N',    /* JOBU */
        'N',               /* JOBVT */
        M->size,           /* M */
        M->level[0]->size, /* N */
        buf->data,         /* A */
        M->size,           /* LDA */
        S->data,           /* S */
        NULL,              /* U */
        M->size,           /* LDU */
        NULL,              /* VT */
        M->level[0]->size, /* LDVT */
        &qwork,            /* WORK */
        -1,                /* LWORK */
        info);             /* INFO */
    lua_number2int(lwork, qwork);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
    /* compute svd */
    matrixW_dgesvd('N',    /* JOBU */
        'N',               /* JOBVT */
        M->size,           /* M */
        M->level[0]->size, /* N */
        buf->data,         /* A */
        M->size,           /* LDA */
        S->data,           /* S */
        NULL,              /* U */
        M->size,           /* LDU */
        NULL,              /* VT */
        M->level[0]->size, /* LDVT */
        work->data,        /* WORK */
        lwork,             /* LWORK */
        info);             /* INFO */
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  }
  else {
    lua_Complex qwork;
    lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 5 * mdim);
    /* copy M */
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * msize);
    matrixW_zcopy(msize, M->data, 1, buf->data, 1);
    /* query for best lwork */
    matrixW_zgesvd('N',    /* JOBU */
        'N',               /* JOBVT */
        M->size,           /* M */
        M->level[0]->size, /* N */
        buf->data,         /* A */
        M->size,           /* LDA */
        S->data,           /* S */
        NULL,              /* U */
        M->size,           /* LDU */
        NULL,              /* VT */
        M->level[0]->size, /* LDVT */
        (lua_Number *) &qwork, /* WORK */
        -1,                /* LWORK */
        rwork->data,       /* RWORK */
        info);             /* INFO */
    lua_number2int(lwork, qwork.r);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * lwork);
    /* compute svd */
    matrixW_zgesvd('N',    /* JOBU */
        'N',               /* JOBVT */
        M->size,           /* M */
        M->level[0]->size, /* N */
        buf->data,         /* A */
        M->size,           /* LDA */
        S->data,           /* S */
        NULL,              /* U */
        M->size,           /* LDU */
        NULL,              /* VT */
        M->level[0]->size, /* LDVT */
        work->data,        /* WORK */
        lwork,             /* LWORK */
        rwork->data,       /* RWORK */
        info);             /* INFO */
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
  }
}

/* compute singular values for matrix M: return matrices U, V and S such that
 * M = U * S * V*, where the diagonal elements of S are the singular values,
 * real, non-negative and in descending order, and first min(rows(M), cols(M))
 * columns of U and V are the left and right singular vectors of M.
 * Note that U is rows(M) x rows(M), S is rows(M) x cols(M), and V is cols(M)
 * x cols(M). */
LUAMATRIX_API void matrix_svd (lua_State *L, lua_Matrix *M, int *info) {
  lua_Matrix *U, *S, *V;
  lm_numbuffer *sdiag, *work, *buf;
  int i, mdim, msize, lwork;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to svd: %d", M->dim);
  mdim = MIN(M->size, M->level[0]->size);
  msize = M->size * M->level[0]->size;
  U = matrix_pusharray(L, M->size, M->size, M->complex);
  S = matrix_pusharray(L, M->size, M->level[0]->size, LM_REAL);
  matrixW_dscal(msize, 0.0, S->data, 1);
  V = matrix_pusharray(L, M->level[0]->size, M->level[0]->size,
      M->complex);
  sdiag = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, mdim);
  if (M->complex == LM_REAL) {
    lua_Number qwork;
    /* copy M */
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, msize);
    matrixW_dcopy(msize, M->data, 1, buf->data, 1);
    /* query for best lwork */
    matrixW_dgesvd('N',    /* JOBU */
        'N',               /* JOBVT */
        M->size,           /* M */
        M->level[0]->size, /* N */
        buf->data,         /* A */
        M->size,           /* LDA */
        sdiag->data,       /* S */
        NULL,              /* U */
        M->size,           /* LDU */
        NULL,              /* VT */
        M->level[0]->size, /* LDVT */
        &qwork,            /* WORK */
        -1,                /* LWORK */
        info);             /* INFO */
    lua_number2int(lwork, qwork);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
    /* compute svd */
    matrixW_dgesvd('A',    /* JOBU */
        'A',               /* JOBVT */
        M->size,           /* M */
        M->level[0]->size, /* N */
        buf->data,         /* A */
        M->size,           /* LDA */
        sdiag->data,       /* S */
        U->data,           /* U */
        U->size,           /* LDU */
        V->data,           /* VT */
        V->size,           /* LDVT */
        work->data,        /* WORK */
        lwork,             /* LWORK */
        info);             /* INFO */
    /* transpose V */
    for (i = 0; i < V->size - 1; i++)
      matrixW_dswap(V->size - i - 1,
          V->data + 1 + i * (V->size + 1), 1,
          V->data + V->size + i * (V->size + 1), V->size);
  }
  else {
    lua_Complex qwork;
    lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 5 * mdim);
    /* copy M */
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * msize);
    matrixW_zcopy(msize, M->data, 1, buf->data, 1);
    /* query for best lwork */
    matrixW_zgesvd('N',    /* JOBU */
        'N',               /* JOBVT */
        M->size,           /* M */
        M->level[0]->size, /* N */
        buf->data,         /* A */
        M->size,           /* LDA */
        sdiag->data,       /* S */
        NULL,              /* U */
        M->size,           /* LDU */
        NULL,              /* VT */
        M->level[0]->size, /* LDVT */
        (lua_Number *) &qwork, /* WORK */
        -1,                /* LWORK */
        rwork->data,       /* RWORK */
        info);             /* INFO */
    lua_number2int(lwork, qwork.r);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * lwork);
    /* compute svd */
    matrixW_zgesvd('A',    /* JOBU */
        'A',               /* JOBVT */
        M->size,           /* M */
        M->level[0]->size, /* N */
        buf->data,         /* A */
        M->size,           /* LDA */
        sdiag->data,       /* S */
        U->data,           /* U */
        U->size,           /* LDU */
        V->data,           /* VT */
        V->size,           /* LDVT */
        work->data,        /* WORK */
        lwork,             /* LWORK */
        rwork->data,       /* RWORK */
        info);             /* INFO */
    /* transpose V */
    for (i = 0; i < V->size - 1; i++)
      matrixW_zswap(V->size - i - 1,
          V->data + 2 * (1 + i * (V->size + 1)), 1,
          V->data + 2 * (V->size + i * (V->size + 1)), V->size);
    /* conjugate V */
    matrixW_dscal(V->size * V->size, -1.0, V->data + 1, 2);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
  }
  /* copy sdiag to S diagonal */
  matrixW_dcopy(mdim, sdiag->data, 1, S->data, S->size + 1);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, sdiag);
}

/* computes the QR factorization of M, that is, for M a m x n matrix, returns
 * Q unitary m x m matrix and R upper trapezoidal m x n matrix such that
 * M = Q * R. */
LUAMATRIX_API void matrix_qr (lua_State *L, lua_Matrix *M, int *info) {
  lua_Matrix *Q, *R;
  lm_numbuffer *buf, *tau, *work;
  int i, mdim, msize, lwork;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to qr: %d", M->dim);
  mdim = MIN(M->size, M->level[0]->size);
  msize = M->size * M->level[0]->size;
  Q = matrix_pusharray(L, M->size, M->size, M->complex);
  R = matrix_pusharray(L, M->size, M->level[0]->size, M->complex);
  if (M->complex == LM_REAL) {
    lua_Number qwork;
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, msize);
    matrixW_dcopy(msize, M->data, 1, buf->data, 1);
    tau = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, mdim);
    /* query */
    matrixW_dgeqrf(M->size, /* M */
        M->level[0]->size,  /* N */
        buf->data,          /* A */
        M->size,            /* LDA */
        tau->data,          /* TAU */
        &qwork,             /* WORK */
        -1,                 /* LWORK */
        info);              /* INFO */
    /* compute */
    lua_number2int(lwork, qwork);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
    matrixW_dgeqrf(M->size, /* M */
        M->level[0]->size,  /* N */
        buf->data,          /* A */
        M->size,            /* LDA */
        tau->data,          /* TAU */
        work->data,         /* WORK */
        lwork,              /* LWORK */
        info);              /* INFO */
    /* build R and Q from data */
    for (i = 0; i < mdim; i++) {
      /* copy data's upper trapezoid to R */
      matrixW_dcopy(M->level[0]->size - i,
          buf->data + i * (M->size + 1), M->size,
          R->data + i * (R->size + 1), R->size);
      /* fill R's lower trapezoid with zeros */
      matrixW_dscal(M->size - i - 1, 0.0,
          R->data + 1 + i * (R->size + 1), 1);
      /* copy data's lower trapezoid to Q */
      matrixW_dcopy(M->size - i - 1,
          buf->data + 1 + i * (M->size + 1), 1,
          Q->data + 1 + i * (Q->size + 1), 1);
    }
    /* build Q */
    matrixW_dorgqr(M->size, /* M */
        M->size,            /* N */
        mdim,               /* K */
        Q->data,            /* A */
        M->size,            /* LDA */
        tau->data,          /* TAU */
        work->data,         /* WORK */
        lwork,              /* LWORK */
        info);              /* INFO */
  }
  else {
    lua_Complex qwork;
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * msize);
    matrixW_zcopy(msize, M->data, 1, buf->data, 1);
    tau = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * mdim);
    /* query */
    matrixW_zgeqrf(M->size, /* M */
        M->level[0]->size,  /* N */
        buf->data,          /* A */
        M->size,            /* LDA */
        tau->data,          /* TAU */
        (lua_Number *) &qwork, /* WORK */
        -1,                 /* LWORK */
        info);              /* INFO */
    /* compute */
    lua_number2int(lwork, qwork.r);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * lwork);
    matrixW_zgeqrf(M->size, /* M */
        M->level[0]->size,  /* N */
        buf->data,          /* A */
        M->size,            /* LDA */
        tau->data,          /* TAU */
        work->data,         /* WORK */
        lwork,              /* LWORK */
        info);              /* INFO */
    /* build R and Q from data */
    for (i = 0; i < mdim; i++) {
      /* copy data's upper trapezoid to R */
      matrixW_zcopy(M->level[0]->size - i,
          buf->data + 2 * i * (M->size + 1), M->size,
          R->data + 2 * i * (R->size + 1), R->size);
      /* fill R's lower trapezoid with zeros */
      matrixW_zdscal(M->size - i - 1, 0.0,
          R->data + 2 * (1 + i * (R->size + 1)), 1);
      /* copy data's lower trapezoid to Q */
      matrixW_zcopy(M->size - i - 1,
          buf->data + 2 * (1 + i * (M->size + 1)), 1,
          Q->data + 2 * (1 + i * (Q->size + 1)), 1);
    }
    /* build Q */
    matrixW_zungqr(M->size, /* M */
        M->size,            /* N */
        mdim,               /* K */
        Q->data,            /* A */
        M->size,            /* LDA */
        tau->data,          /* TAU */
        work->data,         /* WORK */
        lwork,              /* LWORK */
        info);              /* INFO */
  }
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, tau);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
}

/* computes the QR factorization of M with column permutation, that is, for
 * M a m x n matrix, returns Q unitary m x m matrix, R upper trapezoidal
 * m x n matrix, and P a permutation n x n matrix such that M * P = Q * R. */
LUAMATRIX_API void matrix_qrp (lua_State *L, lua_Matrix *M, int *info) {
  lua_Matrix *Q, *R, *P;
  lm_numbuffer *buf, *tau, *work;
  lm_intbuffer *jpvt;
  int i, lwork, mdim, msize;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension to qr: %d", M->dim);
  mdim = MIN(M->size, M->level[0]->size);
  msize = M->size * M->level[0]->size;
  Q = matrix_pusharray(L, M->size, M->size, M->complex);
  R = matrix_pusharray(L, M->size, M->level[0]->size, M->complex);
  P = matrix_pusharray(L, M->level[0]->size, M->level[0]->size, LM_REAL);
  jpvt = matrixB_getintbuffer(L, LUA_ENVIRONINDEX, M->level[0]->size);
  /* setup jpvt and P */
  matrixW_dscal(P->size * P->size, 0.0, P->data, 1);
  for (i = 0; i < P->size; jpvt->data[i++] = 0);
  if (M->complex == LM_REAL) {
    lua_Number qwork;
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, msize);
    matrixW_dcopy(msize, M->data, 1, buf->data, 1);
    tau = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, mdim);
    /* query */
    matrixW_dgeqp3(M->size, /* M */
        M->level[0]->size,  /* N */
        buf->data,          /* A */
        M->size,            /* LDA */
        jpvt->data,         /* JPVT */
        tau->data,          /* TAU */
        &qwork,             /* WORK */
        -1,                 /* LWORK */
        info);              /* INFO */
    /* compute */
    lua_number2int(lwork, qwork);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
    matrixW_dgeqp3(M->size, /* M */
        M->level[0]->size,  /* N */
        buf->data,          /* A */
        M->size,            /* LDA */
        jpvt->data,         /* JPVT */
        tau->data,          /* TAU */
        work->data,         /* WORK */
        lwork,              /* LWORK */
        info);              /* INFO */
    /* build R and Q from data */
    for (i = 0; i < mdim; i++) {
      /* copy data's upper trapezoid to R */
      matrixW_dcopy(M->level[0]->size - i,
          buf->data + i * (M->size + 1), M->size,
          R->data + i * (R->size + 1), R->size);
      /* fill R's lower trapezoid with zeros */
      matrixW_dscal(M->size - i - 1, 0.0,
          R->data + 1 + i * (R->size + 1), 1);
      /* copy data's lower trapezoid to Q */
      matrixW_dcopy(M->size - i - 1,
          buf->data + 1 + i * (M->size + 1), 1,
          Q->data + 1 + i * (Q->size + 1), 1);
    }
    /* build Q */
    matrixW_dorgqr(M->size, /* M */
        M->size,            /* N */
        mdim,               /* K */
        Q->data,            /* A */
        M->size,            /* LDA */
        tau->data,          /* TAU */
        work->data,         /* WORK */
        lwork,              /* LWORK */
        info);              /* INFO */
  }
  else {
    lua_Complex qwork;
    lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX,
        2 * M->level[0]->size);
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * msize);
    matrixW_zcopy(msize, M->data, 1, buf->data, 1);
    tau = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * mdim);
    /* query */
    matrixW_zgeqp3(M->size, /* M */
        M->level[0]->size,  /* N */
        buf->data,          /* A */
        M->size,            /* LDA */
        jpvt->data,         /* JPVT */
        tau->data,          /* TAU */
        (lua_Number *) &qwork, /* WORK */
        -1,                 /* LWORK */
        rwork->data,        /* RWORK */
        info);              /* INFO */
    /* compute */
    lua_number2int(lwork, qwork.r);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * lwork);
    matrixW_zgeqp3(M->size, /* M */
        M->level[0]->size,  /* N */
        buf->data,          /* A */
        M->size,            /* LDA */
        jpvt->data,         /* JPVT */
        tau->data,          /* TAU */
        work->data,         /* WORK */
        lwork,              /* LWORK */
        rwork->data,        /* RWORK */
        info);              /* INFO */
    /* build R and Q from data */
    for (i = 0; i < mdim; i++) {
      /* copy data's upper trapezoid to R */
      matrixW_zcopy(M->level[0]->size - i,
          buf->data + 2 * i * (M->size + 1), M->size,
          R->data + 2 * i * (R->size + 1), R->size);
      /* fill R's lower trapezoid with zeros */
      matrixW_zdscal(M->size - i - 1, 0.0,
          R->data + 2 * (1 + i * (R->size + 1)), 1);
      /* copy data's lower trapezoid to Q */
      matrixW_zcopy(M->size - i - 1,
          buf->data + 2 * (1 + i * (M->size + 1)), 1,
          Q->data + 2 * (1 + i * (Q->size + 1)), 1);
    }
    /* build Q */
    matrixW_zungqr(M->size, /* M */
        M->size,            /* N */
        mdim,               /* K */
        Q->data,            /* A */
        M->size,            /* LDA */
        tau->data,          /* TAU */
        work->data,         /* WORK */
        lwork,              /* LWORK */
        info);              /* INFO */
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
  }
  /* build P */
  for (i = 0; i < P->size; i++)
    P->data[i * P->size + jpvt->data[i] - 1] = 1;
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, tau);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
  matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, jpvt);
}

/* compute linear least squares solution to A * X = B using complete
 * orthogonal factorization of A.
 * X is pushed in the stack, where X = arg{min||B-A*X||} and the rank of A and
 * info are returned as params.
 * note that the i-th column of X, X(i) corresponds to arg{min||B(i)-A*x||}.
 * rank is relative to tol. */
LUAMATRIX_API void matrix_ls (lua_State *L, lua_Matrix *A, lua_Matrix *B,
    lua_Number tol, int *rank, int *info) {
  lua_Matrix *X;
  int i, m, n, nrhs, mind, maxd, lwork;
  lm_numbuffer *buf, *ap, *work;
  lm_intbuffer *jpvt;
  lua_Matrix_complexity complex;
  matrixA_checkinner(L, A, B);
  if (tol <= 0) tol = LM_EPS;
  complex = A->complex | B->complex;
  m = A->size; /* == B->size */
  n = (A->dim == 1) ? 1 : A->level[0]->size;
  nrhs = (B->dim == 1) ? 1 : B->level[0]->size;
  mind = MIN(m, n);
  maxd = MAX(m, n);
  X = (B->dim == 1) ? matrix_pushvector(L, n, complex)
      : matrix_pusharray(L, n, nrhs, complex);
  /* copy A and B */
  if (complex == LM_REAL) {
    ap = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, m * n);
    matrixW_dcopy(m * n, A->data, 1, ap->data, 1);
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, maxd * nrhs);
    for (i = 0; i < nrhs; i++) /* copy m rows */
      matrixW_dcopy(m, B->data + i * m, 1, buf->data + i * maxd, 1);
  }
  else {
    ap = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * m * n);
    if (A->complex != complex) {
      matrixW_dcopy(m * n, A->data, 1, ap->data, 2);
      matrixW_dscal(m * n, 0.0, ap->data + 1, 2);
    }
    else
      matrixW_zcopy(m * n, A->data, 1, ap->data, 1);
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * maxd * nrhs);
    if (B->complex != complex) {
      for (i = 0; i < nrhs; i++) /* copy m rows */
        matrixW_dcopy(m, B->data + i * m, 1, buf->data + 2 * i * maxd, 2);
      matrixW_dscal(maxd * nrhs, 0.0, buf->data + 1, 2);
    }
    else {
      for (i = 0; i < nrhs; i++) /* copy m rows */
        matrixW_zcopy(m, B->data + 2 * i * m, 1, buf->data + 2 * i * maxd, 1);
    }
  }
  /* setup jpvt */
  jpvt = matrixB_getintbuffer(L, LUA_ENVIRONINDEX, n);
  for (i = 0; i < n; jpvt->data[i++] = 0);
  /* compute LSS by complete orthogonalization */
  if (complex == LM_REAL) {
    lua_Number qwork;
    /* query */
    matrixW_dgelsy(m, /* M */
        n,            /* N */
        nrhs,         /* NRHS */
        ap->data,     /* A */
        m,            /* LDA */
        buf->data,    /* B */
        maxd,         /* LDB */
        jpvt->data,   /* JPVT */
        tol,          /* RCOND */
        rank,         /* RANK */
        &qwork,       /* WORK */
        -1,           /* LWORK */
        info);        /* INFO */
    /* compute */
    lua_number2int(lwork, qwork);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
    matrixW_dgelsy(m, /* M */
        n,            /* N */
        nrhs,         /* NRHS */
        ap->data,     /* A */
        m,            /* LDA */
        buf->data,    /* B */
        maxd,         /* LDB */
        jpvt->data,   /* JPVT */
        tol,          /* RCOND */
        rank,         /* RANK */
        work->data,   /* WORK */
        lwork,        /* LWORK */
        info);        /* INFO */
    /* build X */
    for (i = 0; i < nrhs; i++)
      matrixW_dcopy(n, buf->data + i * maxd, 1, X->data + i * n, 1);
  }
  else {
    lua_Complex qwork;
    lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * n);
    /* query */
    matrixW_zgelsy(m, /* M */
        n,            /* N */
        nrhs,         /* NRHS */
        ap->data,     /* A */
        m,            /* LDA */
        buf->data,    /* B */
        maxd,         /* LDB */
        jpvt->data,   /* JPVT */
        tol,          /* RCOND */
        rank,         /* RANK */
        (lua_Number *) &qwork, /* WORK */
        -1,           /* LWORK */
        rwork->data,  /* RWORK */
        info);        /* INFO */
    /* compute */
    lua_number2int(lwork, qwork.r);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * lwork);
    matrixW_zgelsy(m, /* M */
        n,            /* N */
        nrhs,         /* NRHS */
        ap->data,     /* A */
        m,            /* LDA */
        buf->data,    /* B */
        maxd,         /* LDB */
        jpvt->data,   /* JPVT */
        tol,          /* RCOND */
        rank,         /* RANK */
        work->data,   /* WORK */
        lwork,        /* LWORK */
        rwork->data,  /* RWORK */
        info);        /* INFO */
    /* build X */
    for (i = 0; i < nrhs; i++)
      matrixW_zcopy(n, buf->data + 2 * i * maxd, 1, X->data + 2 * i * n, 1);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
  }
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, jpvt);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, ap);
}

/* compute linear least squares solution to A * X = B using singular value
 * decomposition of A.
 * X is pushed in the stack, where X = arg{min||B-A*X||} and the rank of A and
 * info are returned as params.
 * note that the i-th column of X, X(i) corresponds to arg{min||B(i)-A*x||}.
 * rank is relative to tol. */
LUAMATRIX_API void matrix_lss (lua_State *L, lua_Matrix *A, lua_Matrix *B,
    lua_Number tol, int *rank, int *info) {
  lua_Matrix *X;
  int i, m, n, nrhs, mind, maxd, lwork;
  lm_numbuffer *buf, *ap, *work, *s;
  lua_Matrix_complexity complex;
  matrixA_checkinner(L, A, B);
  if (tol <= 0) tol = LM_EPS;
  complex = A->complex | B->complex;
  m = A->size; /* == B->size */
  n = (A->dim == 1) ? 1 : A->level[0]->size;
  nrhs = (B->dim == 1) ? 1 : B->level[0]->size;
  mind = MIN(m, n);
  maxd = MAX(m, n);
  X = (B->dim == 1) ? matrix_pushvector(L, n, complex)
      : matrix_pusharray(L, n, nrhs, complex);
  /* copy A and B */
  if (complex == LM_REAL) {
    ap = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, m * n);
    matrixW_dcopy(m * n, A->data, 1, ap->data, 1);
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, maxd * nrhs);
    for (i = 0; i < nrhs; i++) /* copy m rows */
      matrixW_dcopy(m, B->data + i * m, 1, buf->data + i * maxd, 1);
  }
  else {
    ap = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * m * n);
    if (A->complex != complex) {
      matrixW_dcopy(m * n, A->data, 1, ap->data, 2);
      matrixW_dscal(m * n, 0.0, ap->data + 1, 2);
    }
    else
      matrixW_zcopy(m * n, A->data, 1, ap->data, 1);
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * maxd * nrhs);
    if (B->complex != complex) {
      for (i = 0; i < nrhs; i++) /* copy m rows */
        matrixW_dcopy(m, B->data + i * m, 1, buf->data + 2 * i * maxd, 2);
      matrixW_dscal(maxd * nrhs, 0.0, buf->data + 1, 2);
    }
    else {
      for (i = 0; i < nrhs; i++) /* copy m rows */
        matrixW_zcopy(m, B->data + 2 * i * m, 1, buf->data + 2 * i * maxd, 1);
    }
  }
  /* setup s */
  s = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, mind);
  /* compute LSS by SVD */
  if (complex == LM_REAL) {
    lua_Number qwork;
    /* query */
    matrixW_dgelss(m, /* M */
        n,            /* N */
        nrhs,         /* NRHS */
        ap->data,     /* A */
        m,            /* LDA */
        buf->data,    /* B */
        maxd,         /* LDB */
        s->data,      /* S */
        tol,          /* RCOND */
        rank,         /* RANK */
        &qwork,       /* WORK */
        -1,           /* LWORK */
        info);        /* INFO */
    /* compute */
    lua_number2int(lwork, qwork);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
    matrixW_dgelss(m, /* M */
        n,            /* N */
        nrhs,         /* NRHS */
        ap->data,     /* A */
        m,            /* LDA */
        buf->data,    /* B */
        maxd,         /* LDB */
        s->data,      /* S */
        tol,          /* RCOND */
        rank,         /* RANK */
        work->data,   /* WORK */
        lwork,        /* LWORK */
        info);        /* INFO */
    /* build X */
    for (i = 0; i < nrhs; i++)
      matrixW_dcopy(n, buf->data + i * maxd, 1, X->data + i * n, 1);
  }
  else {
    lua_Complex qwork;
    lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 5 * mind);
    /* query */
    matrixW_zgelss(m, /* M */
        n,            /* N */
        nrhs,         /* NRHS */
        ap->data,     /* A */
        m,            /* LDA */
        buf->data,    /* B */
        maxd,         /* LDB */
        s->data,      /* JPVT */
        tol,          /* RCOND */
        rank,         /* RANK */
        (lua_Number *) &qwork, /* WORK */
        -1,           /* LWORK */
        rwork->data,  /* RWORK */
        info);        /* INFO */
    /* compute */
    lua_number2int(lwork, qwork.r);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * lwork);
    matrixW_zgelss(m, /* M */
        n,            /* N */
        nrhs,         /* NRHS */
        ap->data,     /* A */
        m,            /* LDA */
        buf->data,    /* B */
        maxd,         /* LDB */
        s->data,      /* JPVT */
        tol,          /* RCOND */
        rank,         /* RANK */
        work->data,   /* WORK */
        lwork,        /* LWORK */
        rwork->data,  /* RWORK */
        info);        /* INFO */
    /* build X */
    for (i = 0; i < nrhs; i++)
      matrixW_zcopy(n, buf->data + 2 * i * maxd, 1, X->data + 2 * i * n, 1);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
  }
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, s);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, ap);
}

/* computes the eigenvalues of M */
/* TODO: no_balance option, using GEHRD, [ORGHR], HSEQR, [TREVC] */
LUAMATRIX_API void matrix_eigv (lua_State *L, lua_Matrix *M, int *info) {
  lua_Matrix *E;
  lm_numbuffer *work, *buf;
  int lwork;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension: %d", M->dim);
  if (M->size != M->level[0]->size)
    luaL_error(L, "matrix is not square");
  if (istype_symmetric(M)) {
    /* setup E */
    E = matrix_pushvector(L, M->size, LM_REAL);
    if (M->complex == LM_REAL) {
      lua_Number qwork;
      buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size * M->size);
      matrixW_dcopy(M->size * M->size, M->data, 1, buf->data, 1);
      /* query */
      matrixW_dsyev('N', /* JOBZ */
          'U',           /* UPLO */
          M->size,       /* N */
          buf->data,     /* A */
          M->size,       /* LDA */
          E->data,       /* W */
          &qwork,        /* WORK */
          -1,            /* LWORK */
          info);         /* INFO */
      lua_number2int(lwork, qwork);
      work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
      /* compute */
      matrixW_dsyev('N', /* JOBZ */
          'U',           /* UPLO */
          M->size,       /* N */
          buf->data,     /* A */
          M->size,       /* LDA */
          E->data,       /* W */
          work->data,    /* WORK */
          lwork,         /* LWORK */
          info);         /* INFO */
    }
    else {
      lua_Complex qwork;
      lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX,
          3 * M->size - 2);
      buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * M->size * M->size);
      matrixW_zcopy(M->size * M->size, M->data, 1, buf->data, 1);
      /* query */
      matrixW_zheev('N', /* JOBZ */
          'U',           /* UPLO */
          M->size,       /* N */
          buf->data,     /* A */
          M->size,       /* LDA */
          E->data,       /* W */
          (lua_Number *) &qwork, /* WORK */
          -1,            /* LWORK */
          rwork->data,   /* RWORK */
          info);         /* INFO */
      lua_number2int(lwork, qwork.r);
      work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
      /* compute */
      matrixW_zheev('N', /* JOBZ */
          'U',           /* UPLO */
          M->size,       /* N */
          buf->data,     /* A */
          M->size,       /* LDA */
          E->data,       /* W */
          work->data,    /* WORK */
          lwork,         /* LWORK */
          rwork->data,   /* RWORK */
          info);         /* INFO */
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
    }
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
    return;
  }
  /* =====  general case  ===== */
  if (M->complex == LM_REAL) {
    int i, eigreal = 1;
    lua_Number qwork;
    lm_numbuffer *wr = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size);
    lm_numbuffer *wi = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size);
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size * M->size);
    matrixW_dcopy(M->size * M->size, M->data, 1, buf->data, 1);
    /* query */
    matrixW_dgeev('N',   /* JOBVL */
        'N',             /* JOBVR */
        M->size,         /* N */
        buf->data,       /* A */
        M->size,         /* LDA */
        wr->data,        /* WR */
        wi->data,        /* WI */
        NULL,            /* VL */
        M->size,         /* LDVL */
        NULL,            /* VR */
        M->size,         /* LDVR */
        &qwork,          /* WORK */
        -1,              /* LWORK */
        info);           /* INFO */
    lua_number2int(lwork, qwork);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
    /* compute */
    matrixW_dgeev('N',   /* JOBVL */
        'N',             /* JOBVR */
        M->size,         /* N */
        buf->data,       /* A */
        M->size,         /* LDA */
        wr->data,        /* WR */
        wi->data,        /* WI */
        NULL,            /* VL */
        M->size,         /* LDVL */
        NULL,            /* VR */
        M->size,         /* LDVR */
        work->data,      /* WORK */
        lwork,           /* LWORK */
        info);           /* INFO */
    /* check if eigenvalues are all real */
    for (i = 0; eigreal && i < M->size; i++)
      if (EQZERO(wi->data[i])) eigreal = 0;
    /* setup E */
    if (eigreal) {
      E = matrix_pushvector(L, M->size, LM_REAL);
      matrixW_dcopy(M->size, wr->data, 1, E->data, 1);
    }
    else {
      E = matrix_pushvector(L, M->size, LM_COMPLEX);
      matrixW_dcopy(M->size, wr->data, 1, E->data, 2);
      matrixW_dcopy(M->size, wi->data, 1, E->data + 1, 2);
    }
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, wr);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, wi);
  }
  else {
    lua_Complex qwork;
    lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * M->size);
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * M->size * M->size);
    matrixW_zcopy(M->size * M->size, M->data, 1, buf->data, 1);
    E = matrix_pushvector(L, M->size, LM_COMPLEX);
    /* query */
    matrixW_zgeev('N',   /* JOBVL */
        'N',             /* JOBVR */
        M->size,         /* N */
        buf->data,       /* A */
        M->size,         /* LDA */
        E->data,         /* W */
        NULL,            /* VL */
        M->size,         /* LDVL */
        NULL,            /* VR */
        M->size,         /* LDVR */
        (lua_Number *) &qwork, /* WORK */
        -1,              /* LWORK */
        rwork->data,     /* RWORK */
        info);           /* INFO */
    lua_number2int(lwork, qwork.r);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * lwork);
    /* compute */
    matrixW_zgeev('N',   /* JOBVL */
        'N',             /* JOBVR */
        M->size,         /* N */
        buf->data,       /* A */
        M->size,         /* LDA */
        E->data,         /* W */
        NULL,            /* VL */
        M->size,         /* LDVL */
        NULL,            /* VR */
        M->size,         /* LDVR */
        work->data,      /* WORK */
        lwork,           /* LWORK */
        rwork->data,     /* RWORK */
        info);           /* INFO */
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
  }
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
}

/* computes the eigenvalues and right eigenvectors of M */
/* TODO: no_balance option, using GEHRD, [ORGHR], HSEQR, [TREVC] */
LUAMATRIX_API void matrix_eig (lua_State *L, lua_Matrix *M, int *info) {
  lua_Matrix *E, *V;
  lm_numbuffer *work, *buf;
  int lwork;
  if (M->dim != 2)
    luaL_error(L, "invalid dimension: %d", M->dim);
  if (M->size != M->level[0]->size)
    luaL_error(L, "matrix is not square");
  if (istype_symmetric(M)) {
    /* setup E and V */
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size);
    E = matrix_pusharray(L, M->size, M->size, LM_REAL);
    matrixW_dscal(M->size * M->size, 0.0, E->data, 1);
    V = matrix_copy(L, M);
    if (M->complex == LM_REAL) {
      lua_Number qwork;
      /* query */
      matrixW_dsyev('V', /* JOBZ */
          'U',           /* UPLO */
          M->size,       /* N */
          V->data,       /* A */
          M->size,       /* LDA */
          buf->data,     /* W */
          &qwork,        /* WORK */
          -1,            /* LWORK */
          info);         /* INFO */
      lua_number2int(lwork, qwork);
      work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
      /* compute */
      matrixW_dsyev('V', /* JOBZ */
          'U',           /* UPLO */
          M->size,       /* N */
          V->data,       /* A */
          V->size,       /* LDA */
          buf->data,     /* W */
          work->data,    /* WORK */
          lwork,         /* LWORK */
          info);         /* INFO */
      /* fill E */
      matrixW_dcopy(M->size, buf->data, 1, E->data, M->size + 1);
    }
    else {
      lua_Complex qwork;
      lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX,
          3 * M->size - 2);
      /* query */
      matrixW_zheev('V', /* JOBZ */
          'U',           /* UPLO */
          M->size,       /* N */
          V->data,       /* A */
          M->size,       /* LDA */
          buf->data,     /* W */
          (lua_Number *) &qwork, /* WORK */
          -1,            /* LWORK */
          rwork->data,   /* RWORK */
          info);         /* INFO */
      lua_number2int(lwork, qwork.r);
      work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
      /* compute */
      matrixW_zheev('V', /* JOBZ */
          'U',           /* UPLO */
          M->size,       /* N */
          V->data,       /* A */
          M->size,       /* LDA */
          buf->data,     /* W */
          work->data,    /* WORK */
          lwork,         /* LWORK */
          rwork->data,   /* RWORK */
          info);         /* INFO */
      /* fill E */
      matrixW_dcopy(M->size, buf->data, 1, E->data, M->size + 1);
      matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
    }
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
    return;
  }
  /* =====  general case  ===== */
  if (M->complex == LM_REAL) {
    int i, eigreal = 1;
    lua_Number qwork;
    lm_numbuffer *wr = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size);
    lm_numbuffer *wi = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size);
    lm_numbuffer *vr = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size * M->size);
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, M->size * M->size);
    matrixW_dcopy(M->size * M->size, M->data, 1, buf->data, 1);
    /* query */
    matrixW_dgeev('N',   /* JOBVL */
        'V',             /* JOBVR */
        M->size,         /* N */
        buf->data,       /* A */
        M->size,         /* LDA */
        wr->data,        /* WR */
        wi->data,        /* WI */
        NULL,            /* VL */
        M->size,         /* LDVL */
        vr->data,        /* VR */
        M->size,         /* LDVR */
        &qwork,          /* WORK */
        -1,              /* LWORK */
        info);           /* INFO */
    lua_number2int(lwork, qwork);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, lwork);
    /* compute */
    matrixW_dgeev('N',   /* JOBVL */
        'V',             /* JOBVR */
        M->size,         /* N */
        buf->data,       /* A */
        M->size,         /* LDA */
        wr->data,        /* WR */
        wi->data,        /* WI */
        NULL,            /* VL */
        M->size,         /* LDVL */
        vr->data,        /* VR */
        M->size,         /* LDVR */
        work->data,      /* WORK */
        lwork,           /* LWORK */
        info);           /* INFO */
    /* check if eigenvalues are all real */
    for (i = 0; eigreal && i < M->size; i++)
      if (EQZERO(wi->data[i])) eigreal = 0;
    /* setup E and V */
    if (eigreal) {
      E = matrix_pusharray(L, M->size, M->size, LM_REAL);
      matrixW_dcopy(M->size, wr->data, 1, E->data, M->size + 1);
      V = matrix_pusharray(L, M->size, M->size, LM_REAL);
      matrixW_dcopy(M->size * M->size, vr->data, 1, V->data, 1);
    }
    else {
      E = matrix_pusharray(L, M->size, M->size, LM_COMPLEX);
      matrixW_dcopy(M->size, wr->data, 1, E->data, 2 * (M->size + 1));
      matrixW_dcopy(M->size, wi->data, 1, E->data + 1, 2 * (M->size + 1));
      V = matrix_pusharray(L, M->size, M->size, LM_COMPLEX);
      matrixW_dscal(M->size * M->size, 0.0, V->data + 1, 2);
      matrixW_dcopy(M->size * M->size, vr->data, 1, V->data, 2);
      for (i = 0; i < M->size; i++) { /* fix conjugacy */
        if (!EQZERO(wi->data[i])) {
          matrixW_dcopy(M->size, V->data + 2 * (i + 1) * M->size, 2,
              V->data + 2 * i * M->size + 1, 2);
          matrixW_dcopy(M->size, V->data + 2 * (i + 1) * M->size, 2,
              V->data + 2 * (i + 1) * M->size + 1, 2);
          matrixW_dcopy(M->size, V->data + 2 * i * M->size, 2,
              V->data + 2 * (i + 1) * M->size, 2);
          matrixW_dscal(M->size, -1.0,
              V->data + 2 * (i + 1) * M->size + 1, 2);
          i++;
        }
      }
    }
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, wr);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, wi);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, vr);
  }
  else {
    lua_Complex qwork;
    lm_numbuffer *eb = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * M->size);
    lm_numbuffer *rwork = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * M->size);
    E = matrix_pusharray(L, M->size, M->size, LM_COMPLEX);
    matrixW_dscal(2 * M->size * M->size, 0.0, E->data, 1);
    V = matrix_copy(L, M);
    buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * M->size * M->size);
    matrixW_zcopy(M->size * M->size, M->data, 1, buf->data, 1);
    /* query */
    matrixW_zgeev('N',   /* JOBVL */
        'V',             /* JOBVR */
        M->size,         /* N */
        buf->data,       /* A */
        M->size,         /* LDA */
        eb->data,        /* W */
        NULL,            /* VL */
        M->size,         /* LDVL */
        V->data,         /* VR */
        M->size,         /* LDVR */
        (lua_Number *) &qwork, /* WORK */
        -1,              /* LWORK */
        rwork->data,     /* RWORK */
        info);           /* INFO */
    lua_number2int(lwork, qwork.r);
    work = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * lwork);
    /* compute */
    matrixW_zgeev('N',   /* JOBVL */
        'V',             /* JOBVR */
        M->size,         /* N */
        buf->data,       /* A */
        M->size,         /* LDA */
        eb->data,        /* W */
        NULL,            /* VL */
        M->size,         /* LDVL */
        V->data,         /* VR */
        M->size,         /* LDVR */
        work->data,      /* WORK */
        lwork,           /* LWORK */
        rwork->data,     /* RWORK */
        info);           /* INFO */
    /* fill E */
    matrixW_zcopy(M->size, eb->data, 1, E->data, M->size + 1);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, eb);
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, rwork);
  }
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, work);
  matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
}


/* {=================================================================
 *    Methods
 * ==================================================================} */

static int norm_matrix (lua_State *L) {
  lua_Matrix *M = matrix_checktype(L, 1);
  char norm;
  if (lua_isnoneornil(L, 2))
    norm = 'F'; /* Frobenius norm == 2-norm */
  else {
    const char *input = lua_tostring(L, 2);
    norm = toupper(input[0]);
    if (norm == '2') norm = 'F';
  }
  lua_pushnumber(L, matrix_norm(L, M, norm));
  return 1;
}

static int rcond_matrix (lua_State *L) {
  int info;
  lua_pushnumber(L, matrix_rcond(L, matrix_checktype(L, 1), &info));
  lua_pushinteger(L, info);
  return 2;
}

/* if matrix is singular, return nil */
static int inv_matrix (lua_State *L) {
  int info;
  lua_pushnumber(L, matrix_inv(L, matrix_checktype(L, 1),
        luaL_optnumber(L, 2, 0), &info));
  lua_pushinteger(L, info);
  return 3; /* inv or nil (if near singular), rcond, info */
}

static int lu_matrix (lua_State *L) {
  int info;
  matrix_lu(L, matrix_checktype(L, 1), &info);
  lua_pushinteger(L, info);
  return 4; /* L, U, P, info */
}

static int det_matrix (lua_State *L) {
  lua_Matrix *M = matrix_checktype(L, 1);
  int i, n = M->size * M->size;
  int info = 0;
  lua_Number sign = 1;
  lua_Number *data;
  lm_numbuffer *buf = NULL;
  lm_intbuffer *ipiv = NULL;
  if (M->dim != 2)
    luaL_error(L, "invalid number of dimensions: %d", M->dim);
  if (M->size != M->level[0]->size)
    luaL_error(L, "cannot compute determinant: matrix is not square");
  if (istype_triangular(M)) data = M->data;
  else {
    ipiv = matrixB_getintbuffer(L, LUA_ENVIRONINDEX, M->size);
    if (M->complex == LM_REAL) {
      /* copy M */
      buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, n);
      matrixW_dcopy(n, M->data, 1, buf->data, 1);
      /* decompose */
      matrixW_dgetrf(M->size, /* M */
          M->level[0]->size,  /* N */
          buf->data,          /* A */
          M->size,            /* LDA */
          ipiv->data,         /* IPIV */
          &info);             /* INFO */
    }
    else {
      /* copy M */
      buf = matrixB_getnumbuffer(L, LUA_ENVIRONINDEX, 2 * n);
      matrixW_zcopy(n, M->data, 1, buf->data, 1);
      /* decompose */
      matrixW_zgetrf(M->size, /* M */
          M->level[0]->size,  /* N */
          buf->data,          /* A */
          M->size,            /* LDA */
          ipiv->data,         /* IPIV */
          &info);             /* INFO */
    }
    /* compute sign */
    if (info == 0) { /* non-singular? */
      for (i = 0; i < M->size; i++)
        if (i != ipiv->data[i] - 1) sign *= -1; /* flip sign */
    }
    data = buf->data;
  }
  /* diagonal product */
  if (M->complex == LM_REAL) {
    lua_Number det;
    if (info > 0) det = 0.0;
    else {
      det = sign;
      for (i = 0; i < n; i += M->size + 1) det *= data[i];
    }
    lua_pushnumber(L, det);
  }
  else {
    lua_Complex *det;
    if (info > 0) det = complex_pushzero(L);
    else {
      det = complex_push(L, sign, 0);
      for (i = 0; i < 2 * n; i += 2 * (M->size + 1))
        complex_mul(det, det, (lua_Complex *) (data + i));
    }
  }
  if (!istype_triangular(M)) {
    matrixB_freenumbuffer(L, LUA_ENVIRONINDEX, buf);
    matrixB_freeintbuffer(L, LUA_ENVIRONINDEX, ipiv);
  }
  return 1;
}

static int balance_matrix (lua_State *L) {
  int info;
  matrix_balance(L, matrix_checktype(L, 1), &info);
  lua_pushinteger(L, info);
  return 3; /* B, T, and info */
}

static int chol_matrix (lua_State *L) {
  int info;
  matrix_chol(L, matrix_checktype(L, 1), &info);
  lua_pushinteger(L, info);
  return 2;
}

static int svd_matrix (lua_State *L) {
  lua_Matrix *M = matrix_checktype(L, 1);
  int values_only = lua_toboolean(L, 2);
  int info;
  if (values_only) matrix_svdv(L, M, &info);
  else matrix_svd(L, M, &info);
  if (info)
    printf("WARNING: singular value decomposition did NOT converged\n");
  lua_pushinteger(L, info);
  return values_only ? 2 : 4;
}

/* condition number for 2-norm of a matrix */
static int cond_matrix (lua_State *L) {
  lua_Matrix *s;
  lua_Number cond;
  int info;
  matrix_svdv(L, matrix_checktype(L, 1), &info);
  s = (lua_Matrix *) lua_touserdata(L, -1);
  cond = s->data[0] / s->data[s->size - 1];
  if (info > 0)
    printf("WARNING: singular value decomposition did NOT converged\n");
  lua_pop(L, 1); /* s */
  lua_pushnumber(L, cond);
  lua_pushinteger(L, info);
  return 2;
}

static int rank_matrix (lua_State *L) {
  lua_Matrix *s, *M = matrix_checktype(L, 1);
  lua_Number tol = luaL_optnumber(L, 2, 0);
  int i, info, rank = 0;
  matrix_svdv(L, M, &info);
  if (info > 0)
    printf("WARNING: singular value decomposition did NOT converged\n");
  s = (lua_Matrix *) lua_touserdata(L, -1);
  if (tol <= 0) tol = MAX(M->size, M->level[0]->size) * LM_EPS * s->data[0];
  for (i = 0; i < s->size; i++)
    if (s->data[i] > tol) rank++; else break;
  lua_pop(L, 1); /* s */
  lua_pushinteger(L, rank);
  lua_pushinteger(L, info);
  return 2;
}

static int qr_matrix (lua_State *L) {
  lua_Matrix *M = matrix_checktype(L, 1);
  int perm, info;
  perm = lua_toboolean(L, 2);
  if (perm) /* QR with column pivoting? */
    matrix_qrp(L, M, &info);
  else matrix_qr(L, M, &info);
  lua_pushinteger(L, info);
  return perm ? 4 : 3;
}

static int ls_matrix (lua_State *L) {
  int rank, info;
  matrix_ls(L, matrix_checktype(L, 1), matrix_checktype(L, 2),
      luaL_optnumber(L, 3, 0), &rank, &info);
  lua_pushinteger(L, rank);
  lua_pushinteger(L, info);
  return 3;
}

static int lss_matrix (lua_State *L) {
  int rank, info;
  matrix_lss(L, matrix_checktype(L, 1), matrix_checktype(L, 2),
      luaL_optnumber(L, 3, 0), &rank, &info);
  lua_pushinteger(L, rank);
  lua_pushinteger(L, info);
  return 3;
}

static int eig_matrix (lua_State *L) {
  lua_Matrix *M = matrix_checktype(L, 1);
  int info, values_only = lua_toboolean(L, 2);
  if (values_only) matrix_eigv(L, M, &info);
  else matrix_eig(L, M, &info);
  lua_pushinteger(L, info);
  return values_only ? 2 : 3;
}

/* {=================================================================
 *    Interface
 * ==================================================================} */

static const luaL_reg linalg_func[] = {
  {"norm", norm_matrix},
  {"rcond", rcond_matrix},
  {"inv", inv_matrix},
  {"lu", lu_matrix},
  {"det", det_matrix},
  {"balance", balance_matrix},
  {"chol", chol_matrix},
  {"svd", svd_matrix},
  {"cond", cond_matrix},
  {"rank", rank_matrix},
  {"qr", qr_matrix},
  {"ls", ls_matrix},
  {"lss", lss_matrix},
  {"eig", eig_matrix},
  {NULL, NULL}
};

int linalg_open (lua_State *L)
{
  /* set buffer as current environment */
  lua_getfield(L, LUA_REGISTRYINDEX, LUAMATRIX_BUFFER);
  lua_replace(L, LUA_ENVIRONINDEX);
  /* register functions */
  luaL_register(L, NULL, linalg_func);
  return 0;
}

