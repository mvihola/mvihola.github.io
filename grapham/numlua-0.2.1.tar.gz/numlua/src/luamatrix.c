/* {=================================================================
 * 
 * luamatrix.c
 * Basic matrix library for lua
 * Luis Carvalho (carvalho @ dam.brown.edu)
 * See Copyright Notice in luamatrix.h
 * $Id: luamatrix.c,v 1.2 2006/02/12 20:53:14 carvalho Exp $
 *  
 * ==================================================================} */

#include <lauxlib.h>

#include "luamatrix.h"
#include "luacomplex.h"

/* Modules entry point */
int base_open (lua_State *L);
int stat_open (lua_State *L);
int linalg_open (lua_State *L);

static const luaL_reg matrix_mod[] = {
  {"stat", stat_open},
  {"linalg", linalg_open},
  {NULL, NULL}
};

LUAMATRIX_API int luaopen_luamatrix (lua_State *L) {
  int i;
  /* matrix module */
  base_open(L);
  /* push submodules */
  for (i = 0; matrix_mod[i].name; i++)
    matrix_mod[i].func(L);
  return 1;
}

