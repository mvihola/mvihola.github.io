#ifndef blaswrap_h
#define blaswrap_h

/* ============================= Level 1 ============================= */

doublereal ddot_(integer* N, doublereal* X, integer* incX, doublereal* Y,
    integer* incY);

void zdotu_(doublecomplex* retval, integer* N, doublecomplex* X, integer*
    incX, doublecomplex* Y, integer* incY);

void zdotc_(doublecomplex* retval, integer* N, doublecomplex* X, integer*
    incX, doublecomplex* Y, integer* incY);

doublereal dnrm2_(integer* N, doublereal* X, integer* incX);

doublereal dasum_(integer* N, doublereal* X, integer* incX);

doublereal dznrm2_(integer* N, doublecomplex* X, integer* incX);

doublereal dzasum_(integer* N, doublecomplex* X, integer* incX);

integer idamax_(integer* N, doublereal* X, integer* incX);

integer izamax_(integer* N, doublecomplex* X, integer* incX);

int dswap_(integer* N, doublereal* X, integer* incX, doublereal* Y, integer*
    incY);

int dcopy_(integer* N, doublereal* X, integer* incX, doublereal* Y, integer*
    incY);

int daxpy_(integer* N, doublereal* alpha, doublereal* X, integer* incX,
    doublereal* Y, integer* incY);

int zswap_(integer* N, doublecomplex* X, integer* incX, doublecomplex* Y,
    integer* incY);

int zcopy_(integer* N, doublecomplex* X, integer* incX, doublecomplex* Y,
    integer* incY);

int zaxpy_(integer* N, doublecomplex* alpha, doublecomplex* X, integer* incX,
    doublecomplex* Y, integer* incY);

int drotg_(doublereal* a, doublereal* b, doublereal* c, doublereal* s);

int drot_(integer* N, doublereal* X, integer* incX, doublereal* Y, integer*
    incY, doublereal* c, doublereal* s);

int dscal_(integer* N, doublereal* alpha, doublereal* X, integer* incX);

int zscal_(integer* N, doublecomplex* alpha, doublecomplex* X, integer* incX);

int zdscal_(integer* N, doublereal* alpha, doublecomplex* X, integer* incX);

/* ============================= Level 2 ============================= */

int dgemv_(char* trans, integer* M, integer* N, doublereal* alpha, doublereal*
    A, integer* lda, doublereal* X, integer* incX, doublereal* beta,
    doublereal* Y, integer* incY, integer ltrans);

int dtrmv_(char* uplo, char *trans, char* diag, integer *N,  doublereal *A,
    integer *lda, doublereal *X, integer *incX, integer luplo, integer ltrans,
    integer ldiag);

int dtrsv_(char* uplo, char* trans, char* diag, integer* N, doublereal* A,
    integer* lda, doublereal* X, integer* incX, integer luplo, integer ltrans,
    integer ldiag);

int zgemv_(char* trans, integer* M, integer* N, doublecomplex* alpha,
    doublecomplex* A, integer* lda, doublecomplex* X, integer* incX,
    doublecomplex* beta, doublecomplex* Y, integer* incY, integer ltrans);

int ztrmv_(char* uplo, char *trans, char* diag, integer *N,  doublecomplex *A,
    integer *lda, doublecomplex *X, integer *incX, integer luplo, integer ltrans,
    integer ldiag);

int ztrsv_(char* uplo, char* trans, char* diag, integer* N, doublecomplex* A,
    integer* lda, doublecomplex* X, integer* incX, integer luplo, integer ltrans,
    integer ldiag);

int dsymv_(char* uplo, integer* N, doublereal* alpha, doublereal* A, integer*
    lda, doublereal* X, integer* incX, doublereal* beta, doublereal* Y,
    integer* incY, integer luplo);

int dger_(integer* M, integer* N, doublereal* alpha, doublereal* X, integer*
    incX, doublereal* Y, integer* incY, doublereal* A, integer* lda);

int dsyr_(char* uplo, integer* N, doublereal* alpha, doublereal* X, integer*
    incX, doublereal* A, integer* lda, integer luplo);

int dsyr2_(char* uplo, integer* N, doublereal* alpha, doublereal* X, integer*
    incX, doublereal* Y, integer* incY, doublereal* A, integer* lda,
    integer luplo);

int zhemv_(char* uplo, integer* N, doublecomplex* alpha, doublecomplex* A,
    integer* lda, doublecomplex* X, integer* incX, doublecomplex* beta,
    doublecomplex* Y, integer* incY, integer luplo);

int zgeru_(integer* M, integer* N, doublecomplex* alpha, doublecomplex* X,
    integer* incX, doublecomplex* Y, integer* incY, doublecomplex* A,
    integer* lda);

int zgerc_(integer* M, integer* N, doublecomplex* alpha, doublecomplex* X,
    integer* incX, doublecomplex* Y, integer* incY, doublecomplex* A,
    integer* lda);

int zher_(char* uplo, integer* N, doublereal* alpha, doublecomplex* X,
    integer* incX, doublecomplex* A, integer* lda, integer luplo);

int zher2_(char* uplo, integer* N, doublecomplex* alpha, doublecomplex* X,
    integer* incX, doublecomplex* Y, integer* incY, doublecomplex* A,
    integer* lda, integer luplo);

/* ============================= Level 3 ============================= */

int dgemm_(char* transA, char* transB, integer* M, integer* N, integer* K,
    doublereal* alpha, doublereal* A, integer* lda, doublereal* B,
    integer* ldb, doublereal* beta, doublereal* C, integer* ldc,
    integer ltransa, integer ltransb);

int dsymm_(char* side, char* uplo, integer* M, integer* N, doublereal* alpha,
    doublereal* A, integer* lda, doublereal* B, integer* ldb, doublereal*
    beta, doublereal* C, integer* ldc, integer lside, integer luplo);

int dsyrk_(char* uplo, char* trans, integer* N, integer* K, doublereal* alpha,
    doublereal* A, integer* lda, doublereal* beta, doublereal* C, integer*
    ldc, integer luplo, integer ltrans);

int dsyr2k_(char* uplo, char* trans, integer* N, integer* K, doublereal*
    alpha, doublereal* A, integer* lda, doublereal* B, integer* ldb,
    doublereal* beta, doublereal* C, integer* ldc, integer luplo,
    integer ltrans);

int dtrmm_(char* side, char* uplo, char* trans, char* diag, integer* M,
    integer* N, doublereal* alpha, doublereal* A, integer* lda,
    doublereal* B, integer* ldb, integer lside, integer luplo,
    integer ltrans, integer ldiag);

int dtrsm_(char* side, char* uplo, char* trans, char* diag, integer* M,
    integer* N, doublereal* alpha, doublereal* A, integer* lda,
    doublereal* B, integer* ldb, integer lside, integer luplo,
    integer ltrans, integer ldiag);

int zgemm_(char* transA, char* transB, integer* M, integer* N, integer* K,
    doublecomplex* alpha, doublecomplex* A, integer* lda, doublecomplex*
    B, integer* ldb, doublecomplex* beta, doublecomplex* C, integer* ldc,
    integer ltransa, integer ltransb);

int zsyrk_(char* uplo, char* trans, integer* N, integer* K, doublecomplex*
    alpha, doublecomplex* A, integer* lda, doublecomplex* beta,
    doublecomplex* C, integer* ldc, integer luplo, integer ltrans);

int zsyr2k_(char* uplo, char* trans, integer* N, integer* K, doublecomplex*
    alpha, doublecomplex* A, integer* lda, doublecomplex* B, integer* ldb,
    doublecomplex* beta, doublecomplex* C, integer* ldc, integer luplo,
    integer ltrans);

int ztrmm_(char* side, char* uplo, char* trans, char* diag, integer* M,
    integer* N, doublecomplex* alpha, doublecomplex* A, integer* lda,
    doublecomplex* B, integer* ldb, integer lside, integer luplo,
    integer ltrans, integer ldiag);

int ztrsm_(char* side, char* uplo, char* trans, char* diag, integer* M,
    integer* N, doublecomplex* alpha, doublecomplex* A, integer* lda,
    doublecomplex* B, integer* ldb, integer lside, integer luplo,
    integer ltrans, integer ldiag);

int zhemm_(char* side, char* uplo, integer* M, integer* N, doublecomplex*
    alpha, doublecomplex* A, integer* lda, doublecomplex* B, integer* ldb,
    doublecomplex* beta, doublecomplex* C, integer* ldc, integer lside,
    integer luplo);

int zherk_(char* uplo, char* trans, integer* N, integer* K, doublereal* alpha,
    doublecomplex* A, integer* lda, doublereal* beta, doublecomplex* C,
    integer* ldc, integer luplo, integer ltrans);

int zher2k_(char* uplo, char* trans, integer* N, integer* K, doublecomplex*
    alpha, doublecomplex* A, integer* lda, doublecomplex* B, integer* ldb,
    doublereal* beta, doublecomplex* C, integer* ldc, integer luplo,
    integer ltrans);

#endif
