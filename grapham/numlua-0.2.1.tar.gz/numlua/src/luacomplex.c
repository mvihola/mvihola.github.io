/* {=================================================================
 * 
 * luacomplex.c
 * Complex number library for Lua
 * Luis Carvalho (carvalho @ dam.brown.edu)
 * See Copyright Notice in luacomplex.h
 * $Id: luacomplex.c,v 1.5 2006-09-11 02:25:38 carvalho Exp $
 *  
 * ==================================================================} */

#include <string.h>
#include <math.h>
#include <float.h>

#include <lauxlib.h>

#include "luacomplex.h"
#include "fnlib.h"

#define EQ(a, b) ((a) - (b) < DBL_EPSILON && (a) - (b) > -DBL_EPSILON)
#define EQZERO(a) ((a) < DBL_MIN && (a) > -DBL_MIN)

/* {=================================================================
 *    C Methods (Complex API)
 * ==================================================================} */

LUACOMPLEX_API lua_Complex *complex_to (lua_State *L, int pos) {
  lua_Complex *c = NULL;
  if (lua_isnoneornil(L, pos)) return NULL;
  if (pos <= 0 && pos > LUA_REGISTRYINDEX) pos = lua_gettop(L) + pos + 1;
  if (!lua_getmetatable(L, pos)) return NULL;
  /* check current environment first */
  if (lua_rawequal(L, -1, LUA_ENVIRONINDEX))
    c = (lua_Complex *) lua_touserdata(L, pos);
  else {
    lua_getfield(L, LUA_REGISTRYINDEX, LUACOMPLEX_MT);
    if (lua_rawequal(L, -1, -2))
      c = (lua_Complex *) lua_touserdata(L, pos);
    lua_pop(L, 1); /* LUACOMPLEX_MT */
  }
  lua_pop(L, 1); /* mt */
  return c;
}

/* pushes a complex number c such that R(c) = real and I(c) = imag */
LUACOMPLEX_API lua_Complex *complex_push (lua_State *L, lua_Number real,
    lua_Number imag) {
  lua_Complex *c = (lua_Complex *) lua_newuserdata(L, sizeof(lua_Complex));
  c->r = real;
  c->i = imag;
  /* set metatable */
  lua_getfield(L, LUA_REGISTRYINDEX, LUACOMPLEX_MT);
  lua_setmetatable(L, -2);
  return c;
}

/* if _pos_ holds a complex, copy value on top of stack; if it holds a
 * number, pushes a new complex; otherwise, throw error */
LUACOMPLEX_API lua_Complex *complex_pushvalue (lua_State *L, int pos) {
  lua_Complex *c = complex_to(L, pos);
  if (c != NULL) /* complex? */
    lua_pushvalue(L, pos);
  else if (lua_isnumber(L, pos))
    c = complex_push(L, lua_tonumber(L, pos), 0);
  else
    luaL_argerror(L, pos, "number or complex expected");
  return c;
}

/* {====================     Operations     ========================} */

LUACOMPLEX_API void complex_add (lua_Complex *c, lua_Complex *a,
    lua_Complex *b) {
  c->r = a->r + b->r;
  c->i = a->i + b->i;
}

LUACOMPLEX_API void complex_sub (lua_Complex *c, lua_Complex *a,
    lua_Complex *b) {
  c->r = a->r - b->r;
  c->i = a->i - b->i;
}

LUACOMPLEX_API void complex_mul (lua_Complex *c, lua_Complex *a,
    lua_Complex *b) {
  lua_Number t = a->r*b->r - a->i*b->i;
  c->i = a->r*b->i + a->i*b->r;
  c->r = t;
}

LUACOMPLEX_API void complex_div (lua_Complex *c, lua_Complex *a,
    lua_Complex *b) {
  /* adapted from libF77 */
  lua_Number ratio, den, abr, abi, cr;
  if ((abr=b->r)<0.0) abr = -abr;
  if ((abi=b->i)<0.0) abi = -abi;
  if (abr<=abi) {
    if (abi==0) {
      if (a->i!=0 || a->r!=0) abi = 1.0;
      c->i = c->r = abi/abr;
      return;
    }
    ratio = b->r/b->i;
    den = b->i*(1+ratio*ratio);
    cr = (a->r*ratio+a->i)/den;
    c->i = (a->i*ratio-a->r)/den;
  }
  else {
    ratio = b->i/b->r;
    den = b->r*(1+ratio*ratio);
    cr = (a->r+a->i*ratio)/den;
    c->i = (a->i-a->r*ratio)/den;
  }
  c->r = cr;
}

LUACOMPLEX_API int complex_eq (lua_Complex *a, lua_Complex *b) {
  return (EQ(a->r, b->r) && EQ(a->i, b->i));
}

LUACOMPLEX_API int complex_lt (lua_Complex *a, lua_Complex *b) {
  lua_Number abs_a = complex_abs(a);
  lua_Number abs_b = complex_abs(b);
  lua_Number arg_a = complex_arg(a);
  lua_Number arg_b = complex_arg(b);
  return (abs_a < abs_b || (EQ(abs_a, abs_b) && arg_a < arg_b));
}

LUACOMPLEX_API int complex_le (lua_Complex *a, lua_Complex *b) {
  lua_Number abs_a = complex_abs(a);
  lua_Number abs_b = complex_abs(b);
  lua_Number arg_a = complex_arg(a);
  lua_Number arg_b = complex_arg(b);
  return (abs_a < abs_b || (EQ(abs_a, abs_b) && arg_a <= arg_b));
}

/* {====================      Functions     ========================} */

LUACOMPLEX_API lua_Number complex_abs (lua_Complex *c) {
  /* adapted from libF77 */
  lua_Number r = (c->r<0.0) ? -c->r : c->r;
  lua_Number i = (c->i<0.0) ? -c->i : c->i;
  lua_Number t;
  if (i>r) { t = r; r = i; i = t; }
  if ((r+i)==r) return r;
  t = i/r;
  t = r*sqrt(1.0+t*t);
  return t;
}

LUACOMPLEX_API lua_Number complex_arg (lua_Complex *c) {
  return atan2(c->i, c->r);
}

LUACOMPLEX_API void complex_exp (lua_Complex *f, lua_Complex *c) {
  lua_Number t = exp(c->r);
  f->r = t*cos(c->i);
  f->i = t*sin(c->i);
}

LUACOMPLEX_API void complex_log (lua_Complex *f, lua_Complex *c) {
  lua_Number t = (lua_Number) log(complex_abs(c));
/*  f->i = complex_arg(c);*/
  f->i = atan2(c->i, c->r);
  f->r = t;
}

LUACOMPLEX_API void complex_sin (lua_Complex *f, lua_Complex *c) {
  f->r = sin(c->r)*cosh(c->i);
  f->i = cos(c->r)*sinh(c->i);
}

LUACOMPLEX_API void complex_cos (lua_Complex *f, lua_Complex *c) {
  f->r = cos(c->r)*cosh(c->i);
  f->i = -sin(c->r)*sinh(c->i);
}

LUACOMPLEX_API void complex_sqrt (lua_Complex *f, lua_Complex *c) {
  /* adapted from libF77 */
  lua_Number mag;
  if ((mag=complex_abs(c))==0.0) f->r = f->i = 0.0;
  else if (c->r>0.0) {
    f->r = sqrt(0.5*(mag+c->r));
    f->i = c->i/f->r/2.0;
  }
  else {
    f->i = sqrt(0.5*(mag-c->r));
    if (c->i<0.0) f->i = -f->i;
    f->r = c->i/f->i/2.0;
  }
}

LUACOMPLEX_API void complex_ipow (lua_Complex *f, lua_Complex *c,
    lua_Integer e) {
  /* adapted from libF77 */
  unsigned long u;
  lua_Number t;
  lua_Complex q, x;
  q.r = 1;
  q.i = 0;
  if (e==0) {
    f->i = q.i;
    f->r = q.r;
    return;
  }
  if (e<0) {
    lua_Complex one = {1.0, 0.0};
    e = -e;
    complex_div(&x, &one, c);
  }
  else {
    x.r = c->r;
    x.i = c->i;
  }
  for (u=e;;) {
    if (u & 01) {
      t = q.r*x.r-q.i*x.i;
      q.i = q.r*x.i+q.i*x.r;
      q.r = t;
    }
    if (u >>= 1) {
      t = x.r*x.r-x.i*x.i;
      x.i = 2*x.r*x.i;
      x.r = t;
    }
    else break;
  }
  f->i = q.i;
  f->r = q.r;
}

LUACOMPLEX_API void complex_pow (lua_Complex *f, lua_Complex *a,
    lua_Complex *b) {
  /* adapted from libF77 */
  lua_Number logr = log(complex_abs(a));
  lua_Number logi = complex_arg(a);
  lua_Number x = exp(logr*b->r-logi*b->i);
  lua_Number y = logr*b->i+logi*b->r;
  f->r = x*cos(y);
  f->i = x*sin(y);
}

/* {=================================================================
 *    Lua class (Complex) metamethods
 * ==================================================================} */

static int complex__index (lua_State *L) {
  /* stack contains complex and index */
  lua_Complex *c = (lua_Complex *) lua_touserdata(L, 1);
  const char *index = luaL_checkstring(L, 2);
  if (!strcmp(index, LUACOMPLEX_REAL_LABEL)) /* real */
    lua_pushnumber(L, c->r);
  else if (!strcmp(index, LUACOMPLEX_IMAG_LABEL)) /* imag */
    lua_pushnumber(L, c->i);
  else
    lua_getfield(L, LUA_ENVIRONINDEX, index); /* class[index] */
  return 1;
}

static int complex__newindex (lua_State *L) {
  /* stack contains complex, index and value */
  lua_Complex *c = (lua_Complex *) lua_touserdata(L, 1);
  const char *index = luaL_checkstring(L, 2);
  lua_Number value = luaL_checknumber(L, 3);
  if (!strcmp(index, LUACOMPLEX_REAL_LABEL)) /* real */
    c->r = value;
  else if (!strcmp(index, LUACOMPLEX_IMAG_LABEL)) /* imag */
    c->i = value;
  else
    luaL_error(L, "invalid index: %s", index);
  return 0;
}

static int complex__tostring (lua_State *L) {
  lua_Complex *c = (lua_Complex *) lua_touserdata(L, 1);
  if (c->i < 0)
    lua_pushfstring(L, "%f - %fi", c->r, -c->i);
  else if (c->i > 0)
    lua_pushfstring(L, "%f + %fi", c->r, c->i);
  else /* c->i == 0 */
    lua_pushfstring(L, "%f + 0i", c->r);
  return 1;
}

/* {====================     Operations     ========================} */

static int complex__add (lua_State *L) {
  /* complex and number/complex on stack, in no specific order */
  lua_Complex *a = complex_pushvalue(L, 1);
  lua_Complex *b = complex_pushvalue(L, 2);
  complex_add(complex_pushzero(L), a, b);
  return 1;
}

static int complex__sub (lua_State *L) {
  /* complex and number/complex on stack, in no specific order */
  lua_Complex *a = complex_pushvalue(L, 1);
  lua_Complex *b = complex_pushvalue(L, 2);
  complex_sub(complex_pushzero(L), a, b);
  return 1;
}

static int complex__unm (lua_State *L) {
  lua_Complex *c = (lua_Complex *) lua_touserdata(L, 1);
  complex_push(L, -c->r, -c->i);
  return 1;
}

static int complex__mul (lua_State *L) {
  /* complex and number/complex on stack, in no specific order */
  lua_Complex *a = complex_pushvalue(L, 1);
  lua_Complex *b = complex_pushvalue(L, 2);
  complex_mul(complex_pushzero(L), a, b);
  return 1;
}

static int complex__div (lua_State *L) {
  /* complex and number/complex on stack, in no specific order */
  lua_Complex *a = complex_pushvalue(L, 1);
  lua_Complex *b = complex_pushvalue(L, 2);
  complex_div(complex_pushzero(L), a, b);
  return 1;
}

static int complex__pow (lua_State *L) {
  lua_Complex *a = complex_pushvalue(L, 1);
  lua_Complex *b = complex_pushvalue(L, 2);
  lua_Complex *t = complex_pushzero(L);
  if (b->i==0.0 && b->r==floor(b->r)) { /* integer pow? */
    lua_Integer p;
    lua_Number x = b->r;
    lua_number2int(p, x);
    complex_ipow(t, a, p);
  }
  else complex_pow(t, a, b);
  return 1;
}

static int complex__eq (lua_State *L) {
  /* complex and number/complex on stack, in no specific order */
  lua_Complex *a = complex_pushvalue(L, 1);
  lua_Complex *b = complex_pushvalue(L, 2);
  lua_pushboolean(L, complex_eq(a, b));
  return 1;
}

static int complex__lt (lua_State *L) {
  /* complex and number/complex on stack, in no specific order */
  lua_Complex *a = complex_pushvalue(L, 1);
  lua_Complex *b = complex_pushvalue(L, 2);
  lua_pushboolean(L, complex_lt(a, b));
  return 1;
}

static int complex__le (lua_State *L) {
  /* complex and number/complex on stack, in no specific order */
  lua_Complex *a = complex_pushvalue(L, 1);
  lua_Complex *b = complex_pushvalue(L, 2);
  lua_pushboolean(L, complex_le(a, b));
  return 1;
}


/* {=================================================================
 *    Lua (class) methods
 * ==================================================================} */

/* return true if argument is complex, false otherwise */
static int check_complex (lua_State *L) {
  /* object on stack */
  lua_pushboolean(L, complex_checktype(L, 1));
  return 1;
}

/* return real part of complex/number */
static int real_complex (lua_State *L) {
  /* stack contains complex or number */
  lua_Complex *c = complex_pushvalue(L, 1);
  lua_pushnumber(L, c->r);
  return 1;
}

/* return imag part of complex/number */
static int imag_complex (lua_State *L) {
  /* stack contains complex or number */
  lua_Complex *c = complex_pushvalue(L, 1);
  lua_pushnumber(L, c->i);
  return 1;
}

/* return complex conjugate */
static int conj_complex (lua_State *L) {
  lua_Complex *c = complex_pushvalue(L, 1);
  complex_push(L, c->r, -c->i);
  return 1;
}

/* return absolute value */
static int abs_complex (lua_State *L) {
  /* stack contains complex or number */
  lua_pushnumber(L, complex_abs(complex_pushvalue(L, 1)));
  return 1;
}

/* return argument (angle) */
static int arg_complex (lua_State *L) {
  lua_pushnumber(L, complex_arg(complex_pushvalue(L, 1)));
  return 1;
}

static int exp_complex (lua_State *L) {
  complex_exp(complex_pushzero(L), complex_pushvalue(L, 1));
  return 1;
}

static int log_complex (lua_State *L) {
  complex_log(complex_pushzero(L), complex_pushvalue(L, 1));
  return 1;
}

static int sin_complex (lua_State *L) {
  complex_sin(complex_pushzero(L), complex_pushvalue(L, 1));
  return 1;
}

static int cos_complex (lua_State *L) {
  complex_cos(complex_pushzero(L), complex_pushvalue(L, 1));
  return 1;
}

static int sqrt_complex (lua_State *L) {
  complex_sqrt(complex_pushzero(L), complex_pushvalue(L, 1));
  return 1;
}

    
/* {=================================================================
 *    Interface
 * ==================================================================} */

static int complexMT__call (lua_State *L) {
  /* complex, or one or two numbers on stack */
  lua_Complex *c = complex_to(L, 2);
  if (c != NULL) /* complex? */
    complex_push(L, c->r, c->i); /* push copy */
  else /* number(s) */
    complex_push(L, luaL_optnumber(L, 2, 0), luaL_optnumber(L, 3, 0));
  return 1;
}

static const luaL_reg complex_func[] = {
  {"new", complexMT__call},
  {"check", check_complex},
  {"real", real_complex},
  {"imag", imag_complex},
  {"arg", arg_complex},
  {"abs", abs_complex},
  {"conj", conj_complex},
  {"exp", exp_complex},
  {"log", log_complex},
  {"sin", sin_complex},
  {"cos", cos_complex},
  {"sqrt", sqrt_complex},
  {NULL, NULL}
};

static const luaL_reg complex_mt[] = {
  {"__newindex", complex__newindex},
  {"__tostring", complex__tostring},
  /* operations */
  {"__add", complex__add},
  {"__sub", complex__sub},
  {"__unm", complex__unm},
  {"__mul", complex__mul},
  {"__div", complex__div},
  {"__pow", complex__pow},
  {"__eq", complex__eq},
  {"__lt", complex__lt},
  {"__le", complex__le},
  {NULL, NULL}
};

LUACOMPLEX_API int luaopen_luacomplex (lua_State *L) {
  /* luacomplex MT */
  luaL_newmetatable(L, LUACOMPLEX_MT);
  /* set as current environment */
  lua_pushvalue(L, -1);
  lua_replace(L, LUA_ENVIRONINDEX);
  luaL_register(L, NULL, complex_mt); /* push metamethods */
  /* class table */
  luaL_register(L, LUACOMPLEX_LIBNAME, complex_func);
  /* push constants */
  lua_pushstring(L, LUACOMPLEX_VERSION);
  lua_setfield(L, -2, "_VERSION");
  complex_push(L, 0, 1);  /* i */
  lua_setfield(L, -2, "i");
  /* push class table as upvalue to __index TODO: environ */
  lua_pushcfunction(L, complex__index);
  lua_pushvalue(L, -2);
  lua_setfenv(L, -2);
  lua_setfield(L, -3, "__index");
  lua_pushvalue(L, -2);
  lua_setfield(L, -2, "_MT");   /* push MT */
  /* push class metatable */
  lua_createtable(L, 0, 2);
  lua_pushcfunction(L, complexMT__call);
  lua_setfield(L, -2, "__call");
  lua_pushvalue(L, -2); /* class */
  lua_setfield(L, -2, "__metatable"); /* protect */
  lua_setmetatable(L, -2);
  return 1;
}

