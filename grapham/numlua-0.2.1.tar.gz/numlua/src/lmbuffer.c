/* {=================================================================
 *
 * Buffer routines for lua_Matrix
 * See Copyright Notice in luamatrix.h
 * $Id: lmbuffer.c,v 1.1 2006-09-11 02:25:38 carvalho Exp $
 *
 * ==================================================================} */

#include "lmbuffer.h"

/* alloc buffers */
static lm_numbuffer *numbuffer_new (lua_State *L, size_t size) {
  lm_numbuffer *nb = lua_newuserdata(L,
      sizeof(lm_numbuffer) + size * sizeof(lua_Number));
  nb->data = (lua_Number *) ((lm_numbuffer *) nb + 1);
  nb->size = size;
  return nb;
}

static lm_intbuffer *intbuffer_new (lua_State *L, size_t size) {
  lm_intbuffer *ib = lua_newuserdata(L,
      sizeof(lm_intbuffer) + size * sizeof(lua_Integer));
  ib->data = (lua_Integer *) ((lm_intbuffer *) ib + 1);
  ib->size = size;
  return ib;
}


/* API */

void matrixB_newbuffer (lua_State *L) {
  lua_createtable(L, 0, 4);
  lua_newtable(L);
  lua_setfield(L, -2, LM_NBUF_BUSY);
  lua_newtable(L);
  lua_setfield(L, -2, LM_NBUF_FREE);
  lua_newtable(L);
  lua_setfield(L, -2, LM_IBUF_BUSY);
  lua_newtable(L);
  lua_setfield(L, -2, LM_IBUF_FREE);
}

/* get a buffer from buffer bag at pos s.t. buffer->size>=size */
lm_numbuffer *matrixB_getnumbuffer (lua_State *L, int pos, size_t size) {
  lm_numbuffer *nb = NULL;
  lm_numbuffer *curr_nb;
  int found = 0; /* flag */
  lua_getfield(L, pos, LM_NBUF_FREE);
  lua_getfield(L, pos, LM_NBUF_BUSY);
  /* search best nb: either max size or the first b s.t. b->size>=size */
  lua_pushnil(L);
  while (!found && lua_next(L, -3)) {
    curr_nb = (lm_numbuffer *) lua_touserdata(L, -1);
    if (curr_nb->size>=size) { /* found */
      nb = curr_nb;
      found = 1;
    }
    else if (!nb || curr_nb->size>nb->size) nb = curr_nb;
    lua_pop(L, 1); /* value (udata) */
  }
  if (!nb) /* empty? */
    nb = numbuffer_new(L, size);
  else {
    /* remove buffer from table */
    if (!found) lua_pushlightuserdata(L, (void *) nb); /* push key */
    lua_pushvalue(L, -1);
    lua_gettable(L, -4); /* _free[nb] */
    lua_insert(L, -2); /* key <-> value */
    lua_pushnil(L);
    lua_settable(L, -5); /* _free[key] = nil */
    /* check for suitable buffer (in size) */
    if (nb->size<size) {
      lua_pop(L, 1); /* udata from _free */
      nb = numbuffer_new(L, size);
    }
  }
  lua_pushlightuserdata(L, (void *) nb);
  lua_insert(L, -2); /* key <-> value */
  lua_settable(L, -3); /* _busy[nb] = nb */
  lua_pop(L, 2); /* free and busy tables */
  return nb;
}

/* return 1 if numbuffer is found */
int matrixB_freenumbuffer (lua_State *L, int pos, lm_numbuffer *nb) {
  lua_getfield(L, pos, LM_NBUF_BUSY);
  lua_getfield(L, pos, LM_NBUF_FREE);
  /* remove from _busy */
  lua_pushlightuserdata(L, (void *) nb);
  lua_pushvalue(L, -1); /* key */
  lua_gettable(L, -4);
  if (lua_isnil(L, -1)) { /* not found in _busy? */
    lua_pop(L, 4);
    return 0;
  }
  lua_insert(L, -2); /* key <-> value */
  lua_pushnil(L);
  lua_settable(L, -5); /* _busy[key] = nil */
  /* add buffer to _free */
  lua_pushlightuserdata(L, (void *) nb);
  lua_insert(L, -2); /* key <-> value */
  lua_settable(L, -3); /* _free[nb] = nb */
  lua_pop(L, 2); /* free and busy tables */
  return 1;
}

/* get a buffer from buffer bag at pos s.t. buffer->size>=size */
lm_intbuffer *matrixB_getintbuffer (lua_State *L, int pos, size_t size) {
  lm_intbuffer *ib = NULL;
  lm_intbuffer *curr_ib;
  int found = 0; /* flag */
  lua_getfield(L, pos, LM_IBUF_FREE);
  lua_getfield(L, pos, LM_IBUF_BUSY);
  /* search best ib: either max size or the first b s.t. b->size>=size */
  lua_pushnil(L);
  while (!found && lua_next(L, -3)) {
    curr_ib = (lm_intbuffer *) lua_touserdata(L, -1);
    if (curr_ib->size>=size) { /* found */
      ib = curr_ib;
      found = 1;
    }
    else if (!ib || curr_ib->size>ib->size) ib = curr_ib;
    lua_pop(L, 1); /* value (udata) */
  }
  if (!ib) /* empty? */
    ib = intbuffer_new(L, size);
  else {
    /* remove buffer from table */
    if (!found) lua_pushlightuserdata(L, (void *) ib); /* push key */
    lua_pushvalue(L, -1);
    lua_gettable(L, -4); /* _free[ib] */
    lua_insert(L, -2); /* key <-> value */
    lua_pushnil(L);
    lua_settable(L, -5); /* _free[key] = nil */
    /* check for suitable buffer (in size) */
    if (ib->size<size) {
      lua_pop(L, 1); /* udata from _free */
      ib = intbuffer_new(L, size);
    }
  }
  lua_pushlightuserdata(L, (void *) ib);
  lua_insert(L, -2); /* key <-> value */
  lua_settable(L, -3); /* _busy[ib] = ib */
  lua_pop(L, 2); /* free and busy tables */
  return ib;
}

/* return 1 if intbuffer is found */
int matrixB_freeintbuffer (lua_State *L, int pos, lm_intbuffer *ib) {
  lua_getfield(L, pos, LM_IBUF_BUSY);
  lua_getfield(L, pos, LM_IBUF_FREE);
  /* remove from _busy */
  lua_pushlightuserdata(L, (void *) ib);
  lua_pushvalue(L, -1); /* key */
  lua_gettable(L, -4);
  if (lua_isnil(L, -1)) { /* not found in _busy? */
    lua_pop(L, 4);
    return 0;
  }
  lua_insert(L, -2); /* key <-> value */
  lua_pushnil(L);
  lua_settable(L, -5); /* _busy[key] = nil */
  /* add buffer to _free */
  lua_pushlightuserdata(L, (void *) ib);
  lua_insert(L, -2); /* key <-> value */
  lua_settable(L, -3); /* _free[ib] = ib */
  lua_pop(L, 2); /* free and busy tables */
  return 1;
}

