-- {=================================================================
--
-- complex.lua
-- Complex number library for Lua
-- Luis Carvalho (carvalho @ dam.brown.edu)
-- See Copyright Notice at luacomplex.h
-- $Id: complex.lua,v 1.5 2006/02/12 23:44:27 carvalho Exp $
--  
-- ==================================================================}

local complex = require 'luacomplex'
complex._NAME = 'complex'
complex._PACKAGE = 'numlua'

module(complex._NAME)

