-- {=================================================================
--
-- init.lua
-- Numeric Lua module
-- Luis Carvalho (carvalho @ dam.brown.edu)
-- See Copyright Notice at luamatrix.h
-- $Id: init.lua,v 1.3 2006-09-11 02:27:25 carvalho Exp $
--  
-- ==================================================================}

require 'numlua.complex'
require 'numlua.rng'
require 'numlua.spfun'
require 'numlua.matrix'
local matrix = matrix

module 'numlua'
eps = matrix.eps
rmin = matrix.rmin
rmax = matrix.rmax
