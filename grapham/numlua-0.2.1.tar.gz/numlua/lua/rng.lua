-- {=================================================================
--
-- rng.lua
-- Random number generator (RNG) library for Lua
-- Luis Carvalho (carvalho @ dam.brown.edu)
-- See Copyright Notice at luarng.h
-- $Id: rng.lua,v 1.5 2006/02/12 23:44:27 carvalho Exp $
--  
-- ==================================================================}

local rng = require 'luarng'
rng._NAME = 'rng'
rng._PACKAGE = 'numlua'

local pairs = pairs

module(rng._NAME)

-- ================================================================
-- functions

choose = function (r, t, w)
  local s = 1
  if w then -- compute sum
    s = 0
    for _, v in pairs(t) do
      s = s + v
    end
  end
  local u = r:unif()
  local c = 0
  for k, v in pairs(t) do
    if v > 0 and v < 1 then -- skip special keys
      c = c + v / s
      if u < c then return k end
    end
  end
end

