-- {=================================================================
--
-- spfun.lua
-- Special function library for Lua
-- Luis Carvalho (carvalho @ dam.brown.edu)
-- See Copyright Notice at luaspfun.h
-- $Id: spfun.lua,v 1.4 2006/02/12 23:44:27 carvalho Exp $
--  
-- ==================================================================}

local spfun = require 'luaspfun'
spfun._NAME = 'spfun'
spfun._PACKAGE = 'numlua'

module(spfun._NAME)
