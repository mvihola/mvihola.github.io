-- {=================================================================
-- 
-- Basic matrix library for lua
-- See Copyright Notice in luamatrix.h
--
-- $Id: matrix.lua,v 1.9 2006/02/18 01:54:33 carvalho Exp $
--  
-- ==================================================================}

local lcomplex = require 'luacomplex'
local rng = require 'luarng'
local matrix = require 'luamatrix'
matrix._NAME = 'matrix'
matrix._PACKAGE = 'numlua'

-- cache globals
local assert = assert
local ipairs = ipairs
local print = print
local tostring = tostring
local tonumber = tonumber
local type = type
local unpack = unpack
local time = os.time
local rep = string.rep
local insert = table.insert

module(matrix._NAME)

-- ================================================================
-- info (print) stuff

function list(m)
  assert(check(m), 'matrix expected, got ' .. type(m))
  foreach(m, print)
end

function pretty(m)
  assert(check(m), 'matrix expected, got ' .. type(m))
  assert(dim(m) <= 2)
  -- maximum entry length
  local ml = reduce(m, function(x, y)
    local s = tostring(y):len();
    if x < s then x = s end
    return x
  end, 0)
  if dim(m) == 1 then -- vector?
    map(m, function(e)
      local es = tostring(e)
      print(rep(' ', 2 + ml - es:len()) .. e)
    end)
  else  -- array
    for i = 1, m:size(1) do -- print each row
      print(reduce(m[i], function(x, y)
        local es = tostring(y)
        return x .. rep(' ', 2 + ml - es:len()) .. es
      end, ''))
    end
  end
end


-- ================================================================
-- special matrices

function circ(v)
  assert(type(v) == 'table', 'table expected, got ' .. type(v))
  local n = #v
  return zeros(n):apply(function(i, j) return v[(j-i) % n + 1] end)
end

function pascal(n)
  assert(type(n) == 'number', 'number expected, got ' .. type(n))
  assert(n > 0, 'order must be positive')
  local m = zeros(n)
  -- first row
  for i = 1, n do m[1][i] = 1 end
  -- remaining rows
  for i = 2, n do
    m[i][1] = 1
    for j = 2, n do
      m[i][j] = m[i][j-1] + m[i-1][j]
    end
  end
  return m
end

function magic(n)
  assert(type(n) == 'number', 'number expected, got ' .. type(n))
  assert(n > 0, 'order must be positive')
  assert((n % 2) == 1, 'order must be odd')
  local i = 1
  local j = (n + 1) / 2
  local m = zeros(n)
  m[i][j] = 1 -- first position
  for p = 2, n*n do
    i = (i - 2) % n + 1 -- move right...
    j = j % n + 1   -- ...and up
    if m[i][j] == 0 then  -- empty entry?
      m[i][j] = p   -- fill
    else
      -- move back (left, down) and then down
      i = (i + 1) % n + 1
      j = (j - 2) % n + 1
      m[i][j] = p
    end
  end
  return m
end


-- ================================================================
-- specialized functions

local r = rng(time())
function mvnorm(mean, var, n)
  -- basic and boring testing
  assert(check(mean), 'matrix expected, got ' .. type(mean))
  assert(mean:dim() == 1, 'mean must be a vector')
  assert(check(var), 'matrix expected, got ' .. type(var))
  assert(var:dim() == 2, 'variance must be an array')
  assert(var:issquare(), 'variance must be square')
  assert(mean:size() == var:size(1), 'orders do not match')
  -- compute square root of var using Cholesky decomposition
  local u, info = chol(var) -- #u * u = var
  assert(info == 0, 'matrix is not positive definite')
  -- generate y where y:col(i) ~ N(0_m, I_m)
  local m = mean:size()
  local y = matrix(m, n):map(function(e) return r:norm(0, 1) end)
  -- compute #u * y + mean ~ N(mean, var)
  y = #u * y
  for i, j, e in y:entries() do
    y[i][j] = e + mean[i]
  end
  return y
end

function lsolve(A, B)
  assert(check(A), 'matrix expected, got ' .. type(A))
  assert(check(B), 'matrix expected, got ' .. type(B))
  local x, info = linsolve(A, B)
  if info < EPS then
    print('WARNING: matrix is singular to machine precision: rcond = '
        .. info)
    x, info = lss(A, B)
  end
  return x
end

function quad(A, x)
  assert(check(A), 'matrix expected, got ' .. type(A))
  assert(check(x), 'matrix expected, got ' .. type(x))
  local u, info = chol(A)
  assert(info == 0, 'matrix is not posdef')
  return inner(u*x)
end

-- ================================================================
-- matrix.fromtable

local min_table = function (t)
  local min = t[1] or -1
  for _, v in ipairs(t) do if min > v then min = v end end
  return min
end

local dim_table
dim_table = function (t)
  if type(t) ~= 'table' then
    return 0
  else
    local dims = {}
    for i, v in ipairs(t) do dims[i] = dim_table(v) end
    return min_table(dims)+1
  end
end

local sizes_table = function (t)
  local sizes = {}
  for i, v in ipairs(t) do sizes[i] = #v end
  return min_table(sizes)
end

local has_complex
has_complex = function (t)
  if type(t) ~= 'table' then
    return lcomplex.check(t)
  else
    local has = false
    for i = 1, #t do
      has = has or has_complex(t[i])
      if has then break end
    end
    return has
  end
end

-- TODO: FIXME
function fromtable2(t)
  -- initialize
  local dims = dim_table(t)
  local index = {1}
  local size = {#t}
  local curr_t = t
  local flat_t
  for i = 2, dims do
    index[i] = 1  -- prepare for later step
    size[i] = sizes_table(curr_t)
    -- flatten
    flat_t = {}
    for j = 1, size[i-1] do
      for k = 1, size[i] do
        insert(flat_t, curr_t[j][k])
      end
    end
    curr_t = flat_t
  end
  local m
  local has = has_complex(t)
  if has then
    m = complex(unpack(size))
  else
    m = real(unpack(size))
  end

  -- iterator closure
  local next_table = function (ind)
    local pos = #size
    local back_update = true
    while (back_update) do
      if ind[pos] == size[pos] then
        ind[pos] = 1
        pos = pos-1
        back_update = (pos > 0)
      else
        ind[pos] = ind[pos]+1
        back_update = false
      end
    end
    if pos > 0 then
      return ind
    end
  end

  -- traverse
  local curr_m
  repeat
    curr_m = m
    curr_t = t
    for i = 1, dims-1 do
      curr_m = curr_m[index[i]]
      curr_t = curr_t[index[i]]
    end
    if has then
      curr_m[index[dims]] = lcomplex(curr_t[index[dims]])
    else
      curr_m[index[dims]] = tonumber(curr_t[index[dims]]) or 0
    end
    index = next_table(index)
  until index == nil
  return m
end

-- ================================================================

