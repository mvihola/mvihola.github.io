#include "luacomplex.h"
#include "luamatrix.h"
#include "luarng.h"
#include "luaspfun.h"

#undef LUA_PROGNAME
#define LUA_PROGNAME "numlua"

#define NUMLUA_VERSION "NumericLua 0.2.1"
#define NUMLUA_COPYRIGHT "Copyright (C) 2005-2007 Luis Carvalho"

static const luaL_reg numlua_mod[] = {
  {"luacomplex", luaopen_luacomplex},
  {"luarng", luaopen_luarng},
  {"luamatrix", luaopen_luamatrix},
  {"luaspfun", luaopen_luaspfun},
  {NULL, NULL}
};

